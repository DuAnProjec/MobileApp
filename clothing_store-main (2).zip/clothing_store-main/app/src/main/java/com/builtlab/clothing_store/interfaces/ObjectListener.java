package com.builtlab.clothing_store.interfaces;

public interface ObjectListener<T> {
    void onClick(T t);
}
