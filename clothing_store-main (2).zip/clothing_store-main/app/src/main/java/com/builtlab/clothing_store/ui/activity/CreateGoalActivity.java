package com.builtlab.clothing_store.ui.activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.ActivityCreateGoalBinding;
import com.builtlab.clothing_store.helper.query.BusinessPlanDatabaseQuery;
import com.builtlab.clothing_store.helper.query.BusinessPlanTargetDatabaseQuery;
import com.builtlab.clothing_store.model.BusinessPlan;
import com.builtlab.clothing_store.model.BusinessPlanTarget;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CreateGoalActivity extends AppCompatActivity {
    private ActivityCreateGoalBinding binding;
    private BusinessPlanDatabaseQuery businessPlanDatabaseQuery;
    private BusinessPlanTargetDatabaseQuery businessPlanTargetDatabaseQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityCreateGoalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        businessPlanDatabaseQuery = new BusinessPlanDatabaseQuery(this);
        businessPlanTargetDatabaseQuery = new BusinessPlanTargetDatabaseQuery(this);

        init();
    }

    private void init() {
        initAppBar();
        initEvent();
        setupDatePickers();
        setDefaultQuantities();
    }

    private void initEvent() {
        setupQuantityControls(binding.groupBuyJacket.findViewById(R.id.button_add_quantity), binding.groupBuyJacket.findViewById(R.id.button_subtract_quantity), binding.groupBuyJacket.findViewById(R.id.text_quantity));
        setupQuantityControls(binding.groupBuyTShirt.findViewById(R.id.button_add_quantity), binding.groupBuyTShirt.findViewById(R.id.button_subtract_quantity), binding.groupBuyTShirt.findViewById(R.id.text_quantity));
        setupQuantityControls(binding.groupBuyTrouser.findViewById(R.id.button_add_quantity), binding.groupBuyTrouser.findViewById(R.id.button_subtract_quantity), binding.groupBuyTrouser.findViewById(R.id.text_quantity));
        setupQuantityControls(binding.groupBuyDress.findViewById(R.id.button_add_quantity), binding.groupBuyDress.findViewById(R.id.button_subtract_quantity), binding.groupBuyDress.findViewById(R.id.text_quantity));

        setupQuantityControls(binding.groupSellJacket.findViewById(R.id.button_add_quantity), binding.groupSellJacket.findViewById(R.id.button_subtract_quantity), binding.groupSellJacket.findViewById(R.id.text_quantity));
        setupQuantityControls(binding.groupSellTShirt.findViewById(R.id.button_add_quantity), binding.groupSellTShirt.findViewById(R.id.button_subtract_quantity), binding.groupSellTShirt.findViewById(R.id.text_quantity));
        setupQuantityControls(binding.groupSellTrouser.findViewById(R.id.button_add_quantity), binding.groupSellTrouser.findViewById(R.id.button_subtract_quantity), binding.groupSellTrouser.findViewById(R.id.text_quantity));
        setupQuantityControls(binding.groupSellDress.findViewById(R.id.button_add_quantity), binding.groupSellDress.findViewById(R.id.button_subtract_quantity), binding.groupSellDress.findViewById(R.id.text_quantity));

        binding.btnLogin.setOnClickListener(v -> saveBusinessPlan());
    }

    private void setupQuantityControls(ImageButton buttonAdd, ImageButton buttonSubtract, TextInputEditText textQuantity) {
        buttonSubtract.setOnClickListener(v -> {
            int quantity = getQuantity(textQuantity);
            if (quantity > 0) {
                quantity--;
                textQuantity.setText(String.valueOf(quantity));
            }
        });

        buttonAdd.setOnClickListener(v -> {
            int quantity = getQuantity(textQuantity);
            quantity++;
            textQuantity.setText(String.valueOf(quantity));
        });
    }

    private int getQuantity(TextInputEditText textQuantity) {
        String quantityString = textQuantity.getText().toString();
        if (quantityString.isEmpty()) {
            return 0;
        }
        try {
            return Integer.parseInt(quantityString);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void initAppBar() {
        binding.appbar.appBarTitle.setText(R.string.create_new_plan);
        binding.appbar.buttonBack.setOnClickListener(v -> finish());
    }

    private void setupDatePickers() {
        binding.startDateLayout.setOnClickListener(v -> showDatePickerDialog(binding.startDate));
        binding.endDateLayout.setOnClickListener(v -> showDatePickerDialog(binding.endDate));
    }

    private void showDatePickerDialog(final TextView dateField) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year1, monthOfYear, dayOfMonth) -> {
            String selectedDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year1;
            dateField.setText(selectedDate);
        }, year, month, day);
        datePickerDialog.show();
    }

    private void setDefaultQuantities() {
        ((TextInputEditText) binding.groupBuyJacket.findViewById(R.id.text_quantity)).setText("0");
        ((TextInputEditText)binding.groupBuyTShirt.findViewById(R.id.text_quantity)).setText("0");
        ((TextInputEditText)binding.groupBuyTrouser.findViewById(R.id.text_quantity)).setText("0");
        ((TextInputEditText)binding.groupBuyDress.findViewById(R.id.text_quantity)).setText("0");

        ((TextInputEditText)binding.groupSellJacket.findViewById(R.id.text_quantity)).setText("0");
        ((TextInputEditText)binding.groupSellTShirt.findViewById(R.id.text_quantity)).setText("0");
        ((TextInputEditText)binding.groupSellTrouser.findViewById(R.id.text_quantity)).setText("0");
        ((TextInputEditText)binding.groupSellDress.findViewById(R.id.text_quantity)).setText("0");
    }

    private void saveBusinessPlan() {
        String startDate = binding.startDate.getText().toString();
        String endDate = binding.endDate.getText().toString();

        if (startDate.isEmpty() || endDate.isEmpty()) {
            Toast.makeText(this, "Start date and end date must be filled", Toast.LENGTH_SHORT).show();
            return;
        }

        BusinessPlan businessPlan = new BusinessPlan();
        businessPlan.setStartDate(startDate);
        businessPlan.setEndDate(endDate);
        long businessPlanId = businessPlanDatabaseQuery.addBusinessPlan(businessPlan);

        if (businessPlanId != -1) {
            List<BusinessPlanTarget> targets = createBusinessPlanTargets((int) businessPlanId);
            for (BusinessPlanTarget target : targets) {
                businessPlanTargetDatabaseQuery.addBusinessPlanTarget(target);
            }
            Toast.makeText(this, "Business Plan and targets saved successfully", Toast.LENGTH_SHORT).show();
            Intent returnIntent = new Intent();
            setResult(RESULT_OK, returnIntent);
            finish();
        } else {
            Toast.makeText(this, "Failed to save Business Plan", Toast.LENGTH_SHORT).show();
        }
    }

    private List<BusinessPlanTarget> createBusinessPlanTargets(int businessPlanId) {
        List<BusinessPlanTarget> targets = new ArrayList<>();
        targets.add(new BusinessPlanTarget(0, businessPlanId, "Full set", getQuantity(binding.groupBuyJacket.findViewById(R.id.text_quantity)), getQuantity(binding.groupSellJacket.findViewById(R.id.text_quantity))));
        targets.add(new BusinessPlanTarget(0, businessPlanId, "Áo", getQuantity(binding.groupBuyTShirt.findViewById(R.id.text_quantity)), getQuantity(binding.groupSellTShirt.findViewById(R.id.text_quantity))));
        targets.add(new BusinessPlanTarget(0, businessPlanId, "Quần", getQuantity(binding.groupBuyTrouser.findViewById(R.id.text_quantity)), getQuantity(binding.groupSellTrouser.findViewById(R.id.text_quantity))));
        targets.add(new BusinessPlanTarget(0, businessPlanId, "Đầm/Váy", getQuantity(binding.groupBuyDress.findViewById(R.id.text_quantity)), getQuantity(binding.groupSellDress.findViewById(R.id.text_quantity))));
        return targets;
    }
}
