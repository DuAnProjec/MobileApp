package com.builtlab.clothing_store.helper.query;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.Order;

import java.util.ArrayList;
import java.util.List;

public class OrderDatabaseQuery extends DatabaseQuery<Order> {
    private static final String TABLE_NAME = AppTableData.TABLE_ORDER;

    public OrderDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "OrderID";
    }

    @Override
    protected ContentValues getContentValues(Order order) {
        ContentValues values = new ContentValues();
//        values.put("OrderID", order.getOrderId());
        values.put("CustomerID", order.getCustomerId());
        values.put("OrderDate", order.getOrderDate());
        values.put("SubTotal", order.getSubTotal());
        values.put("DiscountAmount", order.getDiscountAmount());
        values.put("TotalAmount", order.getTotalAmount());
        values.put("Status", order.getStatus());
        values.put("PromotionID", order.getPromotionId());
        return values;
    }

    @Override
    protected Order cursorToItem(Cursor cursor) {
        Order order = new Order();
        order.setOrderId((int) cursor.getLong(cursor.getColumnIndexOrThrow("OrderID")));
        order.setCustomerId((int) cursor.getLong(cursor.getColumnIndexOrThrow("CustomerID")));
        order.setOrderDate(cursor.getString(cursor.getColumnIndexOrThrow("OrderDate")));
        order.setSubTotal(cursor.getDouble(cursor.getColumnIndexOrThrow("SubTotal")));
        order.setDiscountAmount(cursor.getDouble(cursor.getColumnIndexOrThrow("DiscountAmount")));
        order.setTotalAmount(cursor.getDouble(cursor.getColumnIndexOrThrow("TotalAmount")));
        order.setStatus(cursor.getString(cursor.getColumnIndexOrThrow("Status")));
        order.setPromotionId((int) cursor.getLong(cursor.getColumnIndexOrThrow("PromotionID")));
        return order;
    }

    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                orders.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return orders;
    }

    public Order getOrderById(long id) {
        open();
        Order order = getItem(id, "OrderID");
        close();
        return order;
    }

    public double getTotalRevenueByDate(String date) {
        open();
        double totalRevenue = 0;
        Cursor cursor = getDatabase().rawQuery(
                "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE OrderDate = ?", new String[]{date});
        if (cursor.moveToFirst()) {
            totalRevenue = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalRevenue;
    }

    public double getTotalRevenueByMonth(int year, int month) {
        open();
        double totalRevenue = 0;
        String formattedMonth = String.format("%02d", month);
        Cursor cursor = getDatabase().rawQuery(
                "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE strftime('%Y', OrderDate) = ? AND strftime('%m', OrderDate) = ?",
                new String[]{String.valueOf(year), formattedMonth});
        if (cursor.moveToFirst()) {
            totalRevenue = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalRevenue;
    }

    public double getTotalRevenueByQuarter(int year, int quarter) {
        open();
        double totalRevenue = 0;
        String[] months;
        switch (quarter) {
            case 1:
                months = new String[]{"01", "02", "03"};
                break;
            case 2:
                months = new String[]{"04", "05", "06"};
                break;
            case 3:
                months = new String[]{"07", "08", "09"};
                break;
            case 4:
                months = new String[]{"10", "11", "12"};
                break;
            default:
                months = new String[]{};
                break;
        }
        String query = "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE strftime('%Y', OrderDate) = ? AND (strftime('%m', OrderDate) = ? OR strftime('%m', OrderDate) = ? OR strftime('%m', OrderDate) = ?)";
        Cursor cursor = getDatabase().rawQuery(query, new String[]{String.valueOf(year), months[0], months[1], months[2]});
        if (cursor.moveToFirst()) {
            totalRevenue = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalRevenue;
    }

    public double getTotalRevenueByYear(int year) {
        open();
        double totalRevenue = 0;
        String startDate = "01/01/" + year ;
        String endDate = "31/12/" + year ;
        Cursor cursor = getDatabase().rawQuery(
                "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE OrderDate BETWEEN ? AND ?",
                new String[]{startDate, endDate});

        if (cursor.moveToFirst()) {
            totalRevenue = cursor.getDouble(0);
        } else {
            Log.d("Test year", "No data found for the year: " + year);
        }

        cursor.close();
        close();

        return totalRevenue;
    }

    public double getTotalByDate(String date) {
        open();
        double totalRevenue = 0;
        Cursor cursor = getDatabase().rawQuery(
                "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE OrderDate = ?", new String[]{date});
        if (cursor.moveToFirst()) {
            totalRevenue = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalRevenue;
    }
    public double getTotalByMonth(int year, int month) {
        open();
        double totalRevenue = 0;
        String formattedMonth = String.format("%02d", month);
        String query = "SELECT SUM(TotalAmount) FROM " + TABLE_NAME +
                " WHERE strftime('%Y', OrderDate) = ? AND strftime('%m', OrderDate) = ?";
        Cursor cursor = getDatabase().rawQuery(query, new String[]{String.valueOf(year), formattedMonth});
        if (cursor.moveToFirst()) {
            totalRevenue = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalRevenue;
    }

    public List<Order> getOrdersByDateRange(String startDate, String endDate) {
        List<Order> orders = new ArrayList<>();
        open();
        String selection = "OrderDate >= ? AND OrderDate <= ?";
        String[] selectionArgs = {startDate, endDate};
        Cursor cursor = getItemsByCondition(selection, selectionArgs);
        if (cursor.moveToFirst()) {
            do {
                orders.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return orders;
    }
}
