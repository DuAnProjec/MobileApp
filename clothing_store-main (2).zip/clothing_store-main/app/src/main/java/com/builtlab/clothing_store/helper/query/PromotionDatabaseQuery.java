package com.builtlab.clothing_store.helper.query;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.Promotion;

import java.util.ArrayList;
import java.util.List;

public class PromotionDatabaseQuery extends DatabaseQuery<Promotion> {
    private static final String TABLE_NAME = AppTableData.TABLE_PROMOTION;

    public PromotionDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "PromotionID";
    }

    @Override
    protected ContentValues getContentValues(Promotion promotion) {
        ContentValues values = new ContentValues();
        values.put("PromotionName", promotion.getPromotionName());
        values.put("Description", promotion.getDescription());
        values.put("DiscountPercentage", promotion.getDiscountPercentage());
        values.put("MinimumOrderAmount", promotion.getMinimumOrderAmount());
        values.put("StartDate", promotion.getStartDate());
        values.put("EndDate", promotion.getEndDate());
        values.put("ApplicableCategories", promotion.getApplicableCategories());
        values.put("ApplicableTo", promotion.getApplicableTo());
        return values;
    }

    @Override
    protected Promotion cursorToItem(Cursor cursor) {
        Promotion promotion = new Promotion();
        promotion.setPromotionId(cursor.getInt(cursor.getColumnIndexOrThrow("PromotionID")));
        promotion.setPromotionName(cursor.getString(cursor.getColumnIndexOrThrow("PromotionName")));
        promotion.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("Description")));
        promotion.setDiscountPercentage(cursor.getDouble(cursor.getColumnIndexOrThrow("DiscountPercentage")));
        promotion.setMinimumOrderAmount(cursor.getDouble(cursor.getColumnIndexOrThrow("MinimumOrderAmount")));
        promotion.setStartDate(cursor.getString(cursor.getColumnIndexOrThrow("StartDate")));
        promotion.setEndDate(cursor.getString(cursor.getColumnIndexOrThrow("EndDate")));
        promotion.setApplicableCategories(cursor.getString(cursor.getColumnIndexOrThrow("ApplicableCategories")));
        promotion.setApplicableTo(cursor.getString(cursor.getColumnIndexOrThrow("ApplicableTo")));
        return promotion;
    }

    public List<Promotion> getAllPromotions() {
        List<Promotion> promotions = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                promotions.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return promotions;
    }

    public Promotion getPromotionById(long id) {
        open();
        Promotion promotion = getItem(id, "PromotionID");
        close();
        return promotion;
    }

    public long addPromotion(Promotion promotion) {
        long id = -1;
        try {
            open();
            id = insert(promotion);
            if (id == -1) {
                Log.e(TAG, "Failed to insert row for promotion: " + promotion.toString());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error inserting promotion", e);
        } finally {
            close();
        }
        return id;
    }

    public void updatePromotion(Promotion promotion) {
        try {
            open();
            update(promotion.getPromotionId(), promotion);
        } catch (Exception e) {
            Log.e(TAG, "Error updating promotion", e);
        } finally {
            close();
        }
    }

    public void deletePromotion(long promotionId) {
        try {
            open();
            delete(promotionId);
        } catch (Exception e) {
            Log.e(TAG, "Error deleting promotion", e);
        } finally {
            close();
        }
    }
}
