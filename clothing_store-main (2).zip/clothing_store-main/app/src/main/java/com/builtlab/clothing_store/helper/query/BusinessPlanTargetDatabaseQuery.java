package com.builtlab.clothing_store.helper.query;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.BusinessPlanTarget;
import java.util.ArrayList;
import java.util.List;

public class BusinessPlanTargetDatabaseQuery extends DatabaseQuery<BusinessPlanTarget> {
    private static final String TABLE_NAME = AppTableData.TABLE_BUSINESS_PLAN_TARGET;

    public BusinessPlanTargetDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "TargetID";
    }

    @Override
    protected ContentValues getContentValues(BusinessPlanTarget businessPlanTarget) {
        ContentValues values = new ContentValues();
        values.put("BusinessPlanID", businessPlanTarget.getBusinessPlanId());
        values.put("ProductCategory", businessPlanTarget.getProductCategory());
        values.put("PurchaseTarget", businessPlanTarget.getPurchaseTarget());
        values.put("SaleTarget", businessPlanTarget.getSaleTarget());
        return values;
    }

    @Override
    protected BusinessPlanTarget cursorToItem(Cursor cursor) {
        return new BusinessPlanTarget(
                cursor.getInt(cursor.getColumnIndexOrThrow("TargetID")),
                cursor.getInt(cursor.getColumnIndexOrThrow("BusinessPlanID")),
                cursor.getString(cursor.getColumnIndexOrThrow("ProductCategory")),
                cursor.getInt(cursor.getColumnIndexOrThrow("PurchaseTarget")),
                cursor.getInt(cursor.getColumnIndexOrThrow("SaleTarget"))
        );
    }

    public List<BusinessPlanTarget> getAllBusinessPlanTargets() {
        List<BusinessPlanTarget> businessPlanTargets = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                businessPlanTargets.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return businessPlanTargets;
    }

    public BusinessPlanTarget getBusinessPlanTargetById(long id) {
        open();
        BusinessPlanTarget businessPlanTarget = getItem(id, "TargetID");
        close();
        return businessPlanTarget;
    }

    public long addBusinessPlanTarget(BusinessPlanTarget businessPlanTarget) {
        long id = -1;
        try {
            open();
            id = insert(businessPlanTarget);
            if (id == -1) {
                Log.e(TAG, "Failed to insert row for business plan target: " + businessPlanTarget.toString());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error inserting business plan target", e);
        } finally {
            close();
        }
        return id;
    }

    public void updateBusinessPlanTarget(BusinessPlanTarget businessPlanTarget) {
        try {
            open();
            update(businessPlanTarget.getTargetId(), businessPlanTarget);
        } catch (Exception e) {
            Log.e(TAG, "Error updating business plan target", e);
        } finally {
            close();
        }
    }

    public void deleteBusinessPlanTarget(long targetId) {
        try {
            open();
            delete(targetId);
        } catch (Exception e) {
            Log.e(TAG, "Error deleting business plan target", e);
        } finally {
            close();
        }
    }

    public List<BusinessPlanTarget> getBusinessPlanTargetsByPlanId(int businessPlanId) {
        List<BusinessPlanTarget> businessPlanTargets = new ArrayList<>();
        open();
        Cursor cursor = getItemsByColumn("BusinessPlanID", String.valueOf(businessPlanId));
        if (cursor.moveToFirst()) {
            do {
                businessPlanTargets.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return businessPlanTargets;
    }
}
