package com.builtlab.clothing_store.ui.fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.adapter.ProductBanChayAdapter;
import com.builtlab.clothing_store.databinding.FragmentBillBinding;
import com.builtlab.clothing_store.helper.query.ProductDatabaseQuery;
import com.builtlab.clothing_store.model.Product;
import com.builtlab.clothing_store.ui.activity.ListProductActivity;

import java.util.List;

public class BillFragment extends Fragment {

    private FragmentBillBinding binding;
    private List<Product> products;
    private ProductBanChayAdapter adapter;
    private ProductDatabaseQuery query;

    public BillFragment() {
        // Required empty public constructor
    }

    public static BillFragment newInstance() {
        return new BillFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        query = new ProductDatabaseQuery(requireContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentBillBinding.inflate(inflater, container, false);
        View view = binding.getRoot();

        loadProducts();
        updateCategoryCounts();

        binding.tvXemTatCa.setOnClickListener(listener -> {
            Intent intent = new Intent(getActivity(), ListProductActivity.class);
            startActivity(intent);
        });

        binding.cvAoKhoac.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), ListProductActivity.class);
            intent.putExtra("type", 1);
            startActivity(intent);
        });
        binding.cvAoPhong.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), ListProductActivity.class);
            intent.putExtra("type", 2);
            startActivity(intent);
        });
        binding.cvQuan.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), ListProductActivity.class);
            intent.putExtra("type", 3);
            startActivity(intent);
        });
        binding.cvVay.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), ListProductActivity.class);
            intent.putExtra("type", 4);
            startActivity(intent);
        });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadProducts();
        updateCategoryCounts();
    }

    private void loadProducts() {
        products = query.getAllProducts();
        adapter = new ProductBanChayAdapter(requireContext(), products);
        binding.rcvSanPhamBanChay.setLayoutManager(new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false));
        binding.rcvSanPhamBanChay.setAdapter(adapter);
    }

    private void updateCategoryCounts() {
        int aoKhoacCount = query.getProductCountByCategoryId(getCategoryIdFromString("Full set"));
        int aoPhongCount = query.getProductCountByCategoryId(getCategoryIdFromString("Áo"));
        int quanCount = query.getProductCountByCategoryId(getCategoryIdFromString("Quần"));
        int vayCount = query.getProductCountByCategoryId(getCategoryIdFromString("Đầm/Váy"));

        ((TextView) binding.cvAoKhoac.findViewById(R.id.tv_count_ao_khoac)).setText(String.valueOf(aoKhoacCount));
        ((TextView) binding.cvAoPhong.findViewById(R.id.tv_count_ao_phong)).setText(String.valueOf(aoPhongCount));
        ((TextView) binding.cvQuan.findViewById(R.id.tv_count_quan)).setText(String.valueOf(quanCount));
        ((TextView) binding.cvVay.findViewById(R.id.tv_count_vay)).setText(String.valueOf(vayCount));
    }

    public int getCategoryIdFromString(String category) {
        switch (category) {
            case "Full set":
                return 1;
            case "Áo":
                return 2;
            case "Quần":
                return 3;
            case "Đầm/Váy":
                return 4;
            default:
                return -1;
        }
    }
}
