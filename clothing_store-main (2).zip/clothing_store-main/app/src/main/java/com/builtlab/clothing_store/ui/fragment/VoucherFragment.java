package com.builtlab.clothing_store.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.adapter.VoucherAdapter;
import com.builtlab.clothing_store.databinding.FragmentVoucherBinding;
import com.builtlab.clothing_store.helper.query.PromotionDatabaseQuery;
import com.builtlab.clothing_store.model.Promotion;
import com.builtlab.clothing_store.ui.activity.CreateVoucherActivity;

import java.util.List;

public class VoucherFragment extends Fragment {

    private FragmentVoucherBinding binding;
    private VoucherAdapter voucherAdapter;
    private List<Promotion> promotions;

    public VoucherFragment() {
        // Required empty public constructor
    }

    public static VoucherFragment newInstance() {
        return new VoucherFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentVoucherBinding.inflate(inflater, container, false);
        View view = binding.getRoot();

        binding.fab.setOnClickListener(v -> startActivity(new Intent(getActivity(), CreateVoucherActivity.class)));

        loadVouchers();

        return view;
    }

    private void loadVouchers() {
        PromotionDatabaseQuery promotionDbQuery = new PromotionDatabaseQuery(getContext());
        promotions = promotionDbQuery.getAllPromotions();

        voucherAdapter = new VoucherAdapter(getContext(), promotions);
        binding.recyclerViewVouchers.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recyclerViewVouchers.setAdapter(voucherAdapter);
    }
}
