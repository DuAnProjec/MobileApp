package com.builtlab.clothing_store.ui.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.adapter.ProductListAdapter;
import com.builtlab.clothing_store.adapter.SpinnerAdapter;
import com.builtlab.clothing_store.adapter.VoucherAdapter;
import com.builtlab.clothing_store.databinding.ActivityListProductBinding;
import com.builtlab.clothing_store.helper.query.ProductDatabaseQuery;
import com.builtlab.clothing_store.helper.query.PromotionDatabaseQuery;
import com.builtlab.clothing_store.model.Product;
import com.builtlab.clothing_store.model.Promotion;

import java.util.ArrayList;
import java.util.List;

public class ListProductActivity extends AppCompatActivity {

    private ActivityListProductBinding binding;
    private List<Product> products;
    ProductListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityListProductBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();

    }



    private void init() {
        initCustomAppBar();


        loadProducts();

        binding.fabAddProduct.setOnClickListener(listener -> {
            Intent intent = new Intent(this, CreateProductActivity.class);
            startActivity(intent);
        });

        List<String> categories = new ArrayList<>();
        categories.add("Tất cả");
        categories.add("Full set");
        categories.add("Áo");
        categories.add("Quần");
        categories.add("Đầm/Váy");
        SpinnerAdapter spinnerAdapter = new SpinnerAdapter(this, categories);
        binding.spnType.setAdapter(spinnerAdapter);

        binding.spnType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = categories.get(position);
                filterProducts(selectedCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        Intent typeIntent = getIntent();
        int type = typeIntent.getIntExtra("type", 0);
        switch (type) {
            case 1:
                binding.spnType.setSelection(1);
                break;
            case 2:
                binding.spnType.setSelection(2);
                break;
            case 3:
                binding.spnType.setSelection(3);
                break;
            case 4:
                binding.spnType.setSelection(4);
                break;
            case 0:
                binding.spnType.setSelection(0);
                break;
        }

    }

    private void initCustomAppBar() {
        binding.customAppBar.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.customAppBar.appBarTitle.setText("Danh sách sản phẩm");
    }

    private void loadProducts() {
        ProductDatabaseQuery query = new ProductDatabaseQuery(this);
        products = query.getAllProducts();

        adapter = new ProductListAdapter(this, products);
        binding.rcvListProduct.setLayoutManager(new LinearLayoutManager(this));
        binding.rcvListProduct.setAdapter(adapter);
    }

    private void filterProducts(String category) {
        if (category.equals("Tất cả")) {
            adapter.updateList(products);
        } else {
            List<Product> filteredList = new ArrayList<>();
            for (Product product : products) {
                if (product.getCategoryId() == (getCategoryIdFromString(category))) {
                    filteredList.add(product);
                }
            }
            adapter.updateList(filteredList);
        }
    }

    public int getCategoryIdFromString(String category) {
        switch (category) {
            case "Full set":
                return 1;
            case "Áo":
                return 2;
            case "Quần":
                return 3;
            case "Đầm/Váy":
                return 4;
            default:
                return -1;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        loadProducts();
    }

}