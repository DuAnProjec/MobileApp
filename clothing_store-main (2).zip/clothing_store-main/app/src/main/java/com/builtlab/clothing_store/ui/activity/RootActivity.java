package com.builtlab.clothing_store.ui.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.ActivityRootBinding;
import com.builtlab.clothing_store.ui.fragment.BillFragment;
import com.builtlab.clothing_store.ui.fragment.HomeFragment;
import com.builtlab.clothing_store.ui.fragment.ProfileFragment;
import com.builtlab.clothing_store.ui.fragment.VoucherFragment;

public class RootActivity extends BaseActivity {
    private ActivityRootBinding binding;
    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_root);
        binding = ActivityRootBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        binding.bottomNavigationView.setOnApplyWindowInsetsListener(null);
        binding.bottomNavigationView.setPadding(0,0,0,0);


        init();
    }

    private void init() {
        fragmentManager = getSupportFragmentManager();
        setDefaultFragment();
        initEventComponent();
    }

    @SuppressLint("NonConstantResourceId")
    private void initEventComponent() {
        binding.bottomNavigationView.setBackground(null);
        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
                    int itemId = item.getItemId();
                    if (itemId == R.id.btn_home) {
                        replaceFragment(new HomeFragment());
                    } else if (itemId == R.id.btn_list_bill) {
                        replaceFragment(new BillFragment());
                    } else if (itemId == R.id.btn_profile) {
                        replaceFragment(new ProfileFragment());
                    } else if (itemId == R.id.btn_voucher) {
                        replaceFragment(new VoucherFragment());
                    }
                    return true;
                }
        );
    }

    private void setDefaultFragment() {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.setReorderingAllowed(true);
        fragmentTransaction.replace(R.id.frame_layout, new HomeFragment());
        fragmentTransaction.commit();
    }

    private void replaceFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.setReorderingAllowed(true);
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }

}