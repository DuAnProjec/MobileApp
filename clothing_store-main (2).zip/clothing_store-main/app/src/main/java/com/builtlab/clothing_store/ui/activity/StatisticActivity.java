package com.builtlab.clothing_store.ui.activity;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.adapter.SpinnerAdapter;
import com.builtlab.clothing_store.databinding.ActivityStatisticBinding;
import com.builtlab.clothing_store.helper.query.OrderDatabaseQuery;
import com.builtlab.clothing_store.helper.query.PurchaseOrderDatabaseQuery;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class StatisticActivity extends AppCompatActivity {

    ActivityStatisticBinding binding;
    private OrderDatabaseQuery orderDatabaseQuery;
    private PurchaseOrderDatabaseQuery purchaseOrderDatabaseQuery;
    private BarChart barChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityStatisticBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        barChart = binding.barChartToTal;
        orderDatabaseQuery = new OrderDatabaseQuery(this);
        purchaseOrderDatabaseQuery = new PurchaseOrderDatabaseQuery(this);
        init();
    }

    private void init() {
        initCustomAppBar();
        List<String> categories = new ArrayList<>();
        categories.add("Ngày");
        categories.add("Tháng");
        categories.add("Quý");
        categories.add("Năm");
        SpinnerAdapter spinnerAdapter = new SpinnerAdapter(this, categories);
        binding.spnType.setAdapter(spinnerAdapter);

        binding.spnType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = categories.get(position);
                if ("Ngày".equals(selectedItem)) {
                    binding.llSelectDate.setVisibility(View.VISIBLE);
                    binding.spnMonth.setVisibility(View.GONE);
                    binding.spnYear.setVisibility(View.GONE);
                    binding.spnQuarter.setVisibility(View.GONE);
                } else if ("Tháng".equals(selectedItem)) {
                    binding.llSelectDate.setVisibility(View.GONE);
                    binding.spnMonth.setVisibility(View.VISIBLE);
                    binding.spnYear.setVisibility(View.VISIBLE);
                    binding.spnQuarter.setVisibility(View.GONE);
                    setupMonthSpinner();
                    setupYearSpinner();
                } else if ("Quý".equals(selectedItem)) {
                    binding.llSelectDate.setVisibility(View.GONE);
                    binding.spnMonth.setVisibility(View.GONE);
                    binding.spnYear.setVisibility(View.VISIBLE);
                    binding.spnQuarter.setVisibility(View.VISIBLE);
                    setupQuarterSpinner();
                    setupYearSpinner();
                } else if ("Năm".equals(selectedItem)) {
                    binding.llSelectDate.setVisibility(View.GONE);
                    binding.spnMonth.setVisibility(View.GONE);
                    binding.spnYear.setVisibility(View.VISIBLE);
                    binding.spnQuarter.setVisibility(View.GONE);
                    setupYearSpinner();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        binding.llSelectDate.setOnClickListener(v -> {
            showDatePickerDialog(Calendar.getInstance(), binding.tvSelectDate);
        });
        binding.btnSeeStatistic.setOnClickListener(v -> {
            seeStatistic();
        });
    }

    private void setupMonthSpinner() {
        List<String> months = new ArrayList<>();
        for (int i = 1; i <= 12; i++) {
            months.add("Tháng " + i);
        }
        SpinnerAdapter monthAdapter = new SpinnerAdapter(this, months);
        binding.spnMonth.setAdapter(monthAdapter);
    }

    private void setupQuarterSpinner() {
        List<String> quarters = new ArrayList<>();
        quarters.add("Quý 1");
        quarters.add("Quý 2");
        quarters.add("Quý 3");
        quarters.add("Quý 4");
        SpinnerAdapter quarterAdapter = new SpinnerAdapter(this, quarters);
        binding.spnQuarter.setAdapter(quarterAdapter);
    }

    private void setupYearSpinner() {
        List<String> years = new ArrayList<>();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = currentYear - 10; i <= currentYear + 10; i++) {
            years.add(String.valueOf(i));
        }
        SpinnerAdapter yearAdapter = new SpinnerAdapter(this, years);
        binding.spnYear.setAdapter(yearAdapter);

        // Set default selection to the specified year
        int defaultYearIndex = years.indexOf(String.valueOf("2024"));
        if (defaultYearIndex >= 0) {
            binding.spnYear.setSelection(defaultYearIndex);
        }
    }

    private void showDatePickerDialog(final Calendar calendar, final TextView editText) {
        DatePickerDialog datePickerDialog = new DatePickerDialog(StatisticActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDateEditText(editText, calendar);
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void updateDateEditText(TextView editText, Calendar calendar) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        editText.setText(sdf.format(calendar.getTime()));
    }

    public String convertToStandardFormat(String date) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy");

        SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");

        String standardDate = null;
        try {
            Date parsedDate = inputFormat.parse(date);

            standardDate = outputFormat.format(parsedDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return standardDate;
    }

    private void seeStatistic() {
        try {
            String selectedType = binding.spnType.getSelectedItem().toString();
            double totalRevenue = 0;
            double totalExpense = 0;
            String label = "";

            if ("Ngày".equals(selectedType)) {
                String date = binding.tvSelectDate.getText().toString();
                totalRevenue = orderDatabaseQuery.getTotalByDate(convertToStandardFormat(date));
                totalExpense = purchaseOrderDatabaseQuery.getTotalByDate(convertToStandardFormat(date));
                label = date;
            } else if ("Tháng".equals(selectedType)) {
                int year = Integer.parseInt(binding.spnYear.getSelectedItem().toString());
                int month = binding.spnMonth.getSelectedItemPosition() + 1;
                Log.i("MONTTH", "seeStatistic: " + month);
                totalRevenue = orderDatabaseQuery.getTotalByMonth(year, month);
                totalExpense = purchaseOrderDatabaseQuery.getTotalByMonth(year, month);
                label = "Tháng " + month;
            } else if ("Quý".equals(selectedType)) {
                int year = Integer.parseInt(binding.spnYear.getSelectedItem().toString());
                int quarter = binding.spnQuarter.getSelectedItemPosition() + 1;
                totalRevenue = orderDatabaseQuery.getTotalRevenueByQuarter(year, quarter);
                totalExpense = purchaseOrderDatabaseQuery.getTotalPurchaseByQuarter(year, quarter);
                label = "Quý " + quarter;
            } else if ("Năm".equals(selectedType)) {
                int year = Integer.parseInt(binding.spnYear.getSelectedItem().toString());
                totalRevenue = orderDatabaseQuery.getTotalRevenueByYear(year);
                totalExpense = purchaseOrderDatabaseQuery.getTotalPurchaseByYear(year);
                label = String.valueOf(year);
            }

            binding.tvTongThu.setText(String.format(Locale.getDefault(), "%.2f VNĐ", totalRevenue));
            binding.tvTongChi.setText(String.format(Locale.getDefault(), "%.2f VNĐ", -totalExpense));
            binding.tvTongLoiNhuan.setText(String.format(Locale.getDefault(), "%.2f VNĐ", totalRevenue - totalExpense));

            updateBarChart(new double[]{totalRevenue, totalExpense}, new String[]{label, label});
        } catch (Exception e) {
            Log.e("StatisticActivity", "seeStatistic: ", e);
        }
    }

    private void updateBarChart(double[] values, String[] labels) {
        List<BarEntry> revenueEntries = new ArrayList<>();
        List<BarEntry> expenseEntries = new ArrayList<>();
        for (int i = 0; i < values.length; i++) {
            if (i % 2 == 0) {
                revenueEntries.add(new BarEntry(i, (float) values[i]));
            } else {
                expenseEntries.add(new BarEntry(i, (float) values[i]));
            }
        }
        BarDataSet revenueDataSet = new BarDataSet(revenueEntries, "Revenue");
        revenueDataSet.setColor(Color.GREEN); // Set revenue bar color to green
        BarDataSet expenseDataSet = new BarDataSet(expenseEntries, "Expense");
        expenseDataSet.setColor(Color.RED); // Set expense bar color to red

        BarData barData = new BarData(revenueDataSet, expenseDataSet);
        barData.setValueTextColor(Color.TRANSPARENT); // Hide the value text on the bars
        barChart.setData(barData);

        Description description = new Description();
        description.setText("");
        barChart.setDescription(description);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);

        barChart.getAxisLeft().setAxisMinimum(0);
        barChart.invalidate(); // Refresh chart
    }

    private void initCustomAppBar() {
        binding.appbar.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.appbar.appBarTitle.setText("Thống kê chi phí");
    }
}


