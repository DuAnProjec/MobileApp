package com.builtlab.clothing_store.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.helper.query.CustomerDatabaseQuery;
import com.builtlab.clothing_store.model.Customer;
import com.builtlab.clothing_store.ui.activity.CreateCustomerActivity;
import java.util.List;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.CustomerViewHolder> {

    private static final int REQUEST_CODE_CREATE_CUSTOMER = 1;
    private List<Customer> customerList;
    private Context context;

    public CustomerAdapter(Context context, List<Customer> customerList) {
        this.context = context;
        this.customerList = customerList;
    }

    @NonNull
    @Override
    public CustomerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_customer, parent, false);
        return new CustomerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomerViewHolder holder, int position) {
        Customer customer = customerList.get(position);
        holder.customerName.setText(customer.getCustomerName());
        holder.customerPhone.setText(customer.getPhoneNumber());

        holder.editButton.setOnClickListener(v -> {
            Intent intent = new Intent(context, CreateCustomerActivity.class);
            intent.putExtra("customer", customer);
            ((AppCompatActivity) context).startActivityForResult(intent, REQUEST_CODE_CREATE_CUSTOMER);
        });

        holder.deleteButton.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Xóa Khách Hàng")
                    .setMessage("Bạn có chắc chắn muốn xóa khách hàng này?")
                    .setPositiveButton("Có", (dialog, which) -> {
                        CustomerDatabaseQuery customerDbQuery = new CustomerDatabaseQuery(context);
                        customerDbQuery.deleteCustomer(customer.getCustomerId());
                        customerList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, customerList.size());
                    })
                    .setNegativeButton("Không", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return customerList.size();
    }

    public static class CustomerViewHolder extends RecyclerView.ViewHolder {
        TextView customerName;
        TextView customerPhone;
        ImageButton editButton;
        ImageButton deleteButton;

        public CustomerViewHolder(@NonNull View itemView) {
            super(itemView);
            customerName = itemView.findViewById(R.id.customerName);
            customerPhone = itemView.findViewById(R.id.customerPhone);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
