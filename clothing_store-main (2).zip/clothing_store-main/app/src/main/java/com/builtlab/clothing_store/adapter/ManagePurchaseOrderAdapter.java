package com.builtlab.clothing_store.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.ItemListOrderBinding;
import com.builtlab.clothing_store.enums.StatusOrder;
import com.builtlab.clothing_store.interfaces.ObjectListener;
import com.builtlab.clothing_store.model.Order;
import com.builtlab.clothing_store.model.PurchaseOrder;

import java.text.MessageFormat;
import java.util.List;

public class ManagePurchaseOrderAdapter extends RecyclerView.Adapter<ManagePurchaseOrderAdapter.ViewHolder> {
    private Context context;
    private List<PurchaseOrder> purchaseOrders;
    private ObjectListener objectListener;

    public ManagePurchaseOrderAdapter(Context context, List<PurchaseOrder> purchaseOrders, ObjectListener objectListener) {
        this.context = context;
        this.purchaseOrders = purchaseOrders;
        this.objectListener = objectListener;
    }

    @NonNull
    @Override
    public ManagePurchaseOrderAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ManagePurchaseOrderAdapter.ViewHolder(ItemListOrderBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ManagePurchaseOrderAdapter.ViewHolder holder, int position) {
        holder.bind(purchaseOrders.get(position));
    }

    public void setList(List<PurchaseOrder> purchaseOrders) {
        this.purchaseOrders = purchaseOrders;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return purchaseOrders == null ? 0 : purchaseOrders.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ItemListOrderBinding binding;

        public ViewHolder(@NonNull ItemListOrderBinding itemView) {
            super(itemView.getRoot());
            this.binding = itemView;
        }

        private void bind(PurchaseOrder purchaseOrder) {
            binding.orderId.setText(MessageFormat.format("#{0}", purchaseOrder.getPurchaseOrderId()));
            binding.date.setText(purchaseOrder.getOrderDate());
            setOrderStatus(StatusOrder.fromString(purchaseOrder.getStatus().toUpperCase()));
            binding.totalAmount.setText(MessageFormat.format("{0} VNĐ", purchaseOrder.getTotalAmount()));
            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    objectListener.onClick(purchaseOrder);
                }
            });
        }

        private void setOrderStatus(StatusOrder status) {
            switch (status) {
                case SUCCESS: {
                    binding.orderStatus.setText(R.string.paid);
                    binding.orderStatus.setTextColor(ContextCompat.getColor(context, R.color.green));
                    break;
                }
                case FAILED: {
                    binding.orderStatus.setText(R.string.unpaid);
                    binding.orderStatus.setTextColor(ContextCompat.getColor(context, R.color.red));
                    break;
                }
                case PENDING:
                default: {
                    binding.orderStatus.setText(R.string.pending);
                    binding.orderStatus.setTextColor(ContextCompat.getColor(context, R.color.grey));
                    break;
                }
            }
        }

    }
}


