package com.builtlab.clothing_store.helper.query;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.Order;
import com.builtlab.clothing_store.model.Product;
import com.builtlab.clothing_store.model.Promotion;

import java.util.ArrayList;
import java.util.List;

public class ProductDatabaseQuery extends DatabaseQuery<Product> {
    private static final String TABLE_NAME = AppTableData.TABLE_PRODUCT;

    public ProductDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "ProductID";
    }

    @Override
    protected ContentValues getContentValues(Product product) {
        ContentValues values = new ContentValues();
//        values.put("ProductID", product.getProductId());
        values.put("ProductName", product.getProductName());
        values.put("CategoryID", product.getCategoryId());
        values.put("Price", product.getPrice());
        values.put("Description", product.getDescription());
        values.put("Images", String.join("|", product.getImages()));
        values.put("Sizes", String.join("|", product.getSizes()));
        values.put("StockQuantity", product.getStockQuantity());
        return values;
    }

    @Override
    protected Product cursorToItem(Cursor cursor) {
        Product product = new Product();
        product.setProductId((int) cursor.getLong(cursor.getColumnIndexOrThrow("ProductID")));
        product.setProductName(cursor.getString(cursor.getColumnIndexOrThrow("ProductName")));
        product.setCategoryId((int) cursor.getLong(cursor.getColumnIndexOrThrow("CategoryID")));
        product.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("Price")));
        product.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("Description")));
        product.setImages(cursor.getString(cursor.getColumnIndexOrThrow("Images")).split("\\|"));
        product.setSizes(cursor.getString(cursor.getColumnIndexOrThrow("Sizes")).split("\\|"));
        product.setStockQuantity(cursor.getInt(cursor.getColumnIndexOrThrow("StockQuantity")));
        return product;
    }

    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                products.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return products;
    }

    public long addProduct(Product product) {
        long id = -1;
        try {
            open();
            id = insert(product);
            if (id == -1) {
                Log.e(TAG, "Failed to insert row for promotion: " + product.toString());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error inserting promotion", e);
        } finally {
            close();
        }
        return id;
    }

    public void updateProduct(Product product) {
        try {
            open();
            update(product.getProductId(), product);
        } catch (Exception e) {
            Log.e(TAG, "Error updating promotion", e);
        } finally {
            close();
        }
    }

    public Product getProductById(long id) {
        open();
        Product product = getItem(id, "ProductID");
        close();
        return product;
    }

    public void deleteProduct(long productId) {
        try {
            open();
            delete(productId);
            Log.e("Test delete", "Delete thanh cong");
        } catch (Exception e) {
            Log.e("Test delete", "Error deleting product", e);
        } finally {
            close();
        }
    }

    public int updatePurchaseProductStock(long id, int quantityUsed) {
        try {
            open();
            Product product = getProductById(id);
            Log.d("updateProductStock", "Product ID: " + id + ", Quantity Used: " + quantityUsed);
            int result = 0;
            if (product != null) {
                Log.d("updateProductStock", "Current Stock: " + product.getStockQuantity());
                int newStockQuantity = product.getStockQuantity() + quantityUsed;
                if (newStockQuantity < 0) {
                    newStockQuantity = 0;
                }
                product.setStockQuantity(newStockQuantity);
                Log.d("updateProductStock", "New Stock: " + newStockQuantity);
                open();
                result = update(id, product);
                Log.d("updateProductStock", "Success: " + result);
            } else {
                Log.e("updateProductStock", "Product not found with ID: " + id);
            }
            close();
            return result;
        } catch (Exception e) {
            Log.e("updateProductStock", "Error updating product stock: " + e.getMessage());
        }
        return -1;
    }

    public int updateProductStock(long id, int quantityUsed) {
        try {
            open();
            Product product = getProductById(id);
            Log.d("updateProductStock", "Product ID: " + id + ", Quantity Used: " + quantityUsed);
            int result = 0;
            if (product != null) {
                Log.d("updateProductStock", "Current Stock: " + product.getStockQuantity());
                int newStockQuantity = product.getStockQuantity() - quantityUsed;
                if (newStockQuantity < 0) {
                    newStockQuantity = 0;
                }
                product.setStockQuantity(newStockQuantity);
                Log.d("updateProductStock", "New Stock: " + newStockQuantity);
                open();
                result = update(id, product);
                Log.d("updateProductStock", "Success: " + result);
            } else {
                Log.e("updateProductStock", "Product not found with ID: " + id);
            }
            close();
            return result;
        } catch (Exception e) {
            Log.e("updateProductStock", "Error updating product stock: " + e.getMessage());
        }
        return -1;
    }

    public int getTotalSoldByCategoryId(int categoryId) {
        int totalSold = 0;
        open();
        Cursor cursor = null;
        try {
            String query = "SELECT SUM(od.Quantity) AS TotalSold " +
                    "FROM ORDER_DETAIL od " +
                    "JOIN PRODUCT p ON od.ProductID = p.ProductID " +
                    "JOIN CATEGORY c ON p.CategoryID = c.CategoryID " +
                    "WHERE c.CategoryID = ? " +
                    "GROUP BY c.CategoryID";
            cursor = rawQuery(query, new String[]{String.valueOf(categoryId)});
            if (cursor.moveToFirst()) {
                totalSold = cursor.getInt(cursor.getColumnIndexOrThrow("TotalSold"));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error querying total sold by category ID", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            close();
        }
        return totalSold;
    }

    public int getTotalBuyByCategoryId(int categoryId) {
        int totalSold = 0;
        open();
        Cursor cursor = null;
        try {
            String query = "SELECT SUM(od.Quantity) AS TotalSold " +
                    "FROM PURCHASE_ORDER_DETAIL od " +
                    "JOIN PRODUCT p ON od.ProductID = p.ProductID " +
                    "JOIN CATEGORY c ON p.CategoryID = c.CategoryID " +
                    "WHERE c.CategoryID = ? " +
                    "GROUP BY c.CategoryID";
            cursor = rawQuery(query, new String[]{String.valueOf(categoryId)});
            if (cursor.moveToFirst()) {
                totalSold = cursor.getInt(cursor.getColumnIndexOrThrow("TotalSold"));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error querying total sold by category ID", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            close();
        }
        return totalSold;
    }

    public int getProductCountByCategoryId(int categoryId) {
        int productCount = 0;
        open();
        Cursor cursor = null;
        try {
            String query = "SELECT COUNT(*) AS ProductCount " +
                    "FROM " + TABLE_NAME + " " +
                    "WHERE CategoryID = ?";
            cursor = rawQuery(query, new String[]{String.valueOf(categoryId)});
            if (cursor.moveToFirst()) {
                productCount = cursor.getInt(cursor.getColumnIndexOrThrow("ProductCount"));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error querying product count by category ID", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            close();
        }
        return productCount;
    }
    public List<Product> searchProductsByName(String query) {
        List<Product> products = new ArrayList<>();
        open();
        String sql = "SELECT * FROM " + TABLE_NAME + " WHERE ProductName LIKE ?";
        Cursor cursor = rawQuery(sql, new String[]{"%" + query + "%"});
        if (cursor.moveToFirst()) {
            do {
                products.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return products;
    }
}
