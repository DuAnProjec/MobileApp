package com.builtlab.clothing_store.helper.query;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.Customer;
import com.builtlab.clothing_store.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CustomerDatabaseQuery extends DatabaseQuery<Customer> {
    private static final String TABLE_NAME = AppTableData.TABLE_CUSTOMER;

    public CustomerDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "CustomerID";
    }

    @Override
    protected ContentValues getContentValues(Customer customer) {
        ContentValues values = new ContentValues();
//        values.put("CustomerID", customer.getCustomerId());
        values.put("CustomerName", customer.getCustomerName());
        values.put("PhoneNumber", customer.getPhoneNumber());
        values.put("Email", customer.getEmail());
        values.put("Address", customer.getAddress());
        return values;
    }

    @Override
    protected Customer cursorToItem(Cursor cursor) {
        Customer customer = new Customer();
        customer.setCustomerId((int) cursor.getLong(cursor.getColumnIndexOrThrow("CustomerID")));
        customer.setCustomerName(cursor.getString(cursor.getColumnIndexOrThrow("CustomerName")));
        customer.setPhoneNumber(cursor.getString(cursor.getColumnIndexOrThrow("PhoneNumber")));
        customer.setEmail(cursor.getString(cursor.getColumnIndexOrThrow("Email")));
        customer.setAddress(cursor.getString(cursor.getColumnIndexOrThrow("Address")));
        return customer;
    }

    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                customers.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return customers;
    }


    public Customer getCustomerById(long id) {
        open();
        Customer customer = getItem(id, "CustomerID");
        close();
        return customer;
    }

    public long addCustomer(Customer customer) {
        long id = -1;
        try {
            open();
            id = insert(customer);
            if (id == -1) {
                Log.e(TAG, "Failed to insert row for customer: " + customer.toString());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error inserting customer", e);
        } finally {
            close();
        }
        return id;
    }

    public void updateCustomer(Customer customer) {
        try {
            open();
            update(customer.getCustomerId(), customer);
        } catch (Exception e) {
            Log.e(TAG, "Error updating customer", e);
        } finally {
            close();
        }
    }

    public void deleteCustomer(long customerId) {
        try {
            open();
            delete(customerId);
        } catch (Exception e) {
            Log.e(TAG, "Error deleting customer", e);
        } finally {
            close();
        }
    }
}

