package com.builtlab.clothing_store.adapter;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.ItemProductBinding;
import com.builtlab.clothing_store.databinding.ItemProductCheckoutBinding;
import com.builtlab.clothing_store.helper.query.ProductDatabaseQuery;
import com.builtlab.clothing_store.interfaces.ObjectListener;
import com.builtlab.clothing_store.model.OrderDetail;
import com.builtlab.clothing_store.model.Product;
import com.builtlab.clothing_store.ui.activity.CreateOrderActivity;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

public class OrderDetailAdapter extends RecyclerView.Adapter<OrderDetailAdapter.ViewHolder> {
    private Context context;
    private List<OrderDetail> orderDetails;
    private ObjectListener<OrderDetail> onChangeQuantity;
    private ObjectListener<OrderDetail> onDeleteProduct;

    public OrderDetailAdapter(Context context, List<OrderDetail> orderDetails, ObjectListener<OrderDetail> onChangeQuantity, ObjectListener<OrderDetail> onDeleteProduct) {
        this.context = context;
        this.orderDetails = orderDetails;
        this.onChangeQuantity = onChangeQuantity;
        this.onDeleteProduct = onDeleteProduct;
    }

    public void setList(List<OrderDetail> orderDetails) {
        this.orderDetails = orderDetails;
        notifyDataSetChanged();
    }

    public void setItem(OrderDetail orderDetail, int position) {
        this.orderDetails.set(position, orderDetail);
        notifyItemInserted(position);
    }

    public void deleteItem(int position) {
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, orderDetails.size());
        this.orderDetails.remove(position);
    }

    @NonNull
    @Override
    public OrderDetailAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new OrderDetailAdapter.ViewHolder(ItemProductCheckoutBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull OrderDetailAdapter.ViewHolder holder, int position) {
        holder.setData(orderDetails.get(position));

    }

    @Override
    public int getItemCount() {
        return orderDetails == null ? 0 : orderDetails.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ItemProductCheckoutBinding binding;

        public ViewHolder(ItemProductCheckoutBinding itemProductCheckoutBinding) {
            super(itemProductCheckoutBinding.getRoot());
            this.binding = itemProductCheckoutBinding;
        }


        private void setData(OrderDetail orderDetail) {
            ProductDatabaseQuery productDatabaseQuery = new ProductDatabaseQuery(context);
            productDatabaseQuery.open();

            Product product = productDatabaseQuery.getProductById(orderDetail.getProductId());
            if (product != null) {
                Log.d("CreateOrderActivity", "Product retrieved: " + product.toString());
                binding.productName.setText(product.getProductName());
            } else {
                Log.e("CreateOrderActivity", "Product not found");
            }

            productDatabaseQuery.close();

            binding.productSize.setText(orderDetail.getSize());
            binding.groupQuantity.textQuantity.setText(String.valueOf(orderDetail.getQuantity()));

            setEventChangeQuantityButton(product, orderDetail, onChangeQuantity);

            binding.btnDelete.setOnClickListener(v -> {
                onDeleteProduct.onClick(orderDetail);
            });


        }


        private void setEventChangeQuantityButton(Product product, OrderDetail orderDetail, ObjectListener<OrderDetail> onChangeQuantity) {
            TextWatcher textWatcher = new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    // Code to execute before text is changed
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    // Code to execute when text is changing
                    // Handle the change here
                    String quantity = s.toString();
                    // Do something with the changing quantity
                }

                @Override
                public void afterTextChanged(Editable s) {
                    // Code to execute after text has been changed
                    // Handle the final text change here
                    String quantity = s.toString();
                    if (!quantity.isEmpty()) {
                        int quantityValue = Integer.parseInt(quantity);
                        if (quantityValue > product.getStockQuantity()) {
                            // Temporarily remove the TextWatcher
                            binding.groupQuantity.textQuantity.removeTextChangedListener(this);
                            // Set the text to the max stock quantity
                            binding.groupQuantity.textQuantity.setText(MessageFormat.format("{0}", product.getStockQuantity()));
                            // Set the cursor position at the end
                            binding.groupQuantity.textQuantity.setSelection(binding.groupQuantity.textQuantity.getText().length());
                            // Re-add the TextWatcher
                            binding.groupQuantity.textQuantity.addTextChangedListener(this);
                        } else if (quantityValue <= 0) {
                            // Temporarily remove the TextWatcher
                            binding.groupQuantity.textQuantity.removeTextChangedListener(this);
                            // Set the text to "0"
                            binding.groupQuantity.textQuantity.setText("0");
                            // Set the cursor position at the end
                            binding.groupQuantity.textQuantity.setSelection(binding.groupQuantity.textQuantity.getText().length());
                            // Re-add the TextWatcher
                            binding.groupQuantity.textQuantity.addTextChangedListener(this);
                        }
                        orderDetail.setQuantity(quantityValue);
                        onChangeQuantity.onClick(orderDetail);
                    }
                    // Do something with the final quantity
                }
            };

            binding.groupQuantity.textQuantity.addTextChangedListener(textWatcher);
            binding.groupQuantity.textQuantity.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        // Code to execute when "Done" is pressed
                        // You can handle the final input here
                        // For example, get the text and do something with it
                        String quantity = binding.groupQuantity.textQuantity.getText().toString();

                        if (!quantity.isEmpty() && Integer.parseInt(quantity) > product.getStockQuantity()) {
                            // Temporarily remove the TextWatcher
                            binding.groupQuantity.textQuantity.removeTextChangedListener(textWatcher);
                            // Set the text to the max stock quantity
                            binding.groupQuantity.textQuantity.setText(MessageFormat.format("{0}", product.getStockQuantity()));
                            // Set the cursor position at the end
                            binding.groupQuantity.textQuantity.setSelection(binding.groupQuantity.textQuantity.getText().length());
                            // Re-add the TextWatcher
                            binding.groupQuantity.textQuantity.addTextChangedListener(textWatcher);

                            orderDetail.setQuantity(product.getStockQuantity());
                            onChangeQuantity.onClick(orderDetail);
                        }
                        // Hide the keyboard
                        InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                        return true; // Return true to indicate the action was handled
                    }
                    return false;
                }
            });

            binding.groupQuantity.buttonAddQuantity.setOnClickListener(v -> {
                Log.d("CreateOrderActivity", String.valueOf(binding.groupQuantity.textQuantity.getText()));
                int currentQuantity = Integer.parseInt(String.valueOf(binding.groupQuantity.textQuantity.getText()));
                if (currentQuantity < product.getStockQuantity()) {
                    Log.d("CreateOrderActivity", String.valueOf(product.getStockQuantity()));
                    currentQuantity += 1;
                    // Temporarily remove the TextWatcher
                    binding.groupQuantity.textQuantity.removeTextChangedListener(textWatcher);
                    binding.groupQuantity.textQuantity.setText(MessageFormat.format("{0}", currentQuantity));
                    // Set the cursor position at the end
                    binding.groupQuantity.textQuantity.setSelection(binding.groupQuantity.textQuantity.getText().length());
                    // Re-add the TextWatcher
                    binding.groupQuantity.textQuantity.addTextChangedListener(textWatcher);
                    orderDetail.setQuantity(currentQuantity);
                    onChangeQuantity.onClick(orderDetail);
                } else {
                    Toast.makeText(context, "Out of Stock", Toast.LENGTH_SHORT).show();
                }
            });

            binding.groupQuantity.buttonSubtractQuantity.setOnClickListener(v -> {
                String quantityText = Objects.requireNonNull(binding.groupQuantity.textQuantity.getText()).toString();
                int currentQuantity = quantityText.isEmpty() ? 0 : Integer.parseInt(quantityText);
                if (currentQuantity > 1) {
                    currentQuantity -= 1;
                    // Temporarily remove the TextWatcher
                    binding.groupQuantity.textQuantity.removeTextChangedListener(textWatcher);
                    binding.groupQuantity.textQuantity.setText(MessageFormat.format("{0}", currentQuantity));
                    // Set the cursor position at the end
                    binding.groupQuantity.textQuantity.setSelection(binding.groupQuantity.textQuantity.getText().length());
                    // Re-add the TextWatcher
                    binding.groupQuantity.textQuantity.addTextChangedListener(textWatcher);
                    orderDetail.setQuantity(currentQuantity);
                    onChangeQuantity.onClick(orderDetail);
                } else {
                    Toast.makeText(context, "Out of Stock", Toast.LENGTH_SHORT).show();
                }
            });
        }

        private int getImageResourceId(Context context, String imageName) {
            return context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        }
    }

}
