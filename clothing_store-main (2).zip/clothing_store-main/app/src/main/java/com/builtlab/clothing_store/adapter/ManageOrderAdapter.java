package com.builtlab.clothing_store.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.ItemListOrderBinding;
import com.builtlab.clothing_store.enums.StatusOrder;
import com.builtlab.clothing_store.interfaces.ObjectListener;
import com.builtlab.clothing_store.model.Order;

import java.text.MessageFormat;
import java.util.List;

public class ManageOrderAdapter extends RecyclerView.Adapter<ManageOrderAdapter.ViewHolder> {
    private Context context;
    private List<Order> orders;
    private ObjectListener objectListener;

    public ManageOrderAdapter(Context context, List<Order> orders, ObjectListener objectListener) {
        this.context = context;
        this.orders = orders;
        this.objectListener = objectListener;
    }

    @NonNull
    @Override
    public ManageOrderAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ManageOrderAdapter.ViewHolder(ItemListOrderBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ManageOrderAdapter.ViewHolder holder, int position) {
        holder.bind(orders.get(position));
    }

    public void setList(List<Order> orders) {
        this.orders = orders;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return orders == null ? 0 : orders.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ItemListOrderBinding binding;

        public ViewHolder(@NonNull ItemListOrderBinding itemView) {
            super(itemView.getRoot());
            this.binding = itemView;
        }

        private void bind(Order order) {
            binding.orderId.setText(MessageFormat.format("#{0}", order.getOrderId()));
            binding.date.setText(order.getOrderDate());
            setOrderStatus(StatusOrder.fromString(order.getStatus().toUpperCase()));
            binding.totalAmount.setText(MessageFormat.format("{0} VNĐ", order.getTotalAmount()));
            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    objectListener.onClick(order);
                }
            });
        }

        private void setOrderStatus(StatusOrder status) {
            switch (status) {
                case SUCCESS: {
                    binding.orderStatus.setText(R.string.paid);
                    binding.orderStatus.setTextColor(ContextCompat.getColor(context, R.color.green));
                    break;
                }
                case FAILED: {
                    binding.orderStatus.setText(R.string.unpaid);
                    binding.orderStatus.setTextColor(ContextCompat.getColor(context, R.color.red));
                    break;
                }
                case PENDING:
                default: {
                    binding.orderStatus.setText(R.string.pending);
                    binding.orderStatus.setTextColor(ContextCompat.getColor(context, R.color.grey));
                    break;
                }
            }
        }

    }
}


