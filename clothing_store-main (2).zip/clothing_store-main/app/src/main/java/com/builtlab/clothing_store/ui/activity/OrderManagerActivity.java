package com.builtlab.clothing_store.ui.activity;

import static com.builtlab.clothing_store.R.id.group_quantity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.adapter.ManageOrderAdapter;
import com.builtlab.clothing_store.adapter.ManagePurchaseOrderAdapter;
import com.builtlab.clothing_store.databinding.ActivityOrderManagerBinding;
import com.builtlab.clothing_store.enums.MethodManagement;
import com.builtlab.clothing_store.enums.StatusOrder;
import com.builtlab.clothing_store.helper.query.OrderDatabaseQuery;
import com.builtlab.clothing_store.helper.query.PurchaseOrderDatabaseQuery;
import com.builtlab.clothing_store.interfaces.ObjectListener;
import com.builtlab.clothing_store.model.Order;
import com.builtlab.clothing_store.model.OrderDetail;
import com.builtlab.clothing_store.model.Product;
import com.builtlab.clothing_store.model.PurchaseOrder;
import com.builtlab.clothing_store.model.PurchaseOrderDetail;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OrderManagerActivity extends AppCompatActivity {
    private ActivityOrderManagerBinding binding;
    private MethodManagement methodManagement = null;
    private ManageOrderAdapter manageOrderAdapter;
    private ManagePurchaseOrderAdapter managePurchaseOrderAdapter;
    private Dialog dialog;
    boolean isPay = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_order_manager);
        binding = ActivityOrderManagerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        init();
    }

    private void init() {
        initAppBar();
        initEvent();
        initAdapter();
        initData();
    }


    @Override
    protected void onResume() {
        super.onResume();
        initData();
    }

    private void initAdapter() {

        switch (methodManagement) {
            case ORDER: {
                manageOrderAdapter = new ManageOrderAdapter(getApplicationContext(), Collections.emptyList(), new ObjectListener() {
                    @Override
                    public void onClick(Object o) {
                        showBottomSheetOrder((Order) o);
                    }
                });

                LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
                binding.recycleViewListOrder.setAdapter(manageOrderAdapter);
                binding.recycleViewListOrder.setLayoutManager(layoutManager);
                break;
            }
            case PURCHASE:
            default: {
                managePurchaseOrderAdapter = new ManagePurchaseOrderAdapter(getApplicationContext(), Collections.emptyList(), new ObjectListener() {
                    @Override
                    public void onClick(Object o) {
                        showBottomSheetPurchaseOrder((PurchaseOrder) o);
                    }
                });

                LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
                binding.recycleViewListOrder.setAdapter(managePurchaseOrderAdapter);
                binding.recycleViewListOrder.setLayoutManager(layoutManager);
                break;
            }
        }

    }

    private void initData() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(new Runnable() {
            @Override
            public void run() {
                switch (methodManagement) {
                    case ORDER: {
                        OrderDatabaseQuery orderDatabaseQuery = new OrderDatabaseQuery(getApplicationContext());
                        orderDatabaseQuery.open();

                        List<Order> orders = orderDatabaseQuery.getAllOrders();
                        Collections.reverse(orders);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (orders != null) {
                                    Log.d("LoginActivity", "Order retrieved: " + orders.toString());
                                    manageOrderAdapter.setList(orders);
                                } else {
                                    Log.e("LoginActivity", "Order not found");
                                }
                                executor.shutdown();  // Shut down the executor service
                            }
                        });
                        break;
                    }
                    case PURCHASE:
                    default: {
                        PurchaseOrderDatabaseQuery purchaseOrderDatabaseQuery = new PurchaseOrderDatabaseQuery(getApplicationContext());
                        purchaseOrderDatabaseQuery.open();

                        List<PurchaseOrder> purchaseOrders = purchaseOrderDatabaseQuery.getAllPurchaseOrders();
                        Collections.reverse(purchaseOrders);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (purchaseOrders != null) {
                                    Log.d("LoginActivity", "Order retrieved: " + purchaseOrders.toString());
                                    managePurchaseOrderAdapter.setList(purchaseOrders);
                                } else {
                                    Log.e("LoginActivity", "Order not found");
                                }
                                executor.shutdown();  // Shut down the executor service
                            }
                        });
                        break;
                    }
                }

            }
        });


    }

    private void initEvent() {
        binding.buttonCreateNewOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OrderManagerActivity.this, CreateOrderActivity.class);
                intent.putExtra("methodManagement", methodManagement.toStringValue());
                startActivity(intent);
            }
        });
    }

    private void initAppBar() {
        if (getIntent() != null && getIntent().hasExtra("methodManagement")) {
            methodManagement = MethodManagement.fromString(getIntent().getStringExtra("methodManagement"));
        }
        binding.customAppBar.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        if (methodManagement != null) {
            switch (methodManagement) {
                case PURCHASE: {
                    binding.customAppBar.appBarTitle.setText(R.string.list_purchase);
                    binding.textViewCreateNewOrder.setText(R.string.create_new_purchase_order_button);
                    break;
                }
                case ORDER:
                default: {
                    binding.customAppBar.appBarTitle.setText(R.string.list_order);
                    binding.textViewCreateNewOrder.setText(R.string.create_new_order_button);
                    break;
                }
            }
        }
    }

    private void showBottomSheetOrder(Order order) {
        isPay = order.getStatus().equals(StatusOrder.SUCCESS.toStringValue());


        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.bottom_sheet_change_status_order);

        TextView total = dialog.findViewById(R.id.price);
        Chip chipPay = dialog.findViewById(R.id.chip_paid);
        Chip chipUnPay = dialog.findViewById(R.id.chip_unpaid);
        Button saveButton = dialog.findViewById(R.id.btn_save_change);

        if(isPay) {
            chipPay.setChecked(true);
            chipUnPay.setChecked(false);
        } else {
            chipUnPay.setChecked(true);
            chipPay.setChecked(false);
        }

        total.setText(String.valueOf(order.getTotalAmount()));
        chipPay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isPay = true;
                } else {
                    isPay = false;
                    chipUnPay.setChecked(true);
                }
            }
        });
        chipUnPay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isPay = false;
                } else {
                    isPay = true;
                    chipPay.setChecked(true);
                }
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ExecutorService executor = Executors.newSingleThreadExecutor();
                Handler handler = new Handler(Looper.getMainLooper());
                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        OrderDatabaseQuery orderDatabaseQuery = new OrderDatabaseQuery(getApplicationContext());
                        orderDatabaseQuery.open();
                        order.setStatus(isPay ? StatusOrder.SUCCESS.toStringValue() : StatusOrder.PENDING.toStringValue());
                        orderDatabaseQuery.update(order.getOrderId(), order);
                        orderDatabaseQuery.close();
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                initData();
                                dialog.dismiss();
                            }
                        });
                    }
                });

            }
        });


        dialog.show();

        Objects.requireNonNull(dialog.getWindow()).setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setGravity(Gravity.BOTTOM);
    }

    private void showBottomSheetPurchaseOrder(PurchaseOrder purchaseOrder) {
        isPay = purchaseOrder.getStatus().equals(StatusOrder.SUCCESS.toStringValue());
        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.bottom_sheet_change_status_order);

        TextView total = dialog.findViewById(R.id.price);
        Chip chipPay = dialog.findViewById(R.id.chip_paid);
        Chip chipUnPay = dialog.findViewById(R.id.chip_unpaid);
        Button saveButton = dialog.findViewById(R.id.btn_save_change);

        if(isPay) {
            chipPay.setChecked(true);
            chipUnPay.setChecked(false);
        } else {
            chipUnPay.setChecked(true);
            chipPay.setChecked(false);
        }

        total.setText(String.valueOf(purchaseOrder.getTotalAmount()));
        chipPay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isPay = true;
                } else {
                    isPay = false;
                    chipUnPay.setChecked(true);
                }
            }
        });
        chipUnPay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isPay = false;
                } else {
                    isPay = true;
                    chipPay.setChecked(true);
                }
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ExecutorService executor = Executors.newSingleThreadExecutor();
                Handler handler = new Handler(Looper.getMainLooper());
                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        PurchaseOrderDatabaseQuery purchaseOrderDatabaseQuery = new PurchaseOrderDatabaseQuery(getApplicationContext());
                        purchaseOrderDatabaseQuery.open();
                        purchaseOrder.setStatus(isPay ? StatusOrder.SUCCESS.toStringValue() : StatusOrder.PENDING.toStringValue());
                        purchaseOrderDatabaseQuery.update(purchaseOrder.getPurchaseOrderId(), purchaseOrder);
                        purchaseOrderDatabaseQuery.close();
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                initData();
                                dialog.dismiss();
                            }
                        });
                    }
                });

            }
        });


        dialog.show();

        Objects.requireNonNull(dialog.getWindow()).setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setGravity(Gravity.BOTTOM);
    }
}