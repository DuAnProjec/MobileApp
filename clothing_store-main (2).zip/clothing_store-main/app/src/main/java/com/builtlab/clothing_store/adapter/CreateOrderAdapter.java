package com.builtlab.clothing_store.adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.ItemProductBinding;
import com.builtlab.clothing_store.interfaces.ObjectListener;
import com.builtlab.clothing_store.model.Product;

import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.List;

public class CreateOrderAdapter extends RecyclerView.Adapter<CreateOrderAdapter.ViewHolder> {
    private Context context;
    private List<Product> products;
    private ObjectListener objectListener;

    public CreateOrderAdapter(Context context, List<Product> products, ObjectListener objectListener) {
        this.context = context;
        this.products = products;
        this.objectListener = objectListener;
    }

    public void setList(List<Product> products) {
        this.products = products;
//        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CreateOrderAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CreateOrderAdapter.ViewHolder(ItemProductBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CreateOrderAdapter.ViewHolder holder, int position) {
        holder.setData(products.get(position));

    }

    @Override
    public int getItemCount() {
        return products == null ? 0 : products.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ItemProductBinding binding;

        public ViewHolder(ItemProductBinding itemProductBinding) {
            super(itemProductBinding.getRoot());
            this.binding = itemProductBinding;
        }

        private void setData(Product product) {
            binding.productName.setText(product.getProductName());
            binding.productPrice.setText(MessageFormat.format("{0} VNĐ", String.valueOf(product.getPrice())));

            String[] images = product.getImages();
            if (images.length > 0) {
                Uri imageUri = Uri.parse(images[0]);
                try {
                    context.getContentResolver().takePersistableUriPermission(imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (SecurityException e) {
                    e.printStackTrace();
                }

                try (InputStream inputStream = context.getContentResolver().openInputStream(imageUri)) {
                    if (inputStream != null) {
                        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                        binding.productImage.setImageBitmap(bitmap);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

//            binding.productImage.setImageResource(getImageResourceId(context, product.getImages()[0]));
//            binding.productImage.setImageResource(R.drawable.ic_voucher);
            binding.addProductButton.setOnClickListener(v -> {
                        objectListener.onClick(product);
                    }
            );
        }

        private int getImageResourceId(Context context, String imageName) {
            return context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        }
    }

}
