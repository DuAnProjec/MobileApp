package com.builtlab.clothing_store.constants;

public class AppString {
    public static final String APP_NAME = "CLOTHIO";
    public static final String APP_VERSION = "1.0";
    public static final String APP_AUTHOR = "UIT";
    public static final String APP_DESCRIPTION = "CLOTHIO";
    public static final String KEY_PREFERENCE_NAME = "CLOTHING_PREF";

}
