package com.builtlab.clothing_store.enums;

public enum MethodManagement {
    ORDER,
    PURCHASE;

    public String toStringValue() {
        return this.name();
    }

    public static MethodManagement fromString(String value) {
        if (value == null) {
            throw new IllegalArgumentException("String value cannot be null");
        }
        return MethodManagement.valueOf(value);
    }

    public boolean equals(String value) {
        if (value == null) {
            return false;
        }
        return this.name().equals(value.toUpperCase());
    }
}

