package com.builtlab.clothing_store.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.model.Promotion;
import com.builtlab.clothing_store.ui.activity.CreateVoucherActivity;
import com.builtlab.clothing_store.helper.query.PromotionDatabaseQuery;

import java.util.List;

public class VoucherAdapter extends RecyclerView.Adapter<VoucherAdapter.VoucherViewHolder> {

    private final List<Promotion> promotions;
    private final Context context;

    public VoucherAdapter(Context context, List<Promotion> promotions) {
        this.context = context;
        this.promotions = promotions;
    }

    @NonNull
    @Override
    public VoucherViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_voucher, parent, false);
        return new VoucherViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VoucherViewHolder holder, int position) {
        Promotion promotion = promotions.get(position);
        holder.tvVoucherName.setText(promotion.getPromotionName());
        holder.tvVoucherExpiry.setText("HSD: " + promotion.getEndDate());
        holder.tvVoucherDescription.setText(promotion.getDescription());
        holder.tvVoucherDetails.setText(promotion.getDiscountPercentage() + "% giảm giá cho đơn lớn hơn " + promotion.getMinimumOrderAmount() + "k");

        holder.btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(context, CreateVoucherActivity.class);
            intent.putExtra("promotion", promotion);
            context.startActivity(intent);
        });

        holder.btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Xóa Voucher")
                    .setMessage("Bạn có chắc chắn muốn xóa voucher này?")
                    .setPositiveButton("Có", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            PromotionDatabaseQuery promotionDbQuery = new PromotionDatabaseQuery(context);
                            promotionDbQuery.deletePromotion(promotion.getPromotionId());
                            promotions.remove(position);
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, promotions.size());
                        }
                    })
                    .setNegativeButton("Không", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return promotions.size();
    }

    public static class VoucherViewHolder extends RecyclerView.ViewHolder {

        TextView tvVoucherName, tvVoucherExpiry, tvVoucherDescription, tvVoucherDetails;
        ImageButton btnEdit, btnDelete;

        public VoucherViewHolder(@NonNull View itemView) {
            super(itemView);
            tvVoucherName = itemView.findViewById(R.id.tvVoucherName);
            tvVoucherExpiry = itemView.findViewById(R.id.tvVoucherExpiry);
            tvVoucherDescription = itemView.findViewById(R.id.tvVoucherDescription);
            tvVoucherDetails = itemView.findViewById(R.id.tvVoucherDetails);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
