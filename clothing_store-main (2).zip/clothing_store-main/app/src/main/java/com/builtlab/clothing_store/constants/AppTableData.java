package com.builtlab.clothing_store.constants;

public class AppTableData {
    public static final String TABLE_CATEGORY = "CATEGORY";
    public static final String TABLE_ACCOUNT = "ACCOUNT";
    public static final String TABLE_PRODUCT = "PRODUCT";
    public static final String TABLE_CUSTOMER = "CUSTOMER";
    public static final String TABLE_ORDER = "ORDERS";
    public static final String TABLE_ORDER_DETAIL = "ORDER_DETAIL";
    public static final String TABLE_PROMOTION = "PROMOTION";
    public static final String TABLE_SUPPLIER = "SUPPLIER";
    public static final String TABLE_PURCHASE_ORDER = "PURCHASE_ORDER";
    public static final String TABLE_PURCHASE_ORDER_DETAIL = "PURCHASE_ORDER_DETAIL";
    public static final String TABLE_BUSINESS_PLAN = "BUSINESS_PLAN";
    public static final String TABLE_BUSINESS_PLAN_TARGET = "BUSINESS_PLAN_TARGET";
}
