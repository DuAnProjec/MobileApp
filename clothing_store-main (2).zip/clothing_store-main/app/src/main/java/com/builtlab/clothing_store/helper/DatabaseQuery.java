package com.builtlab.clothing_store.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public abstract class DatabaseQuery<T> {
    private SQLiteDatabase db;
    private DatabaseHandler dbHelper;

    public DatabaseQuery(Context context) {
        dbHelper = new DatabaseHandler(context);
    }

    protected abstract String getTableName();
    protected abstract String getTablePrimaryKey();

    protected abstract ContentValues getContentValues(T item);

    protected abstract T cursorToItem(Cursor cursor);

    public void open() {
        db = dbHelper.getWritableDatabase();
    }

    protected SQLiteDatabase getDatabase() {
        return dbHelper.getReadableDatabase();
    }
    public void close() {
        dbHelper.close();
    }

    public long insert(T item) {
        ContentValues values = getContentValues(item);
        return db.insert(getTableName(), null, values);
    }

    public int update(long id, T item) {
        ContentValues values = getContentValues(item);
        String selection = getTablePrimaryKey() + " = ?";
        String[] selectionArgs = {String.valueOf(id)};
        return db.update(getTableName(), values, selection, selectionArgs);
    }

    public int delete(long id) {
        String selection = getTablePrimaryKey() + " = ?";
        String[] selectionArgs = {String.valueOf(id)};
        return db.delete(getTableName(), selection, selectionArgs);
    }

    public Cursor getAll() {
        Cursor cursor = db.query(
                getTableName(),
                null,
                null,
                null,
                null,
                null,
                null);

        return cursor;
    }

    public T getItem(long id, String param) {
        String selection = param + " = ?";
        String[] selectionArgs = {String.valueOf(id)};
        Cursor cursor = db.query(
                getTableName(),
                null,
                selection,
                selectionArgs,
                null,
                null,
                null);
        cursor.moveToFirst();
        T item = cursorToItem(cursor);
        cursor.close();
        return item;
    }

    public Cursor getItemsByColumn(String column, String value) {
        String selection = column + " = ?";
        String[] selectionArgs = {value};
        return db.query(getTableName(), null, selection, selectionArgs, null, null, null);
    }

    public Cursor getItemsByCondition(String selection, String[] selectionArgs) {
        return db.query(getTableName(), null, selection, selectionArgs, null, null, null);
    }

    public Cursor rawQuery(String query, String[] selectionArgs) {
        return db.rawQuery(query, selectionArgs);
    }
}
