package com.builtlab.clothing_store.ui.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.adapter.PreviewImageDetailAdapter;
import com.builtlab.clothing_store.databinding.ActivityProductDetailBinding;
import com.builtlab.clothing_store.interfaces.ObjectListener;
import com.builtlab.clothing_store.model.Product;

import java.util.ArrayList;
import java.util.List;

public class ProductDetailActivity extends AppCompatActivity {

    private ActivityProductDetailBinding binding;
    private PreviewImageDetailAdapter previewImageDetailAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProductDetailBinding.inflate(getLayoutInflater());
        init();
        setContentView(binding.getRoot());
    }

    private void init() {
        initCustomAppBar();

        Intent intent = getIntent();
        if (intent.hasExtra("product")) {
            Product product = (Product) intent.getSerializableExtra("product");
            updateProductData(product);
        }
    }

    private void initCustomAppBar() {
        binding.customAppBar.buttonBack.setOnClickListener(v -> finish());
        binding.customAppBar.appBarTitle.setText("Chi tiết sản phẩm");
    }

    private void updateProductData(Product product) {
        binding.tvProductName.setText(product.getProductName());
        binding.tvPrice.setText(product.getPrice() + " VNĐ");
        binding.tvDesc.setText(product.getDescription());

        String[] images = product.getImages();
        if (images.length > 0) {
            Uri imageUri = Uri.parse(images[0]);

            List<Uri> uriList = new ArrayList<>();
            for (String imageUrl : images) {
                Uri uri = Uri.parse(imageUrl);
                uriList.add(uri);
            }
            previewImageDetailAdapter = new PreviewImageDetailAdapter(getApplicationContext(), uriList, s -> {
                Intent intent = new Intent(getApplicationContext(), PreviewImageActivity.class);
                intent.putExtra("url", s);
                startActivity(intent);
            });

            binding.imgProductImage.setVisibility(View.GONE);
            binding.recyclePreviewImage.setVisibility(View.VISIBLE);

            LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
            binding.recyclePreviewImage.setAdapter(previewImageDetailAdapter);
            binding.recyclePreviewImage.setLayoutManager(layoutManager);
        }

        GridLayout gridLayoutSizes = binding.gridLayoutSizes;
        gridLayoutSizes.removeAllViews();
        for (String size : product.getSizes()) {
            Button sizeButton = new Button(this, null, 0, R.style.CustomRadioButton);
            sizeButton.setText(size);

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = GridLayout.LayoutParams.WRAP_CONTENT;
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            params.setMargins(8, 8, 8, 8);
            gridLayoutSizes.addView(sizeButton, params);
        }

        switch (product.getCategoryId()) {
            case 1:
                binding.tvType.setText("Full set");
                break;
            case 2:
                binding.tvType.setText("Áo");
                break;
            case 3:
                binding.tvType.setText("Quần");
                break;
            case 4:
                binding.tvType.setText("Đầm/Váy");
                break;
        }
    }
}
