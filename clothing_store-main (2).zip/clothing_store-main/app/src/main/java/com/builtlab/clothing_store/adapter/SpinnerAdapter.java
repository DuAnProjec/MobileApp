package com.builtlab.clothing_store.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.builtlab.clothing_store.R;

import java.util.List;

public class SpinnerAdapter extends ArrayAdapter<String> {

    private Context context;
    private List<String> items;

    public SpinnerAdapter(Context context, List<String> items) {
        super(context, R.layout.item_custom_spinner, items);
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createView(position, convertView, parent);
    }

    private View createView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_custom_spinner, parent, false);
        }

        TextView textView = convertView.findViewById(R.id.spinner_text);
        textView.setText(items.get(position));

        return convertView;
    }
}

