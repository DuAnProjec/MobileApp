package com.builtlab.clothing_store.ui.activity;

import static com.builtlab.clothing_store.R.id.group_quantity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.adapter.CreateOrderAdapter;
import com.builtlab.clothing_store.databinding.ActivityCreateOrderBinding;
import com.builtlab.clothing_store.enums.MethodManagement;
import com.builtlab.clothing_store.helper.query.ProductDatabaseQuery;
import com.builtlab.clothing_store.interfaces.ObjectListener;
import com.builtlab.clothing_store.model.OrderDetail;
import com.builtlab.clothing_store.model.Product;
import com.builtlab.clothing_store.model.PurchaseOrderDetail;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CreateOrderActivity extends AppCompatActivity {
    private MethodManagement methodManagement = null;
    private Dialog dialog;
    private CreateOrderAdapter createOrderAdapter;
    private ActivityCreateOrderBinding binding;
    private int sumQuantityCart = 0;
    private List<OrderDetail> orderDetails;
    private List<PurchaseOrderDetail> purchaseOrderDetails;
    private String sizeSelected = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_create_order);
        binding = ActivityCreateOrderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        init();
    }

    private void init() {
        initCustomAppBar();
        initDefaultData();
        initAdapter();
        initEventComponent();
        fetchProducts();
    }

    private void initAdapter() {
        createOrderAdapter = new CreateOrderAdapter(getApplicationContext(), Collections.emptyList(), new ObjectListener() {
            @Override
            public void onClick(Object o) {
                showBottomSheetBuyProduct((Product) o);
            }
        });

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 2, GridLayoutManager.VERTICAL, false);
        gridLayoutManager.setSmoothScrollbarEnabled(true);
        binding.recycleViewCreateOrder.setLayoutManager(gridLayoutManager);
        binding.recycleViewCreateOrder.setAdapter(createOrderAdapter);
    }

    private void initData() {
        ProductDatabaseQuery productDatabaseQuery = new ProductDatabaseQuery(getApplicationContext());
        productDatabaseQuery.open();

        List<Product> products = productDatabaseQuery.getAllProducts();
        if (products != null) {
            Log.d("CreateOrderActivity", "Product retrieved: " + products.toString());
            createOrderAdapter.setList(products);
        } else {
            Log.e("CreateOrderActivity", "Product not found");
        }

        productDatabaseQuery.close();
    }

    public void fetchProducts() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(new Runnable() {
            @Override
            public void run() {
                ProductDatabaseQuery productDatabaseQuery = new ProductDatabaseQuery(getApplicationContext());
                List<Product> products = productDatabaseQuery.getAllProducts();

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (products != null) {
                            Log.d("CreateOrderActivity", "Products retrieved: " + products.stream().map(Object::toString));
//                            createOrderAdapter.setList(products);
                            updateOrderDetailsAdapter(products);

                        } else {
                            Log.e("CreateOrderActivity", "Products not found");
                        }
                        executor.shutdown();  // Shut down the executor service
                    }
                });
            }
        });
    }


    private void initEventComponent() {
        binding.btnCreateNewOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (methodManagement) {
                    case ORDER:{
                        if (orderDetails.isEmpty()) {
                            Toast.makeText(getApplicationContext(), "Please add product", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        OrderDetailActivity orderDetailActivity = new OrderDetailActivity();
                        Intent intent = new Intent(CreateOrderActivity.this, orderDetailActivity.getClass());
                        intent.putExtra("methodManagement", methodManagement.toStringValue());
                        intent.putParcelableArrayListExtra("orderDetails", (ArrayList<? extends Parcelable>) new ArrayList<>(orderDetails));
                        startActivity(intent);
                        break;
                    }
                    case PURCHASE:
                    default:{
                        if (purchaseOrderDetails.isEmpty()) {
                            Toast.makeText(getApplicationContext(), "Please add product", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        OrderDetailActivity orderDetailActivity = new OrderDetailActivity();
                        Intent intent = new Intent(CreateOrderActivity.this, orderDetailActivity.getClass());
                        intent.putExtra("methodManagement", methodManagement.toStringValue());
                        intent.putParcelableArrayListExtra("purchaseOrderDetails", (ArrayList<? extends Parcelable>) new ArrayList<>(purchaseOrderDetails));
                        startActivity(intent);
                        break;
                    }
                }

            }
        });
    }

    private void initDefaultData() {
        binding.cartQuantity.setText("0");
        binding.cartQuantity.setText(String.valueOf(sumQuantityCart));
        switch (methodManagement) {
            case ORDER: {
                binding.customAppBar.appBarTitle.setText(R.string.title_app_bar_create_order);
                binding.btnCreateNewOrder.setText(R.string.create_new_order_button);
                orderDetails = new ArrayList<>();
                break;
            }
            case PURCHASE:
            default: {
                binding.customAppBar.appBarTitle.setText(R.string.title_app_bar_create_purchase_order);
                binding.btnCreateNewOrder.setText(R.string.create_new_purchase_order_button);
                purchaseOrderDetails = new ArrayList<>();
                break;
            }
        }

    }

    private void initCustomAppBar() {
        if (getIntent() != null && getIntent().hasExtra("methodManagement")) {
            methodManagement = MethodManagement.fromString(getIntent().getStringExtra("methodManagement"));
        }
        binding.customAppBar.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



    }

    private void updateOrderDetailsAdapter(List<Product> products) {
        new Handler(Looper.getMainLooper()).post(() -> {
            createOrderAdapter.setList(products);
            createOrderAdapter.notifyDataSetChanged();
        });
    }

    private List<Product> getProducts() {
        List<Product> products = new ArrayList<>();

        products.add(new Product(1, "Áo thun", 1, 199.99, "Áo thun thời trang", new String[]{"sample_image"}, new String[]{"S", "M", "L"}, 100));
        products.add(new Product(2, "Quần jean", 2, 399.99, "Quần jean cao cấp", new String[]{"sample_image"}, new String[]{"M", "L"}, 50));
        products.add(new Product(3, "Áo sơ mi", 1, 299.99, "Áo sơ mi thanh lịch", new String[]{"sample_image"}, new String[]{"L", "XL"}, 80));
        products.add(new Product(4, "Giày thể thao", 3, 499.99, "Giày thể thao phong cách", new String[]{"sample_image"}, new String[]{"40", "41", "42"}, 200));
        products.add(new Product(5, "Túi xách", 4, 599.99, "Túi xách sang trọng", new String[]{"sample_image"}, new String[]{"One size"}, 70));
        products.add(new Product(6, "Đầm dạ hội", 5, 999.99, "Đầm dạ hội quyến rũ", new String[]{"sample_image"}, new String[]{"S", "M", "L", "XL"}, 30));
        products.add(new Product(7, "Full set", 1, 399.99, "Full set mùa đông", new String[]{"sample_image"}, new String[]{"M", "L", "XL"}, 60));
        products.add(new Product(8, "Mũ lưỡi trai", 6, 99.99, "Mũ lưỡi trai thời trang", new String[]{"sample_image"}, new String[]{"One size"}, 150));
        products.add(new Product(9, "Kính râm", 7, 299.99, "Kính râm phong cách", new String[]{"sample_image"}, new String[]{"One size"}, 40));
        products.add(new Product(10, "Đồng hồ", 8, 1999.99, "Đồng hồ đẳng cấp", new String[]{"sample_image"}, new String[]{"One size"}, 20));

        return products;
    }

    private int getImageResourceId(Context context, String imageName) {
        return context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
    }

    private void showBottomSheetBuyProduct(Product product) {
        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.bottom_sheet_add_product);

        TextView productPrice = dialog.findViewById(R.id.product_price);
        productPrice.setText(MessageFormat.format("{0} VNĐ", String.valueOf(product.getPrice())));

        TextView productStock = dialog.findViewById(R.id.product_quantity_stock);
        productStock.setText(MessageFormat.format("{0} sản phẩm còn lại", String.valueOf(product.getStockQuantity())));

        ImageButton addQuantity = dialog.findViewById(group_quantity).findViewById(R.id.button_add_quantity);
        ImageButton removeQuantity = dialog.findViewById(group_quantity).findViewById(R.id.button_subtract_quantity);
        TextInputEditText editTextQuantity = dialog.findViewById(group_quantity).findViewById(R.id.text_quantity);

        // DEFAULT VALUE
        editTextQuantity.setText("1");

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Code to execute before text is changed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Code to execute when text is changing
                // Handle the change here
                String quantity = s.toString();
                // Do something with the changing quantity
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Code to execute after text has been changed
                // Handle the final text change here
                String quantity = s.toString();
                if (!quantity.isEmpty()) {
                    int quantityValue = Integer.parseInt(quantity);
                    if (quantityValue > product.getStockQuantity()) {
                        // Temporarily remove the TextWatcher
                        editTextQuantity.removeTextChangedListener(this);
                        // Set the text to the max stock quantity
                        editTextQuantity.setText(MessageFormat.format("{0}", product.getStockQuantity()));
                        // Set the cursor position at the end
                        editTextQuantity.setSelection(editTextQuantity.getText().length());
                        // Re-add the TextWatcher
                        editTextQuantity.addTextChangedListener(this);
                    } else if (quantityValue <= 0) {
                        // Temporarily remove the TextWatcher
                        editTextQuantity.removeTextChangedListener(this);
                        // Set the text to "0"
                        editTextQuantity.setText("0");
                        // Set the cursor position at the end
                        editTextQuantity.setSelection(editTextQuantity.getText().length());
                        // Re-add the TextWatcher
                        editTextQuantity.addTextChangedListener(this);
                    }
                }
                // Do something with the final quantity
            }
        };

        editTextQuantity.addTextChangedListener(textWatcher);
        editTextQuantity.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    // Code to execute when "Done" is pressed
                    // You can handle the final input here
                    // For example, get the text and do something with it
                    String quantity = editTextQuantity.getText().toString();

                    if (!quantity.isEmpty() && Integer.parseInt(quantity) > product.getStockQuantity()) {
                        // Temporarily remove the TextWatcher
                        editTextQuantity.removeTextChangedListener(textWatcher);
                        // Set the text to the max stock quantity
                        editTextQuantity.setText(MessageFormat.format("{0}", product.getStockQuantity()));
                        // Set the cursor position at the end
                        editTextQuantity.setSelection(editTextQuantity.getText().length());
                        // Re-add the TextWatcher
                        editTextQuantity.addTextChangedListener(textWatcher);
                    }
                    // Hide the keyboard
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                    return true; // Return true to indicate the action was handled
                }
                return false;
            }
        });

        addQuantity.setOnClickListener(v -> {
            Log.d("CreateOrderActivity", String.valueOf(editTextQuantity.getText()));
            int currentQuantity = Integer.parseInt(String.valueOf(editTextQuantity.getText()));
            if (currentQuantity >= product.getStockQuantity() && methodManagement == MethodManagement.ORDER) {
                Toast.makeText(CreateOrderActivity.this, "Out of Stock", Toast.LENGTH_SHORT).show();
            } else {
                Log.d("CreateOrderActivity", String.valueOf(product.getStockQuantity()));
                currentQuantity += 1;
                // Temporarily remove the TextWatcher
                editTextQuantity.removeTextChangedListener(textWatcher);
                editTextQuantity.setText(MessageFormat.format("{0}", currentQuantity));
                // Set the cursor position at the end
                editTextQuantity.setSelection(editTextQuantity.getText().length());
                // Re-add the TextWatcher
                editTextQuantity.addTextChangedListener(textWatcher);
                productPrice.setText(MessageFormat.format("{0} VNĐ", product.getPrice() * currentQuantity));
            }
        });

        removeQuantity.setOnClickListener(v -> {
            String quantityText = Objects.requireNonNull(editTextQuantity.getText()).toString();
            int currentQuantity = quantityText.isEmpty() ? 0 : Integer.parseInt(quantityText);
            if (currentQuantity > 0) {
                currentQuantity -= 1;
                // Temporarily remove the TextWatcher
                editTextQuantity.removeTextChangedListener(textWatcher);
                editTextQuantity.setText(MessageFormat.format("{0}", currentQuantity));
                // Set the cursor position at the end
                editTextQuantity.setSelection(editTextQuantity.getText().length());
                // Re-add the TextWatcher
                editTextQuantity.addTextChangedListener(textWatcher);
                productPrice.setText(MessageFormat.format("{0} VNĐ", product.getPrice() * currentQuantity));
            } else {
                Toast.makeText(CreateOrderActivity.this, "Out of Stock", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnAddToCart = dialog.findViewById(R.id.btn_buy_now);
        btnAddToCart.setOnClickListener(v -> {

            switch (methodManagement) {
                case ORDER: {
                    OrderDetail orderDetail = new OrderDetail();
                    orderDetail.setProductId(product.getProductId());
                    if (sizeSelected.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please select size", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    orderDetail.setSize(sizeSelected);
                    sizeSelected = "";
                    if (Integer.parseInt(Objects.requireNonNull(editTextQuantity.getText()).toString()) <= 0) {
                        Toast.makeText(getApplicationContext(), "Please enter quantity", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    orderDetail.setQuantity(Integer.parseInt(Objects.requireNonNull(editTextQuantity.getText()).toString()));
                    orderDetail.setUnitPrice(1000);
                    orderDetails.add(orderDetail);
                    sumQuantityCart = orderDetails.size();
                    binding.cartQuantity.setText(String.valueOf(sumQuantityCart));
                    break;
                }
                case PURCHASE:
                default: {
                    PurchaseOrderDetail purchaseOrderDetail = new PurchaseOrderDetail();
                    purchaseOrderDetail.setProductId(product.getProductId());
                    if (sizeSelected.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please select size", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    purchaseOrderDetail.setSize(sizeSelected);
                    sizeSelected = "";
                    if (Integer.parseInt(Objects.requireNonNull(editTextQuantity.getText()).toString()) <= 0) {
                        Toast.makeText(getApplicationContext(), "Please enter quantity", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    purchaseOrderDetail.setQuantity(Integer.parseInt(Objects.requireNonNull(editTextQuantity.getText()).toString()));
                    purchaseOrderDetail.setUnitPrice(1000);
                    purchaseOrderDetails.add(purchaseOrderDetail);
                    sumQuantityCart = purchaseOrderDetails.size();
                    binding.cartQuantity.setText(String.valueOf(sumQuantityCart));

                    break;
                }
            }


            dialog.dismiss();
        });


        ChipGroup chipGroup = dialog.findViewById(R.id.group_size);
        for (String size : product.getSizes()) {
            Chip chip = createChip(size, new ObjectListener<Chip>() {
                @Override
                public void onClick(Chip chip) {
                    sizeSelected = chip.getText().toString();
                }
            });
            chipGroup.addView(chip);
        }

        dialog.show();

        Objects.requireNonNull(dialog.getWindow()).setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setGravity(Gravity.BOTTOM);
    }


    private Chip createChip(String size, ObjectListener<Chip> listener) {
        Chip chip = new Chip(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,  // width
                LinearLayout.LayoutParams.WRAP_CONTENT   // height
        );
        int margin = (int) getResources().getDimension(R.dimen.chip_margin);
        layoutParams.setMargins(margin, margin, margin, margin);
        chip.setLayoutParams(layoutParams);
        int padding = (int) getResources().getDimension(R.dimen.chip_padding);
        chip.setPadding(padding, padding, padding, padding);

        chip.setText(size);
        ColorStateList backgroundColor = ContextCompat.getColorStateList(this, R.color.chip_background_color);
        chip.setChipBackgroundColor(backgroundColor);

        ColorStateList strokeColor = ContextCompat.getColorStateList(this, R.color.brandColor20);
        chip.setChipStrokeColor(strokeColor);
        chip.setChipStrokeWidth(3);

        ColorStateList textColor = ContextCompat.getColorStateList(this, R.color.chip_text_color);
        chip.setTextColor(textColor);

        chip.setCheckable(true);

        chip.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    listener.onClick(chip);
                    Toast.makeText(getApplicationContext(), chip.getText() + " checked", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), chip.getText() + " unchecked", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return chip;
    }
}
