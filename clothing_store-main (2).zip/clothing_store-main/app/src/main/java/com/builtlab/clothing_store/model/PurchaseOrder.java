package com.builtlab.clothing_store.model;

public class PurchaseOrder {
    private int purchaseOrderId;
    private String orderDate;
    private double totalAmount;
    private String status;
    private int supplierId;

    public PurchaseOrder(int purchaseOrderId, String orderDate, double totalAmount, String status, int supplierId) {
        this.purchaseOrderId = purchaseOrderId;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
        this.status = status;
        this.supplierId = supplierId;
    }

    public PurchaseOrder() {

    }
    public int getPurchaseOrderId() {
        return purchaseOrderId;
    }

    public void setPurchaseOrderId(int purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    @Override
    public String toString() {
        return "PurchaseOrder{" +
                "purchaseOrderId=" + purchaseOrderId +
                ", orderDate='" + orderDate + '\'' +
                ", totalAmount=" + totalAmount +
                ", status='" + status + '\'' +
                ", supplierId=" + supplierId +
                '}';
    }
}
