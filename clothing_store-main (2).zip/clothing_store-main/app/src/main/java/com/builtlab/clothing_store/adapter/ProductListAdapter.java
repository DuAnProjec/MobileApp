package com.builtlab.clothing_store.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.helper.query.ProductDatabaseQuery;
import com.builtlab.clothing_store.model.Product;
import com.builtlab.clothing_store.ui.activity.CreateProductActivity;
import com.builtlab.clothing_store.ui.activity.ProductDetailActivity;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class ProductListAdapter extends RecyclerView.Adapter<ProductListAdapter.ProductViewHolder> {

    private Context context;
    private List<Product> productList;

    public ProductListAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_in_list, parent, false);
        return new ProductViewHolder(view);
    }

    public void updateList(List<Product> list) {
        this.productList = list;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        position = holder.getAdapterPosition();
        Product product = productList.get(position);
        holder.productName.setText(product.getProductName());
        holder.tvPrice.setText(product.getPrice() + " VNĐ");

        String[] images = product.getImages();
        if (images.length > 0) {
            Uri imageUri = Uri.parse(images[0]);
            try {
                context.getContentResolver().takePersistableUriPermission(imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException e) {
                e.printStackTrace();
            }

            try (InputStream inputStream = context.getContentResolver().openInputStream(imageUri)) {
                if (inputStream != null) {
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    holder.productImage.setImageBitmap(bitmap);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        holder.linearLayoutSizes.removeAllViews();
        for (String size : product.getSizes()) {
            TextView sizeTextView = new TextView(context);
            sizeTextView.setText(size);
            sizeTextView.setBackgroundResource(R.drawable.bg_spinner);
            sizeTextView.setGravity(android.view.Gravity.CENTER);
            sizeTextView.setPadding(16, 8, 16, 8);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(8, 8, 8, 8);
            holder.linearLayoutSizes.addView(sizeTextView, params);
        }

        holder.btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(context, CreateProductActivity.class);
            intent.putExtra("product", product);
            context.startActivity(intent);
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ProductDetailActivity.class);
            intent.putExtra("product", product);
            context.startActivity(intent);
        });

        holder.btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Xóa sản phẩm")
                    .setMessage("Bạn có chắc chắn muốn xóa sản phẩm này?")
                    .setPositiveButton("Có", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ProductDatabaseQuery productDbQuery = new ProductDatabaseQuery(context);
                            productDbQuery.deleteProduct(product.getProductId());
                            int position = holder.getAdapterPosition();
                            productList.remove(position);
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, productList.size());
                        }
                    })
                    .setNegativeButton("Không", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ProductViewHolder extends RecyclerView.ViewHolder {

        ImageView productImage;
        TextView productName, tvPrice;
        LinearLayout linearLayoutSizes;
        ImageButton btnDelete, btnEdit;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.product_image);
            productName = itemView.findViewById(R.id.product_name);
            tvPrice = itemView.findViewById(R.id.tv_price);
            linearLayoutSizes = itemView.findViewById(R.id.linear_layout_sizes);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnEdit = itemView.findViewById(R.id.btnEdit);
        }
    }
    public interface OnProductItemClickListener {
        void onEditClick(Product product);
        void onDeleteClick(Product product);
    }
}
