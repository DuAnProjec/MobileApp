package com.builtlab.clothing_store.enums;

public enum StatusOrder {
    PENDING,
    SUCCESS,
    FAILED;

    public String toStringValue() {
        return this.name();
    }

    public static StatusOrder fromString(String value) {
        if (value == null) {
            throw new IllegalArgumentException("String value cannot be null");
        }
        return StatusOrder.valueOf(value);
    }

    public boolean equals(String value) {
        if (value == null) {
            return false;
        }
        return this.name().equals(value.toUpperCase());
    }
}
