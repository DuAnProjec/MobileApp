package com.builtlab.clothing_store.helper.query;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.PurchaseOrder;

import java.util.ArrayList;
import java.util.List;

public class PurchaseOrderDatabaseQuery extends DatabaseQuery<PurchaseOrder> {
    private static final String TABLE_NAME = AppTableData.TABLE_PURCHASE_ORDER;

    public PurchaseOrderDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "PurchaseOrderID";
    }

    @Override
    protected ContentValues getContentValues(PurchaseOrder purchaseOrder) {
        ContentValues values = new ContentValues();
//        values.put("PurchaseOrderID", purchaseOrder.getPurchaseOrderId());
        values.put("OrderDate", purchaseOrder.getOrderDate());
        values.put("TotalAmount", purchaseOrder.getTotalAmount());
        values.put("Status", purchaseOrder.getStatus());
        values.put("SupplierID", purchaseOrder.getSupplierId());
        return values;
    }

    @Override
    protected PurchaseOrder cursorToItem(Cursor cursor) {
        PurchaseOrder purchaseOrder = new PurchaseOrder();
        purchaseOrder.setPurchaseOrderId((int) cursor.getLong(cursor.getColumnIndexOrThrow("PurchaseOrderID")));
        purchaseOrder.setOrderDate(cursor.getString(cursor.getColumnIndexOrThrow("OrderDate")));
        purchaseOrder.setTotalAmount(cursor.getDouble(cursor.getColumnIndexOrThrow("TotalAmount")));
        purchaseOrder.setStatus(cursor.getString(cursor.getColumnIndexOrThrow("Status")));
        purchaseOrder.setSupplierId((int) cursor.getLong(cursor.getColumnIndexOrThrow("SupplierID")));
        return purchaseOrder;
    }

    public List<PurchaseOrder> getAllPurchaseOrders() {
        List<PurchaseOrder> purchaseOrders = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                purchaseOrders.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return purchaseOrders;
    }

    public PurchaseOrder getPurchaseOrderById(long id) {
        open();
        PurchaseOrder purchaseOrder = getItem(id, "PurchaseOrderID");
        close();
        return purchaseOrder;
    }

    public double getTotalPurchaseByDate(String date) {
        open();
        double totalPurchase = 0;
        Cursor cursor = getDatabase().rawQuery(
                "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE OrderDate = ?", new String[]{date});
        if (cursor.moveToFirst()) {
            totalPurchase = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalPurchase;
    }

    public double getTotalPurchaseByMonth(int year, int month) {
        open();
        double totalPurchase = 0;
        String formattedMonth = String.format("%02d", month);
        Cursor cursor = getDatabase().rawQuery(
                "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE strftime('%Y', OrderDate) = ? AND strftime('%m', OrderDate) = ?",
                new String[]{String.valueOf(year), formattedMonth});
        if (cursor.moveToFirst()) {
            totalPurchase = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalPurchase;
    }

    public double getTotalPurchaseByQuarter(int year, int quarter) {
        open();
        double totalPurchase = 0;
        String[] months;
        switch (quarter) {
            case 1:
                months = new String[]{"01", "02", "03"};
                break;
            case 2:
                months = new String[]{"04", "05", "06"};
                break;
            case 3:
                months = new String[]{"07", "08", "09"};
                break;
            case 4:
                months = new String[]{"10", "11", "12"};
                break;
            default:
                months = new String[]{};
                break;
        }
        String query = "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE strftime('%Y', OrderDate) = ? AND (strftime('%m', OrderDate) = ? OR strftime('%m', OrderDate) = ? OR strftime('%m', OrderDate) = ?)";
        Cursor cursor = getDatabase().rawQuery(query, new String[]{String.valueOf(year), months[0], months[1], months[2]});
        if (cursor.moveToFirst()) {
            totalPurchase = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalPurchase;
    }

    public double getTotalPurchaseByYear(int year) {
        open();
        double totalPurchase = 0;
        Cursor cursor = getDatabase().rawQuery(
                "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE strftime('%Y', OrderDate) = ?",
                new String[]{String.valueOf(year)});
        if (cursor.moveToFirst()) {
            totalPurchase = cursor.getDouble(0);
        } else {
            Log.d("Test year", "No data found for the year: " + year);
        }
        cursor.close();
        close();
        return totalPurchase;
    }

    public double getTotalByDate(String date) {
        open();
        double totalRevenue = 0;
        Cursor cursor = getDatabase().rawQuery(
                "SELECT SUM(TotalAmount) FROM " + TABLE_NAME + " WHERE OrderDate = ?", new String[]{date});
        if (cursor.moveToFirst()) {
            totalRevenue = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalRevenue;
    }
    public double getTotalByMonth(int year, int month) {
        open();
        double totalRevenue = 0;
        String formattedMonth = String.format("%02d", month);
        String query = "SELECT SUM(TotalAmount) FROM " + TABLE_NAME +
                " WHERE strftime('%Y', OrderDate) = ? AND strftime('%m', OrderDate) = ?";
        Cursor cursor = getDatabase().rawQuery(query, new String[]{String.valueOf(year), formattedMonth});
        if (cursor.moveToFirst()) {
            totalRevenue = cursor.getDouble(0);
        }
        cursor.close();
        close();
        return totalRevenue;
    }
}
