package com.builtlab.clothing_store.helper.query;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.Order;
import com.builtlab.clothing_store.model.OrderDetail;

import java.util.ArrayList;
import java.util.List;

public class OrderDetailDatabaseQuery extends DatabaseQuery<OrderDetail> {
    private static final String TABLE_NAME = AppTableData.TABLE_ORDER_DETAIL;

    public OrderDetailDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "OrderDetailID";
    }

    @Override
    protected ContentValues getContentValues(OrderDetail orderDetail) {
        ContentValues values = new ContentValues();
//        values.put("OrderDetailID", orderDetail.getOrderDetailId());
        values.put("OrderID", orderDetail.getOrderId());
        values.put("ProductID", orderDetail.getProductId());
        values.put("Quantity", orderDetail.getQuantity());
        values.put("UnitPrice", orderDetail.getUnitPrice());
        values.put("Size", orderDetail.getSize());
        return values;
    }

    @Override
    protected OrderDetail cursorToItem(Cursor cursor) {
        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setOrderDetailId((int) cursor.getLong(cursor.getColumnIndexOrThrow("OrderDetailID")));
        orderDetail.setOrderId((int) cursor.getLong(cursor.getColumnIndexOrThrow("OrderID")));
        orderDetail.setProductId((int) cursor.getLong(cursor.getColumnIndexOrThrow("ProductID")));
        orderDetail.setQuantity(cursor.getInt(cursor.getColumnIndexOrThrow("Quantity")));
        orderDetail.setUnitPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("UnitPrice")));
        orderDetail.setSize(cursor.getString(cursor.getColumnIndexOrThrow("Size")));
        return orderDetail;
    }

    public List<OrderDetail> getAllOrderDetails() {
        List<OrderDetail> orderDetails = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                orderDetails.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return orderDetails;
    }


    public OrderDetail getOrderDetailById(long id) {
        open();
        OrderDetail orderDetail = getItem(id,"OrderDetailID");
        close();
        return orderDetail;
    }

}
