package com.builtlab.clothing_store.helper;

import android.os.AsyncTask;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailSender {

    private static final String FROM = "chatable.web@gmail.com";
    private static final String SMTP_SERVER = "smtp.gmail.com";
    private static final int PORT = 465;
    private static final String USERNAME = "chatable.web@gmail.com";
    private static final String PASSWORD = "jbuitqkwvndlkaql";

    public static void sendEmailAsync(String to, String subject, String body) {
        new SendEmailTask().execute(to, subject, body);
    }

    private static class SendEmailTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            String to = params[0];
            String subject = params[1];
            String body = params[2];
            sendEmail(to, subject, body);
            return null;
        }

        private void sendEmail(String to, String subject, String body) {
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", SMTP_SERVER);
            props.put("mail.smtp.port", String.valueOf(PORT));
            props.put("mail.smtp.ssl.enable", "true");

            Session session = Session.getInstance(props,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(USERNAME, PASSWORD);
                        }
                    });

            try {
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(FROM));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
                message.setSubject(subject);
                message.setText(body);

                Transport.send(message);

                System.out.println("Email sent successfully");

            } catch (MessagingException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
