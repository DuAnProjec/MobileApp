package com.builtlab.clothing_store.helper.query;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.Customer;
import com.builtlab.clothing_store.model.Supplier;

import java.util.ArrayList;
import java.util.List;

public class SupplierDatabaseQuery extends DatabaseQuery<Supplier> {
    private static final String TABLE_NAME = AppTableData.TABLE_SUPPLIER;

    public SupplierDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "SupplierID";
    }

    @Override
    protected ContentValues getContentValues(Supplier supplier) {
        ContentValues values = new ContentValues();
//        values.put("CustomerID", customer.getCustomerId());
        values.put("SupplierName", supplier.getSupplierName());
        values.put("ContactPhone", supplier.getContactPhone());
        values.put("Address", supplier.getAddress());
        return values;
    }

    @Override
    protected Supplier cursorToItem(Cursor cursor) {
        Supplier supplier = new Supplier();
        supplier.setSupplierId((int)cursor.getLong(cursor.getColumnIndexOrThrow("SupplierID")));
        supplier.setSupplierName(cursor.getString(cursor.getColumnIndexOrThrow("SupplierName")));
        supplier.setContactPhone(cursor.getString(cursor.getColumnIndexOrThrow("ContactPhone")));
        supplier.setAddress(cursor.getString(cursor.getColumnIndexOrThrow("Address")));
        return supplier;
    }

    public List<Supplier> getAllSuppliers() {
        List<Supplier> suppliers = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                suppliers.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return suppliers;
    }


    public Supplier getSupplierById(long id) {
        open();
        Supplier supplier = getItem(id, getTablePrimaryKey());
        close();
        return supplier;
    }

    public long addSupplier(Supplier supplier) {
        long id = -1;
        try {
            open();
            id = insert(supplier);
            if (id == -1) {
                Log.e(TAG, "Failed to insert row for customer: " + supplier.toString());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error inserting customer", e);
        } finally {
            close();
        }
        return id;
    }

    public void updateSupplier(Supplier supplier) {
        try {
            open();
            update(supplier.getSupplierId(), supplier);
        } catch (Exception e) {
            Log.e(TAG, "Error updating customer", e);
        } finally {
            close();
        }
    }

    public void deleteSupplier(long supplierId) {
        try {
            open();
            delete(supplierId);
        } catch (Exception e) {
            Log.e(TAG, "Error deleting customer", e);
        } finally {
            close();
        }
    }
}

