package com.builtlab.clothing_store.model;

public class BusinessPlan {
    private int businessPlanId;
    private String startDate;
    private String endDate;

    public BusinessPlan(){

    }

    public BusinessPlan(int businessPlanId, String startDate, String endDate) {
        this.businessPlanId = businessPlanId;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public int getBusinessPlanId() {
        return businessPlanId;
    }

    public void setBusinessPlanId(int businessPlanId) {
        this.businessPlanId = businessPlanId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "BusinessPlan{" +
                "businessPlanId=" + businessPlanId +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                '}';
    }
}
