package com.builtlab.clothing_store.ui.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.ActivityCreateCustomerBinding;
import com.builtlab.clothing_store.helper.query.CustomerDatabaseQuery;
import com.builtlab.clothing_store.model.Customer;

public class CreateCustomerActivity extends AppCompatActivity {
    private ActivityCreateCustomerBinding binding;
    private static final String TAG = "CreateCustomerActivity";
    private Customer customer;
    private boolean isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateCustomerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (getIntent() != null && getIntent().hasExtra("customer")) {
            customer = (Customer) getIntent().getSerializableExtra("customer");
            isEditMode = true;
            populateCustomerDetails();
        } else {
            customer = new Customer();
        }

        initCustomAppBar();
        initSaveButton();
    }

    private void initCustomAppBar() {
        binding.customAppBar.buttonBack.setOnClickListener(v -> finish());
        binding.customAppBar.appBarTitle.setText(isEditMode ? R.string.title_app_bar_edit_customer : R.string.title_app_bar_create_customer);
    }

    private void initSaveButton() {
        binding.buttonSave.setOnClickListener(v -> saveCustomer());
    }

    private void populateCustomerDetails() {
        binding.editTextName.setText(customer.getCustomerName());
        binding.editTextPhone.setText(customer.getPhoneNumber());
        binding.editTextEmail.setText(customer.getEmail());
        binding.editTextAddress.setText(customer.getAddress());
    }

    private void saveCustomer() {
        String name = binding.editTextName.getText().toString().trim();
        String phone = binding.editTextPhone.getText().toString().trim();
        String email = binding.editTextEmail.getText().toString().trim();
        String address = binding.editTextAddress.getText().toString().trim();
//        String gender = binding.editTextGender.getText().toString().trim();

        Log.d(TAG, "Customer details - Name: " + name + ", Phone: " + phone + ", Email: " + email + ", Address: " + address);

        if (validateInput(name, phone, email, address)) {
            customer.setCustomerName(name);
            customer.setPhoneNumber(phone);
            customer.setEmail(email);
            customer.setAddress(address);

            CustomerDatabaseQuery customerDbQuery = new CustomerDatabaseQuery(this);

            if (isEditMode) {
                customerDbQuery.updateCustomer(customer);
                Toast.makeText(this, "Customer updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                customerDbQuery.addCustomer(customer);
                Toast.makeText(this, "Customer added successfully", Toast.LENGTH_SHORT).show();
            }

            setResult(RESULT_OK);
            finish();
        }
    }

    private boolean validateInput(String name, String phone, String email, String address) {
        if (name.isEmpty()) {
            binding.editTextName.setError("Name is required");
            return false;
        }
        if (phone.isEmpty()) {
            binding.editTextPhone.setError("Phone number is required");
            return false;
        }
        if (email.isEmpty()) {
            binding.editTextEmail.setError("Email is required");
            return false;
        }
        if (address.isEmpty()) {
            binding.editTextAddress.setError("Address is required");
            return false;
        }
        return true;
    }
}
