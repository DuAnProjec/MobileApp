package com.builtlab.clothing_store.helper.query;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.PurchaseOrder;
import com.builtlab.clothing_store.model.PurchaseOrderDetail;

import java.util.ArrayList;
import java.util.List;

public class PurchaseOrderDetailDatabaseQuery extends DatabaseQuery<PurchaseOrderDetail> {
    private static final String TABLE_NAME = AppTableData.TABLE_PURCHASE_ORDER_DETAIL;

    public PurchaseOrderDetailDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "PurchaseOrderDetailID";
    }

    @Override
    protected ContentValues getContentValues(PurchaseOrderDetail purchaseOrderDetail) {
        ContentValues values = new ContentValues();
//        values.put("PurchaseOrderDetailID", purchaseOrderDetail.getPurchaseOrderDetailId());
        values.put("PurchaseOrderID", purchaseOrderDetail.getPurchaseOrderId());
        values.put("ProductID", purchaseOrderDetail.getProductId());
        values.put("Quantity", purchaseOrderDetail.getQuantity());
        values.put("UnitPrice", purchaseOrderDetail.getUnitPrice());
        values.put("Size", purchaseOrderDetail.getSize());
        return values;
    }

    @Override
    protected PurchaseOrderDetail cursorToItem(Cursor cursor) {
        PurchaseOrderDetail purchaseOrderDetail = new PurchaseOrderDetail();
        purchaseOrderDetail.setPurchaseOrderDetailId((int) cursor.getLong(cursor.getColumnIndexOrThrow("PurchaseOrderDetailID")));
        purchaseOrderDetail.setPurchaseOrderId((int) cursor.getLong(cursor.getColumnIndexOrThrow("PurchaseOrderID")));
        purchaseOrderDetail.setProductId((int) cursor.getLong(cursor.getColumnIndexOrThrow("ProductID")));
        purchaseOrderDetail.setQuantity(cursor.getInt(cursor.getColumnIndexOrThrow("Quantity")));
        purchaseOrderDetail.setUnitPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("UnitPrice")));
        purchaseOrderDetail.setSize(cursor.getString(cursor.getColumnIndexOrThrow("Size")));





        return purchaseOrderDetail;

    }

    public List<PurchaseOrderDetail> getAllPurchaseOrderDetail() {
        List<PurchaseOrderDetail> purchaseOrderDetails = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                purchaseOrderDetails.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return purchaseOrderDetails;
    }


    public PurchaseOrderDetail getPurchaseOrderDetailById(long id) {
        open();
        PurchaseOrderDetail purchaseOrderDetail = getItem(id, getTablePrimaryKey());
        close();
        return purchaseOrderDetail;
    }


}
