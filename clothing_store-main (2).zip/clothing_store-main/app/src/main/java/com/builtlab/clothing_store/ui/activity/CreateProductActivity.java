package com.builtlab.clothing_store.ui.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.adapter.PreviewImageAdapter;
import com.builtlab.clothing_store.databinding.ActivityCreateProductBinding;
import com.builtlab.clothing_store.helper.query.ProductDatabaseQuery;
import com.builtlab.clothing_store.interfaces.ObjectListener;
import com.builtlab.clothing_store.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CreateProductActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_STORAGE_PERMISSION = 1;

    private ActivityCreateProductBinding binding;
    private ActivityResultLauncher<String> selectImagesLauncher;
    private PreviewImageAdapter previewImageAdapter;
    private Button selectedCategoryButton;
    private boolean[] isSelectedSize = new boolean[5];
    private List<Uri> imageUris = new ArrayList<>();
    private List<String> imageStrings = new ArrayList<>();
    private Product productToEdit = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateProductBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_STORAGE_PERMISSION);
        }

        setupRecyclerView();
        initCustomAppBar();
        initSelectImagesLauncher();

        binding.btnAoKhoac.setOnClickListener(this::onCategoryButtonClicked);
        binding.btnAoKhoac.performClick();
        binding.btnAoPhong.setOnClickListener(this::onCategoryButtonClicked);
        binding.btnQuan.setOnClickListener(this::onCategoryButtonClicked);
        binding.btnVay.setOnClickListener(this::onCategoryButtonClicked);

        binding.btnSizeS.setOnClickListener(view -> onSizeButtonClicked(0, view));
        binding.btnSizeM.setOnClickListener(view -> onSizeButtonClicked(1, view));
        binding.btnSizeL.setOnClickListener(view -> onSizeButtonClicked(2, view));
        binding.btnSizeXL.setOnClickListener(view -> onSizeButtonClicked(3, view));
        binding.btnSize2XL.setOnClickListener(view -> onSizeButtonClicked(4, view));

        binding.btnLuuPdoduct.setOnClickListener(v -> createProduct());

        Intent intent = getIntent();
        if (intent.hasExtra("product")) {
            productToEdit = (Product) intent.getSerializableExtra("product");
            loadProductData(productToEdit);
        }

        binding.llImage.setOnClickListener(v -> openGallery());
    }

    private void setupRecyclerView() {
        previewImageAdapter = new PreviewImageAdapter(this, imageUris, this::onImageRemoved);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        binding.recyclePreviewImage.setLayoutManager(layoutManager);
        binding.recyclePreviewImage.setAdapter(previewImageAdapter);
    }

    private void createProduct() {
        String productName = binding.edtName.getText().toString().trim();
        String desc = binding.edtDescription.getText().toString().trim();
        String priceStr = binding.edtPrice.getText().toString().trim();

        if (productName.isEmpty() || desc.isEmpty() || priceStr.isEmpty() || selectedCategoryButton == null) {
            Toast.makeText(this, "Vui lòng điền đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Giá sản phẩm không hợp lệ", Toast.LENGTH_SHORT).show();
            return;
        }

        int categoryId;
        if (selectedCategoryButton.getText().equals("Full set")) {
            categoryId = 1;
        } else if (selectedCategoryButton.getText().equals("Áo")) {
            categoryId = 2;
        } else if (selectedCategoryButton.getText().equals("Quần")) {
            categoryId = 3;
        } else if (selectedCategoryButton.getText().equals("Đầm/Váy")) {
            categoryId = 4;
        } else {
            Toast.makeText(this, "Danh mục sản phẩm không hợp lệ", Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> sizeStrings = new ArrayList<>();
        if (isSelectedSize[0]) sizeStrings.add("S");
        if (isSelectedSize[1]) sizeStrings.add("M");
        if (isSelectedSize[2]) sizeStrings.add("L");
        if (isSelectedSize[3]) sizeStrings.add("XL");
        if (isSelectedSize[4]) sizeStrings.add("2XL");

        Product product = new Product();
        if (productToEdit == null) {
            product.setProductId(new Random().nextInt(10000) + 1);
        } else {
            product.setProductId(productToEdit.getProductId());
        }
        product.setProductName(productName);
        product.setDescription(desc);
        product.setPrice(price);
        product.setImages(imageStrings.toArray(new String[0]));
        product.setCategoryId(categoryId);
        product.setSizes(sizeStrings.toArray(new String[0]));
        product.setStockQuantity(0);

        ProductDatabaseQuery query = new ProductDatabaseQuery(this);

        if (productToEdit == null) {
            long productId = query.addProduct(product);
            if (productId != -1) {
                Toast.makeText(this, "Thêm sản phẩm thành công", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Thêm sản phẩm thất bại", Toast.LENGTH_SHORT).show();
            }
            finish();
        } else {
            try {
                query.updateProduct(product);
                Toast.makeText(this, "Cập nhật sản phẩm thành công", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Cập nhật sản phẩm thất bại", Toast.LENGTH_SHORT).show();
            }
            finish();
        }
    }

    private void loadProductData(Product productToEdit) {
        binding.edtName.setText(productToEdit.getProductName());
        binding.edtDescription.setText(productToEdit.getDescription());
        binding.edtPrice.setText(String.valueOf(productToEdit.getPrice()));
        binding.llImage.setVisibility(View.VISIBLE);
        binding.llSelectImage.setVisibility(View.GONE);

        imageStrings.clear();
        imageUris.clear();

        for (String imageUri : productToEdit.getImages()) {
            imageStrings.add(imageUri);
            imageUris.add(Uri.parse(imageUri));
        }
        previewImageAdapter.updateList(imageUris);

        String[] sizes = productToEdit.getSizes();
        for (int i = 0; i < isSelectedSize.length; i++) {
            isSelectedSize[i] = false;
        }
        for (String size : sizes) {
            switch (size) {
                case "S":
                    isSelectedSize[0] = true;
                    break;
                case "M":
                    isSelectedSize[1] = true;
                    break;
                case "L":
                    isSelectedSize[2] = true;
                    break;
                case "XL":
                    isSelectedSize[3] = true;
                    break;
                case "2XL":
                    isSelectedSize[4] = true;
                    break;
            }
        }

        updateSizeButtonsUI();

        switch (productToEdit.getCategoryId()) {
            case 1:
                binding.btnAoKhoac.performClick();
                break;
            case 2:
                binding.btnAoPhong.performClick();
                break;
            case 3:
                binding.btnQuan.performClick();
                break;
            case 4:
                binding.btnVay.performClick();
                break;
        }
    }

    private void onImageRemoved(String uri) {
        imageUris.remove(Uri.parse(uri));
        imageStrings.remove(uri);
        previewImageAdapter.updateList(imageUris);
    }

    private void updateSizeButtonsUI() {
        Button[] sizeButtons = {binding.btnSizeS, binding.btnSizeM, binding.btnSizeL, binding.btnSizeXL, binding.btnSize2XL};
        for (int i = 0; i < isSelectedSize.length; i++) {
            if (isSelectedSize[i]) {
                sizeButtons[i].setTextColor(getResources().getColor(R.color.white));
                sizeButtons[i].setBackgroundResource(R.drawable.bg_button_checked);
            } else {
                sizeButtons[i].setTextColor(getResources().getColor(R.color.brandColor20));
                sizeButtons[i].setBackgroundResource(R.drawable.bg_button_unchecked);
            }
        }
    }

    private void initCustomAppBar() {
        binding.customAppBar.buttonBack.setOnClickListener(v -> finish());
        binding.llSelectImage.setOnClickListener(v -> openGallery());
        binding.customAppBar.appBarTitle.setText(R.string.title_themSanPham);
    }

    private void initSelectImagesLauncher() {
        selectImagesLauncher = registerForActivityResult(
                new ActivityResultContracts.GetMultipleContents(),
                this::updateCardViewWithImages
        );
    }

    private void openGallery() {
        selectImagesLauncher.launch("image/*");
    }

    private void updateCardViewWithImages(List<Uri> newImageUris) {
        TextView placeholderText = binding.tvImageSelect;
        ImageView placeHolderImage = binding.imgProductImage;
        placeholderText.setVisibility(View.GONE);
        placeHolderImage.setVisibility(View.GONE);

        for (Uri imageUri : newImageUris) {
            try {
                getContentResolver().takePersistableUriPermission(imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException e) {
                e.printStackTrace();
            }

            String uriString = imageUri.toString();
            imageStrings.add(uriString);
            imageUris.add(imageUri);
        }
        binding.llSelectImage.setVisibility(View.GONE);
        binding.llImage.setVisibility(View.VISIBLE);

        previewImageAdapter.updateList(imageUris);
    }

    private void onCategoryButtonClicked(View view) {
        if (selectedCategoryButton != null) {
            selectedCategoryButton.setTextColor(getResources().getColor(R.color.brandColor20));
            selectedCategoryButton.setBackgroundResource(R.drawable.bg_button_unchecked);
        }
        selectedCategoryButton = (Button) view;
        selectedCategoryButton.setTextColor(getResources().getColor(R.color.white));
        selectedCategoryButton.setBackgroundResource(R.drawable.bg_button_checked);
    }

    private void onSizeButtonClicked(int index, View view) {
        Button button = (Button) view;
        if (!isSelectedSize[index]) {
            button.setTextColor(getResources().getColor(R.color.white));
            button.setBackgroundResource(R.drawable.bg_button_checked);
            isSelectedSize[index] = true;
        } else {
            button.setTextColor(getResources().getColor(R.color.brandColor20));
            button.setBackgroundResource(R.drawable.bg_button_unchecked);
            isSelectedSize[index] = false;
        }
    }
}
