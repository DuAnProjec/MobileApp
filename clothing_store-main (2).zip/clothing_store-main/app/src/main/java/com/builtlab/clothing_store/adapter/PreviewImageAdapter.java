package com.builtlab.clothing_store.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.builtlab.clothing_store.databinding.ItemPreviewImageBinding;
import com.builtlab.clothing_store.interfaces.ObjectListener;

import java.util.List;

public class PreviewImageAdapter extends RecyclerView.Adapter<PreviewImageAdapter.ViewHolder> {
    private Context context;
    private List<Uri> list;
    private ObjectListener<String> onPreview;

    public PreviewImageAdapter(Context context, List<Uri> list, ObjectListener<String> onPreview) {
        this.context = context;
        this.list = list;
        this.onPreview = onPreview;
    }

    @NonNull
    @Override
    public PreviewImageAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new PreviewImageAdapter.ViewHolder(ItemPreviewImageBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull PreviewImageAdapter.ViewHolder holder, int position) {
        holder.bind(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    public void updateList(List<Uri> newList) {
        this.list = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ItemPreviewImageBinding binding;

        public ViewHolder(ItemPreviewImageBinding itemView) {
            super(itemView.getRoot());
            this.binding = itemView;
        }

        private void bind(Uri url) {
            binding.imagePreview.setImageURI(url);
            binding.imgIcon.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    list.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, list.size());
                }
            });
        }
    }
}
