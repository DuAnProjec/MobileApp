package com.builtlab.clothing_store.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.enums.StatusOrder;
import com.builtlab.clothing_store.helper.query.OrderDatabaseQuery;
import com.builtlab.clothing_store.model.Order;

public class LoginActivity extends AppCompatActivity {
    private Button btnLogin;
    private EditText username;
    private EditText password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        init();
//
//        OrderDatabaseQuery orderDatabaseQuery = new OrderDatabaseQuery(getApplicationContext());
//        orderDatabaseQuery.open(); // Open the database connection
//
//        long orderId = 1;
//        Order order = orderDatabaseQuery.getOrderById(orderId);
//        if (order != null) {
//            Log.d("LoginActivity", "Order retrieved: " + order.toString());
//            // Do something with the retrieved order
//        } else {
//            Log.e("LoginActivity", "Order not found");
//        }
//
//        orderDatabaseQuery.close(); // Close the database connection
//
//        Log.d("LoginActivity", StatusOrder.SUCCESS.toStringValue());
//        Log.d("LoginActivity", StatusOrder.FAILED.toStringValue());
//        Log.d("LoginActivity", StatusOrder.PENDING.toStringValue());
    }

    private void init() {
        initViewComponent();
        initEventComponent();
    }

    private void initViewComponent() {
        btnLogin = findViewById(R.id.btn_login);
        username = findViewById(R.id.edit_email);
        password = findViewById(R.id.edit_password);
    }

    private void initEventComponent() {
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {
                    Intent intent = new Intent(LoginActivity.this, RootActivity.class);
                    startActivity(intent);
                    finish();
                } else if (username.getText().toString().equals("khachhang") && password.getText().toString().equals("khachhang")) {
                    Intent intent = new Intent(LoginActivity.this, RootActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Tên đăng nhập hoặc mật khẩu không đúng!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}