package com.builtlab.clothing_store.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.ActivityCreateVoucherBinding;
import com.builtlab.clothing_store.helper.query.PromotionDatabaseQuery;
import com.builtlab.clothing_store.model.Promotion;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class CreateVoucherActivity extends AppCompatActivity {
    private ActivityCreateVoucherBinding binding;

    private Button selectedCategoryButton;
    private Button selectedUserButton;

    private Calendar startDateCalendar;
    private Calendar endDateCalendar;

    private Promotion promotionToEdit = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateVoucherBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initCustomAppBar();
        initButtons();
        initDatePicker();
        initSaveButton();

        // Check if we are editing an existing promotion
        Intent intent = getIntent();
        if (intent.hasExtra("promotion")) {
            promotionToEdit = (Promotion) intent.getSerializableExtra("promotion");
            loadPromotionData(promotionToEdit);
        }
    }

    private void initCustomAppBar() {
        binding.customAppBar.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.customAppBar.appBarTitle.setText(R.string.title_app_bar_create_voucher);
    }

    private void initButtons() {
        selectedCategoryButton = binding.buttonAllCategories;
        selectedUserButton = binding.buttonAllUsers;

        binding.buttonAllCategories.setOnClickListener(this::onCategoryButtonClicked);
        binding.buttonTShirts.setOnClickListener(this::onCategoryButtonClicked);
        binding.buttonPants.setOnClickListener(this::onCategoryButtonClicked);
        binding.buttonDresses.setOnClickListener(this::onCategoryButtonClicked);

        binding.buttonAllUsers.setOnClickListener(this::onUserButtonClicked);
        binding.buttonCustomers.setOnClickListener(this::onUserButtonClicked);
    }

    private void onCategoryButtonClicked(View view) {
        if (selectedCategoryButton != null) {
            selectedCategoryButton.setTextColor(getResources().getColor(R.color.brandColor20));
            selectedCategoryButton.setBackgroundResource(R.drawable.bg_button_unchecked);
        }
        selectedCategoryButton = (Button) view;
        selectedCategoryButton.setTextColor(getResources().getColor(R.color.white));
        selectedCategoryButton.setBackgroundResource(R.drawable.bg_button_checked);
    }

    private void onUserButtonClicked(View view) {
        if (selectedUserButton != null) {
            selectedUserButton.setTextColor(getResources().getColor(R.color.brandColor20));
            selectedUserButton.setBackgroundResource(R.drawable.bg_button_unchecked);
        }
        selectedUserButton = (Button) view;
        selectedUserButton.setTextColor(getResources().getColor(R.color.white));
        selectedUserButton.setBackgroundResource(R.drawable.bg_button_checked);
    }

    private void initDatePicker() {
        startDateCalendar = Calendar.getInstance();
        endDateCalendar = Calendar.getInstance();

        binding.editTextStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(startDateCalendar, binding.editTextStartDate);
            }
        });

        binding.editTextEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(endDateCalendar, binding.editTextEndDate);
            }
        });
    }

    private void showDatePickerDialog(final Calendar calendar, final TextInputEditText editText) {
        DatePickerDialog datePickerDialog = new DatePickerDialog(CreateVoucherActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDateEditText(editText, calendar);
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void updateDateEditText(TextInputEditText editText, Calendar calendar) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        editText.setText(sdf.format(calendar.getTime()));
    }

    private void loadPromotionData(Promotion promotion) {
        binding.editTextProgramName.setText(promotion.getPromotionName());
        binding.editTextDescription.setText(promotion.getDescription());
        binding.editTextDiscountPercentage.setText(String.valueOf(promotion.getDiscountPercentage()));
        binding.editTextMinimumOrder.setText(String.valueOf(promotion.getMinimumOrderAmount()));
        binding.editTextStartDate.setText(promotion.getStartDate());
        binding.editTextEndDate.setText(promotion.getEndDate());

        switch (promotion.getApplicableCategories()) {
            case "Tất cả":
                onCategoryButtonClicked(binding.buttonAllCategories);
                break;
            case "Áo":
                onCategoryButtonClicked(binding.buttonTShirts);
                break;
            case "Quần":
                onCategoryButtonClicked(binding.buttonPants);
                break;
            case "Đầm/Váy":
                onCategoryButtonClicked(binding.buttonDresses);
                break;
        }

        switch (promotion.getApplicableTo()) {
            case "Tất cả":
                onUserButtonClicked(binding.buttonAllUsers);
                break;
            case "Khách hàng":
                onUserButtonClicked(binding.buttonCustomers);
                break;
        }
    }

    private void initSaveButton() {
        binding.buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePromotion();
            }
        });
    }

    private void savePromotion() {
        String promotionName = binding.editTextProgramName.getText().toString().trim();
        String description = binding.editTextDescription.getText().toString().trim();
        String discountPercentageStr = binding.editTextDiscountPercentage.getText().toString().trim();
        String minimumOrderAmountStr = binding.editTextMinimumOrder.getText().toString().trim();
        String startDate = binding.editTextStartDate.getText().toString().trim();
        String endDate = binding.editTextEndDate.getText().toString().trim();
        String applicableCategories = selectedCategoryButton != null ? selectedCategoryButton.getText().toString() : "";
        String applicableTo = selectedUserButton != null ? selectedUserButton.getText().toString() : "";

        if (promotionName.isEmpty() || discountPercentageStr.isEmpty() || minimumOrderAmountStr.isEmpty() || startDate.isEmpty() || endDate.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return;
        }

        double discountPercentage;
        double minimumOrderAmount;
        try {
            discountPercentage = Double.parseDouble(discountPercentageStr);
            minimumOrderAmount = Double.parseDouble(minimumOrderAmountStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Vui lòng nhập đúng định dạng số", Toast.LENGTH_SHORT).show();
            return;
        }

        Promotion promotion;
        if (promotionToEdit != null) {
            promotion = promotionToEdit;
        } else {
            promotion = new Promotion();
        }

        promotion.setPromotionName(promotionName);
        promotion.setDescription(description);
        promotion.setDiscountPercentage(discountPercentage);
        promotion.setMinimumOrderAmount(minimumOrderAmount);
        promotion.setStartDate(startDate);
        promotion.setEndDate(endDate);
        promotion.setApplicableCategories(applicableCategories);
        promotion.setApplicableTo(applicableTo);

        PromotionDatabaseQuery promotionDbQuery = new PromotionDatabaseQuery(this);

        if (promotionToEdit != null) {
            promotionDbQuery.updatePromotion(promotion);
            Toast.makeText(this, "Cập nhật chương trình khuyến mãi thành công", Toast.LENGTH_SHORT).show();
        } else {
            long promotionId = promotionDbQuery.addPromotion(promotion);
            if (promotionId != -1) {
                Toast.makeText(this, "Thêm chương trình khuyến mãi thành công", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Thêm chương trình khuyến mãi thất bại", Toast.LENGTH_SHORT).show();
            }
        }
        finish();
    }
}
