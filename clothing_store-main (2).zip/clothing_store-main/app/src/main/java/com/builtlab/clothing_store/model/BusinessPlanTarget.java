package com.builtlab.clothing_store.model;

public class BusinessPlanTarget {
    private int targetId;
    private int businessPlanId;
    private String productCategory;
    private int purchaseTarget;
    private int saleTarget;

    public BusinessPlanTarget(int targetId, int businessPlanId, String productCategory, int purchaseTarget, int saleTarget) {
        this.targetId = targetId;
        this.businessPlanId = businessPlanId;
        this.productCategory = productCategory;
        this.purchaseTarget = purchaseTarget;
        this.saleTarget = saleTarget;
    }

    public int getTargetId() {
        return targetId;
    }

    public void setTargetId(int targetId) {
        this.targetId = targetId;
    }

    public int getBusinessPlanId() {
        return businessPlanId;
    }

    public void setBusinessPlanId(int businessPlanId) {
        this.businessPlanId = businessPlanId;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public int getPurchaseTarget() {
        return purchaseTarget;
    }

    public void setPurchaseTarget(int purchaseTarget) {
        this.purchaseTarget = purchaseTarget;
    }

    public int getSaleTarget() {
        return saleTarget;
    }

    public void setSaleTarget(int saleTarget) {
        this.saleTarget = saleTarget;
    }

    @Override
    public String toString() {
        return "BusinessPlanTarget{" +
                "targetId=" + targetId +
                ", businessPlanId=" + businessPlanId +
                ", productCategory='" + productCategory + '\'' +
                ", purchaseTarget=" + purchaseTarget +
                ", saleTarget=" + saleTarget +
                '}';
    }
}
