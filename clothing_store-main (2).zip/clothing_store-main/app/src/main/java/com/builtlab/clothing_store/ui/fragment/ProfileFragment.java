package com.builtlab.clothing_store.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.FragmentProfileBinding;
import com.builtlab.clothing_store.helper.query.CustomerDatabaseQuery;
import com.builtlab.clothing_store.model.Customer;
import com.builtlab.clothing_store.ui.activity.CreateCustomerActivity;
import com.builtlab.clothing_store.adapter.CustomerAdapter;
import java.util.List;

public class ProfileFragment extends Fragment {

    private static final int REQUEST_CODE_CREATE_CUSTOMER = 1;
    private FragmentProfileBinding binding;
    private CustomerAdapter adapter;
    private List<Customer> customerList;

    public ProfileFragment() {
        // Required empty public constructor
    }

    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        View view = binding.getRoot();
        binding.fab.setOnClickListener(v -> startActivityForResult(new Intent(getActivity(), CreateCustomerActivity.class), REQUEST_CODE_CREATE_CUSTOMER));

        loadCustomers();

        return view;
    }

    private void loadCustomers() {
        CustomerDatabaseQuery customerDbQuery = new CustomerDatabaseQuery(getContext());
        customerList = customerDbQuery.getAllCustomers();
        for (Customer customer : customerList) {
            Log.d("ProfileFragment", "Customer: " + customer.getCustomerName());
        }
        adapter = new CustomerAdapter(getContext(), customerList);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recyclerView.setAdapter(adapter);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_CREATE_CUSTOMER && resultCode == AppCompatActivity.RESULT_OK) {
            // Refresh customer list
            loadCustomers();
        }
    }
}
