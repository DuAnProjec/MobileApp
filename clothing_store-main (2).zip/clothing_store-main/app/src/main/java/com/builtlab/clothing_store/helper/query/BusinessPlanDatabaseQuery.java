package com.builtlab.clothing_store.helper.query;

import static android.content.ContentValues.TAG;

import static com.builtlab.clothing_store.constants.AppTableData.TABLE_BUSINESS_PLAN;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.builtlab.clothing_store.constants.AppTableData;
import com.builtlab.clothing_store.helper.DatabaseQuery;
import com.builtlab.clothing_store.model.BusinessPlan;

import java.util.ArrayList;
import java.util.List;

public class BusinessPlanDatabaseQuery extends DatabaseQuery<BusinessPlan> {
    private static final String TABLE_NAME = AppTableData.TABLE_BUSINESS_PLAN;

    public BusinessPlanDatabaseQuery(Context context) {
        super(context);
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

    @Override
    protected String getTablePrimaryKey() {
        return "BusinessPlanID";
    }

    @Override
    protected ContentValues getContentValues(BusinessPlan businessPlan) {
        ContentValues values = new ContentValues();
        values.put("BusinessPlanID", businessPlan.getBusinessPlanId());
        values.put("StartDate", businessPlan.getStartDate());
        values.put("EndDate", businessPlan.getEndDate());
        return values;
    }

    @Override
    protected BusinessPlan cursorToItem(Cursor cursor) {
        BusinessPlan businessPlan = new BusinessPlan(
                cursor.getInt(cursor.getColumnIndexOrThrow("BusinessPlanID")),
                cursor.getString(cursor.getColumnIndexOrThrow("StartDate")),
                cursor.getString(cursor.getColumnIndexOrThrow("EndDate"))
        );
        return businessPlan;
    }

    public List<BusinessPlan> getAllBusinessPlans() {
        List<BusinessPlan> businessPlans = new ArrayList<>();
        open();
        Cursor cursor = getAll();
        if (cursor.moveToFirst()) {
            do {
                businessPlans.add(cursorToItem(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        close();
        return businessPlans;
    }

    public BusinessPlan getBusinessPlanById(long id) {
        open();
        BusinessPlan businessPlan = getItem(id, "BusinessPlanID");
        close();
        return businessPlan;
    }

    public long addBusinessPlan(BusinessPlan businessPlan) {
        long id = -1;
        try {
            open();
            delete(0);

            id = insert(businessPlan);
            if (id == -1) {
                Log.e(TAG, "Failed to insert row for business plan: " + businessPlan.toString());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error inserting business plan", e);
        } finally {
            close();
        }
        return id;
    }

    public void updateBusinessPlan(BusinessPlan businessPlan) {
        try {
            open();
            update(businessPlan.getBusinessPlanId(), businessPlan);
        } catch (Exception e) {
            Log.e(TAG, "Error updating business plan", e);
        } finally {
            close();
        }
    }

    public void deleteBusinessPlan(long businessPlanId) {
        try {
            open();
            delete(businessPlanId);
        } catch (Exception e) {
            Log.e(TAG, "Error deleting business plan", e);
        } finally {
            close();
        }
    }
}
