package com.builtlab.clothing_store.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.builtlab.clothing_store.constants.AppTableData;

import java.util.Random;

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "cloth.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_CATEGORY = AppTableData.TABLE_CATEGORY;
    private static final String TABLE_ACCOUNT = AppTableData.TABLE_ACCOUNT;
    private static final String TABLE_PRODUCT = AppTableData.TABLE_PRODUCT;
    private static final String TABLE_CUSTOMER = AppTableData.TABLE_CUSTOMER;
    private static final String TABLE_ORDER = AppTableData.TABLE_ORDER;
    private static final String TABLE_ORDER_DETAIL = AppTableData.TABLE_ORDER_DETAIL;
    private static final String TABLE_PROMOTION = AppTableData.TABLE_PROMOTION;
    private static final String TABLE_SUPPLIER = AppTableData.TABLE_SUPPLIER;
    private static final String TABLE_PURCHASE_ORDER = AppTableData.TABLE_PURCHASE_ORDER;
    private static final String TABLE_PURCHASE_ORDER_DETAIL = AppTableData.TABLE_PURCHASE_ORDER_DETAIL;
    private static final String TABLE_BUSINESS_PLAN = AppTableData.TABLE_BUSINESS_PLAN;
    private static final String TABLE_BUSINESS_PLAN_TARGET = AppTableData.TABLE_BUSINESS_PLAN_TARGET;


    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d("DatabaseHandler", "DatabaseHandler: constructor called");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("DatabaseHandler", "onCreate: called");
        db.execSQL(createCategoryTable());
        Log.d("DatabaseHandler", "onCreate: createCategoryTable");
        db.execSQL(createAccountTable());
        Log.d("DatabaseHandler", "onCreate: createAccountTable");
        db.execSQL(createProductTable());
        Log.d("DatabaseHandler", "onCreate: createProductTable");
        db.execSQL(createCustomerTable());
        Log.d("DatabaseHandler", "onCreate: createCustomerTable");
        db.execSQL(createOrderTable());
        Log.d("DatabaseHandler", "onCreate: createOrderTable");
        db.execSQL(createOrderDetailTable());
        Log.d("DatabaseHandler", "onCreate: createOrderDetailTable");
        db.execSQL(createPromotionTable());
        Log.d("DatabaseHandler", "onCreate: createPromotionTable");
        db.execSQL(createSupplierTable());
        Log.d("DatabaseHandler", "onCreate: createSupplierTable");
        db.execSQL(createPurchaseOrderTable());
        Log.d("DatabaseHandler", "onCreate: createPurchaseOrderTable");
        db.execSQL(createPurchaseOrderDetailTable());
        Log.d("DatabaseHandler", "onCreate: createPurchaseOrderDetailTable");
        db.execSQL(createBusinessPlanTable());
        Log.d("DatabaseHandler", "onCreate: createBusinessPlanTable");
        db.execSQL(createBusinessPlanTargetTable());
        Log.d("DatabaseHandler", "onCreate: createBusinessPlanTargetTable");
        addSampleData(db);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d("DatabaseHandler", "onUpgrade: called");
        dropTable(db, TABLE_CATEGORY);
        dropTable(db, TABLE_ACCOUNT);
        dropTable(db, TABLE_PRODUCT);
        dropTable(db, TABLE_CUSTOMER);
        dropTable(db, TABLE_ORDER);
        dropTable(db, TABLE_ORDER_DETAIL);
        dropTable(db, TABLE_PROMOTION);
        dropTable(db, TABLE_SUPPLIER);
        dropTable(db, TABLE_PURCHASE_ORDER);
        dropTable(db, TABLE_PURCHASE_ORDER_DETAIL);
        dropTable(db, TABLE_BUSINESS_PLAN);
        dropTable(db, TABLE_BUSINESS_PLAN_TARGET);
        onCreate(db);
    }

    private String createCategoryTable() {
        return "CREATE TABLE " + TABLE_CATEGORY + "("
                + "CategoryID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "CategoryName TEXT NOT NULL" + ")";
    }

    private String createAccountTable() {
        return "CREATE TABLE " + TABLE_ACCOUNT + "("
                + "AccountID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "Email TEXT UNIQUE NOT NULL,"
                + "Password TEXT NOT NULL" + ")";
    }

    private String createProductTable() {
        return "CREATE TABLE " + TABLE_PRODUCT + "("
                + "ProductID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "ProductName TEXT NOT NULL,"
                + "CategoryID INTEGER NOT NULL,"
                + "Price REAL NOT NULL,"
                + "Description TEXT,"
                + "Images TEXT,"
                + "Sizes TEXT,"
                + "StockQuantity INTEGER NOT NULL,"
                + "FOREIGN KEY (CategoryID) REFERENCES " + TABLE_CATEGORY + "(CategoryID)" + ")";
    }

    private String createCustomerTable() {
        return "CREATE TABLE " + TABLE_CUSTOMER + "("
                + "CustomerID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "CustomerName TEXT NOT NULL,"
                + "PhoneNumber TEXT,"
                + "Email TEXT,"
                + "Address TEXT" + ")";
    }

    private String createOrderTable() {
        return "CREATE TABLE " + TABLE_ORDER + "("
                + "OrderID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "CustomerID INTEGER,"
                + "OrderDate DATE NOT NULL,"
                + "SubTotal REAL,"
                + "DiscountAmount REAL,"
                + "TotalAmount REAL NOT NULL,"
                + "Status TEXT NOT NULL,"
                + "PromotionID INTEGER,"
                + "FOREIGN KEY (CustomerID) REFERENCES " + TABLE_CUSTOMER + "(CustomerID),"
                + "FOREIGN KEY (PromotionID) REFERENCES " + TABLE_PROMOTION + "(PromotionID)" + ")";
    }

    private String createOrderDetailTable() {
        return "CREATE TABLE " + TABLE_ORDER_DETAIL + "("
                + "OrderDetailID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "OrderID INTEGER,"
                + "ProductID INTEGER,"
                + "Quantity INTEGER NOT NULL,"
                + "UnitPrice REAL NOT NULL,"
                + "Size TEXT,"
                + "FOREIGN KEY (OrderID) REFERENCES " + TABLE_ORDER + "(OrderID),"
                + "FOREIGN KEY (ProductID) REFERENCES " + TABLE_PRODUCT + "(ProductID)" + ")";
    }

    private String createPromotionTable() {
        return "CREATE TABLE " + TABLE_PROMOTION + "("
                + "PromotionID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "PromotionName TEXT NOT NULL,"
                + "Description TEXT,"
                + "DiscountPercentage REAL NOT NULL,"
                + "MinimumOrderAmount REAL NOT NULL,"
                + "StartDate DATE NOT NULL,"
                + "EndDate DATE NOT NULL,"
                + "ApplicableCategories TEXT,"
                + "ApplicableTo TEXT" + ")";
    }

    private String createSupplierTable() {
        return "CREATE TABLE " + TABLE_SUPPLIER + "("
                + "SupplierID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "SupplierName TEXT NOT NULL,"
                + "ContactPhone TEXT,"
                + "Address TEXT" + ")";
    }

    private String createPurchaseOrderTable() {
        return "CREATE TABLE " + TABLE_PURCHASE_ORDER + "("
                + "PurchaseOrderID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "OrderDate DATE NOT NULL,"
                + "TotalAmount REAL NOT NULL,"
                + "Status TEXT NOT NULL,"
                + "SupplierID INTEGER NOT NULL,"
                + "FOREIGN KEY (SupplierID) REFERENCES " + TABLE_SUPPLIER + "(SupplierID)" + ")";
    }

    private String createPurchaseOrderDetailTable() {
        return "CREATE TABLE " + TABLE_PURCHASE_ORDER_DETAIL + "("
                + "PurchaseOrderDetailID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "PurchaseOrderID INTEGER,"
                + "ProductID INTEGER,"
                + "Quantity INTEGER NOT NULL,"
                + "UnitPrice REAL NOT NULL,"
                + "Size TEXT,"
                + "FOREIGN KEY (PurchaseOrderID) REFERENCES " + TABLE_PURCHASE_ORDER + "(PurchaseOrderID),"
                + "FOREIGN KEY (ProductID) REFERENCES " + TABLE_PRODUCT + "(ProductID)" + ")";
    }

    private String createBusinessPlanTable() {
        return "CREATE TABLE " + TABLE_BUSINESS_PLAN + "("
                + "BusinessPlanID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "StartDate DATE NOT NULL,"
                + "EndDate DATE NOT NULL" + ")";
    }

    private String createBusinessPlanTargetTable() {
        return "CREATE TABLE " + TABLE_BUSINESS_PLAN_TARGET + "("
                + "TargetID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "BusinessPlanID INTEGER,"
                + "ProductCategory TEXT NOT NULL,"
                + "PurchaseTarget INTEGER NOT NULL,"
                + "SaleTarget INTEGER NOT NULL,"
                + "FOREIGN KEY (BusinessPlanID) REFERENCES " + TABLE_BUSINESS_PLAN + "(BusinessPlanID)" + ")";
    }

    private void dropTable(SQLiteDatabase db, String tableName) {
        db.execSQL("DROP TABLE IF EXISTS " + tableName);
    }

    private void addSampleData(SQLiteDatabase db) {
        Log.d("DatabaseHandler", "addSampleData: called");

        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('H&M', '0987654321', '123 Fashion St, City 1')");
        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('Zara', '0987654322', '456 Style Blvd, City 2')");
        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('Uniqlo', '0987654323', '789 Trend Ave, City 3')");
        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('Forever 21', '0987654324', '321 Vogue Rd, City 4')");
        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('GAP', '0987654325', '654 Modern St, City 5')");
        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('Old Navy', '0987654326', '987 Fashion Way, City 6')");
        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('Topshop', '0987654327', '123 Couture Ln, City 7')");
        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('Mango', '0987654328', '456 Trendy Blvd, City 8')");
        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('ASOS', '0987654329', '789 Style Rd, City 9')");
        db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('Bershka', '0987654330', '321 Chic St, City 10')");


        // Sample data for CATEGORY table
        for (int i = 1; i <= 10; i++) {
            db.execSQL("INSERT INTO " + TABLE_CATEGORY + " (CategoryName) VALUES ('Category " + i + "')");
        }

        // Sample data for ACCOUNT table
        for (int i = 1; i <= 10; i++) {
            db.execSQL("INSERT INTO " + TABLE_ACCOUNT + " (Email, Password) VALUES ('user" + i + "@example.com', 'password" + i + "')");
        }

        // Sample data for PRODUCT table
//        Random random = new Random();
//        for (int i = 1; i <= 10; i++) {
//            int randomCategoryId = random.nextInt(4) + 1;
//            db.execSQL("INSERT INTO " + TABLE_PRODUCT + " (ProductName, CategoryID, Price, Description, Images, Sizes, StockQuantity) VALUES ('Product " + i + "', " + randomCategoryId + ", 10.0, 'Description " + i + "', 'Image" + i + ".jpg', 'S|M|L', 100)");
//        }

        // Sample data for CUSTOMER table
//        for (int i = 1; i <= 10; i++) {
//            db.execSQL("INSERT INTO " + TABLE_CUSTOMER + " (CustomerName, PhoneNumber, Email, Address) VALUES ('Customer " + i + "', '1234567890', 'customer" + i + "@example.com', 'Address " + i + "')");
//        }

        // Sample data for ORDERS table
//        for (int i = 1; i <= 10; i++) {
//            db.execSQL("INSERT INTO " + TABLE_ORDER + " (CustomerID, OrderDate, SubTotal, DiscountAmount, TotalAmount, Status, PromotionID) VALUES (1, '2024-07-18', 100.0, 10.0, 90.0, 'SUCCESS', 1)");
//        }

        // Sample data for ORDER_DETAIL table
//        for (int i = 1; i <= 10; i++) {
//            db.execSQL("INSERT INTO " + TABLE_ORDER_DETAIL + " (OrderID, ProductID, Quantity, UnitPrice, Size) VALUES (1, 1, 2, 10.0, 'M')");
//        }

        // Sample data for PROMOTION table
//        for (int i = 1; i <= 10; i++) {
//            db.execSQL("INSERT INTO " + TABLE_PROMOTION + " (PromotionName, Description, DiscountPercentage, MinimumOrderAmount, StartDate, EndDate, ApplicableCategories, ApplicableTo) VALUES ('Promotion " + i + "', 'Description " + i + "', 10.0, 50.0, '2022-01-01', '2022-12-31', '1,2,3', 'All')");
//        }

        // Sample data for SUPPLIER table
//        for (int i = 1; i <= 10; i++) {
//            db.execSQL("INSERT INTO " + TABLE_SUPPLIER + " (SupplierName, ContactPhone, Address) VALUES ('Supplier " + i + "', '1234567890', 'Address " + i + "')");
//        }

        // Sample data for PURCHASE_ORDER table
//        for (int i = 1; i <= 10; i++) {
//            db.execSQL("INSERT INTO " + TABLE_PURCHASE_ORDER + " (OrderDate, TotalAmount, Status, SupplierID) VALUES ('2024-07-18', 100.0, 'PENDING', 1)");
//        }

        // Sample data for PURCHASE_ORDER_DETAIL table
//        for (int i = 1; i <= 10; i++) {
//            db.execSQL("INSERT INTO " + TABLE_PURCHASE_ORDER_DETAIL + " (PurchaseOrderID, ProductID, Quantity, UnitPrice, Size) VALUES (1, 1, 2, 10.0, 'M')");
//        }

        // Sample data for BUSINESS_PLAN table
//        for (int i = 1; i <= 10; i++) {
//            db.execSQL("INSERT INTO " + TABLE_BUSINESS_PLAN + " (StartDate, EndDate) VALUES ('2022-01-01', '2022-12-31')");
//        }

        // Sample data for BUSINESS_PLAN_TARGET table
//        for (int i = 1; i <= 10; i++) {
//            db.execSQL("INSERT INTO " + TABLE_BUSINESS_PLAN_TARGET + " (BusinessPlanID, ProductCategory, PurchaseTarget, SaleTarget) VALUES (1, 'Category " + i + "', 100, 200)");
//        }

        Log.d("DatabaseHandler", "addSampleData: sample data added");
    }

}
