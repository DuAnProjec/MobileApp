package com.builtlab.clothing_store.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.adapter.OrderDetailAdapter;
import com.builtlab.clothing_store.adapter.PurchaseOrderDetailAdapter;
import com.builtlab.clothing_store.databinding.ActivityOrderDetailBinding;
import com.builtlab.clothing_store.enums.MethodManagement;
import com.builtlab.clothing_store.enums.StatusOrder;
import com.builtlab.clothing_store.helper.query.CustomerDatabaseQuery;
import com.builtlab.clothing_store.helper.query.OrderDatabaseQuery;
import com.builtlab.clothing_store.helper.query.OrderDetailDatabaseQuery;
import com.builtlab.clothing_store.helper.query.ProductDatabaseQuery;
import com.builtlab.clothing_store.helper.query.PromotionDatabaseQuery;
import com.builtlab.clothing_store.helper.query.PurchaseOrderDatabaseQuery;
import com.builtlab.clothing_store.helper.query.PurchaseOrderDetailDatabaseQuery;
import com.builtlab.clothing_store.helper.query.SupplierDatabaseQuery;
import com.builtlab.clothing_store.interfaces.ObjectListener;
import com.builtlab.clothing_store.model.Customer;
import com.builtlab.clothing_store.model.Order;
import com.builtlab.clothing_store.model.OrderDetail;
import com.builtlab.clothing_store.model.Product;
import com.builtlab.clothing_store.model.Promotion;
import com.builtlab.clothing_store.model.PurchaseOrder;
import com.builtlab.clothing_store.model.PurchaseOrderDetail;
import com.builtlab.clothing_store.model.Supplier;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.OptionalInt;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class OrderDetailActivity extends AppCompatActivity {
    private MethodManagement methodManagement = null;
    private ActivityOrderDetailBinding binding;
    private List<OrderDetail> orderDetails;
    private List<PurchaseOrderDetail> purchaseOrderDetails;
    private List<Customer> customers;
    private List<Supplier> suppliers;
    private List<Promotion> promotions;
    private OrderDetailAdapter orderDetailAdapter;
    private PurchaseOrderDetailAdapter purchaseOrderDetailAdapter;
    private double sumAmountCart = 0;
    private Boolean payed = false;
    private Customer customerSelected = null;
    private Supplier suplierSelected = null;
    private Promotion promotionSelected = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityOrderDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        init();
    }

    private void init() {
        initCustomAppBar();
        initAdapter();
        initDefaultValue();
        initEventComponent();


    }

    private void initDefaultValue() {
        switch (methodManagement) {
            case ORDER: {
                binding.textViewCustomer.setText(R.string.customer);
                break;
            }
            case PURCHASE:
            default: {
                binding.textViewCustomer.setText(R.string.supplier);
                break;
            }
        }
        getTotalPriceProduct();
        binding.chipPaid.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d("ChipCheck", "Chip " + buttonView.getText() + " isChecked: " + isChecked);
                if (isChecked) {
                    payed = true;
//                    Toast.makeText(getApplicationContext(), buttonView.getText() + " checked", Toast.LENGTH_SHORT).show();
                    Log.i("ChipCheck", "Chip " + buttonView.getText() + " isChecked");
                } else {
                    payed = false;
                    binding.chipUnpaid.setChecked(true);
//                    Toast.makeText(getApplicationContext(), buttonView.getText() + " unchecked", Toast.LENGTH_SHORT).show();
                    Log.i("ChipCheck", "Chip " + buttonView.getText() + " unchecked");
                }

            }
        });
        binding.chipUnpaid.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d("ChipCheck", "Chip " + buttonView.getText() + " isChecked: " + isChecked);
                if (isChecked) {
                    payed = false;
//                    Toast.makeText(getApplicationContext(), buttonView.getText() + " checked", Toast.LENGTH_SHORT).show();
                    Log.i("ChipCheck", "Chip " + buttonView.getText() + " isChecked");
                } else {
                    payed = true;
                    binding.chipPaid.setChecked(true);
//                    Toast.makeText(getApplicationContext(), buttonView.getText() + " unchecked", Toast.LENGTH_SHORT).show();
                    Log.i("ChipCheck", "Chip " + buttonView.getText() + " unchecked");
                }
            }
        });
        binding.chipUnpaid.setChecked(true);
        binding.tvVoucher.setText("0 %");


        getDataCustomerSpinner();
        getDataVoucherSpinner();
    }

    private void getDataVoucherSpinner() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(new Runnable() {
            @Override
            public void run() {
                PromotionDatabaseQuery promotionDatabaseQuery = new PromotionDatabaseQuery(getApplicationContext());
                List<Promotion> promotionList = promotionDatabaseQuery.getAllPromotions();

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (promotionList != null) {
                            List<Promotion> _promotions = promotionList;
                            List<Promotion> filteredPromotions = _promotions.stream()
                                    .filter(e -> e.getMinimumOrderAmount() < sumAmountCart)
                                    .collect(Collectors.toList());

                            promotions = filteredPromotions;
                            if (promotions.isEmpty()) {
                                Log.e("TAG", "promotions empty");
                                binding.tvVoucher.setText("0 %");
                                promotionSelected = null;
                                getTotalPriceProduct();
                            }
                            setUpPromotionSpinner(promotions);
                        } else {
                            Log.e("CreateOrderActivity", "Products not found");
                        }
                        executor.shutdown();  // Shut down the executor service
                    }
                });
            }
        });
    }

    private void setUpPromotionSpinner(List<Promotion> _promotions) {
        ArrayAdapter<Promotion> adapter = getPromotionArrayAdapter();

        binding.spinnerVoucherCode.setAdapter(adapter);

        binding.spinnerVoucherCode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (_promotions.isEmpty()) {
                    Log.e("TAG", "promotions empty");
                    promotionSelected = null;
                    getTotalPriceProduct();
                    return;
                }
                Promotion selectedPromotion = (Promotion) parent.getItemAtPosition(position);
                promotionSelected = selectedPromotion;
                getTotalPriceProduct();
//                Toast.makeText(getApplicationContext(), "Selected: " + selectedPromotion.getPromotionId(), Toast.LENGTH_SHORT).show();
                Log.e("TAG", "Selected: " + selectedPromotion.getPromotionId());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                promotionSelected = null;
            }
        });
    }

    @NonNull
    private ArrayAdapter<Promotion> getPromotionArrayAdapter() {
        ArrayAdapter<Promotion> adapter = new ArrayAdapter<Promotion>(this, android.R.layout.simple_spinner_item, promotions) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                return createViewFromResource(position, convertView, parent, android.R.layout.simple_spinner_item);
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                return createViewFromResource(position, convertView, parent, android.R.layout.simple_spinner_dropdown_item);
            }

            private View createViewFromResource(int position, View convertView, ViewGroup parent, int resource) {
                View view = convertView;
                if (view == null) {
                    view = LayoutInflater.from(getContext()).inflate(resource, parent, false);
                }
                view.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));
                TextView text = view.findViewById(android.R.id.text1);
                text.setTextColor(ContextCompat.getColor(getContext(), R.color.brandColor20));
                Promotion promotion = getItem(position);
                assert promotion != null;
                text.setText(promotion.getPromotionName());
                return view;
            }
        };

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    private void getDataCustomerSpinner() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(new Runnable() {
            @Override
            public void run() {
                switch (methodManagement) {
                    case ORDER: {
                        CustomerDatabaseQuery customerDatabaseQuery = new CustomerDatabaseQuery(getApplicationContext());
                        List<Customer> customerList = customerDatabaseQuery.getAllCustomers();
                        handler.post(new Runnable() {
                            @Override
                            public void run() {


                                if (customerList != null) {
                                    customers = customerList;
                                    setUpCustomerSpinner(customers);
                                } else {
                                    Log.e("CreateOrderActivity", "Products not found");
                                }
                                executor.shutdown();  // Shut down the executor service
                            }
                        });
                        break;
                    }
                    case PURCHASE:
                    default: {
                        SupplierDatabaseQuery supplierDatabaseQuery = new SupplierDatabaseQuery(getApplicationContext());
                        List<Supplier> supplierList = supplierDatabaseQuery.getAllSuppliers();
                        handler.post(new Runnable() {
                            @Override
                            public void run() {


                                if (supplierList != null) {
                                    suppliers = supplierList;
                                    setUpSupplierSpinner(suppliers);
                                } else {
                                    Log.e("CreateOrderActivity", "Products not found");
                                }
                                executor.shutdown();  // Shut down the executor service
                            }
                        });
                        break;
                    }
                }


            }
        });
    }

    private void setUpCustomerSpinner(List<Customer> customers) {
        ArrayAdapter<Customer> adapter = new ArrayAdapter<Customer>(this, android.R.layout.simple_spinner_item, customers) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // This method is called to display the currently selected item
                return createViewFromResource(position, convertView, parent, android.R.layout.simple_spinner_item);
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                // This method is called to display each item in the dropdown list
                return createViewFromResource(position, convertView, parent, android.R.layout.simple_spinner_dropdown_item);
            }

            private View createViewFromResource(int position, View convertView, ViewGroup parent, int resource) {
                View view = convertView;
                if (view == null) {
                    view = LayoutInflater.from(getContext()).inflate(resource, parent, false);
                }
                view.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));
                TextView text = view.findViewById(android.R.id.text1);
                text.setTextColor(ContextCompat.getColor(getContext(), R.color.brandColor20));
                Customer customer = getItem(position);
                text.setText(customer.getCustomerName());
                return view;
            }
        };

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        binding.spinnerCustomer.setAdapter(adapter);

        binding.spinnerCustomer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Customer selectedCustomer = (Customer) parent.getItemAtPosition(position);
                customerSelected = selectedCustomer;
//                Toast.makeText(getApplicationContext(), "Selected: " + selectedCustomer.getCustomerName(), Toast.LENGTH_SHORT).show();
                Log.e("TAG", "Selected: " + selectedCustomer.getCustomerName());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                customerSelected = null;
            }
        });
    }

    private void setUpSupplierSpinner(List<Supplier> suppliers) {
        ArrayAdapter<Supplier> adapter = new ArrayAdapter<Supplier>(this, android.R.layout.simple_spinner_item, suppliers) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // This method is called to display the currently selected item
                return createViewFromResource(position, convertView, parent, android.R.layout.simple_spinner_item);
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                // This method is called to display each item in the dropdown list
                return createViewFromResource(position, convertView, parent, android.R.layout.simple_spinner_dropdown_item);
            }

            private View createViewFromResource(int position, View convertView, ViewGroup parent, int resource) {
                View view = convertView;
                if (view == null) {
                    view = LayoutInflater.from(getContext()).inflate(resource, parent, false);
                }
                view.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));
                TextView text = view.findViewById(android.R.id.text1);
                text.setTextColor(ContextCompat.getColor(getContext(), R.color.brandColor20));
                Supplier supplier = getItem(position);
                text.setText(supplier.getSupplierName());
                return view;
            }
        };

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        binding.spinnerCustomer.setAdapter(adapter);

        binding.spinnerCustomer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Supplier selectedSupplier = (Supplier) parent.getItemAtPosition(position);
                suplierSelected = selectedSupplier;
//                Toast.makeText(getApplicationContext(), "Selected: " + selectedCustomer.getCustomerName(), Toast.LENGTH_SHORT).show();
                Log.e("TAG", "Selected: " + suplierSelected.getSupplierName());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                suplierSelected = null;
            }
        });
    }


    private CompoundButton.OnCheckedChangeListener chipCheck = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            Log.d("ChipCheck", "Chip " + buttonView.getText() + " isChecked: " + isChecked);
            if (isChecked) {
//                Toast.makeText(getApplicationContext(), buttonView.getText() + " checked", Toast.LENGTH_SHORT).show();
                Log.i("ChipCheck", "Chip " + buttonView.getText() + " isChecked");
            } else {
//                Toast.makeText(getApplicationContext(), buttonView.getText() + " unchecked", Toast.LENGTH_SHORT).show();
                Log.i("ChipCheck", "Chip " + buttonView.getText() + " unchecked");
            }
        }
    };

    private void getTotalPriceProduct() {
        switch (methodManagement) {
            case ORDER: {
                if (orderDetails.isEmpty()) {
                    sumAmountCart = 0;
                    binding.tvSubTotal.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart)));
                    binding.tvVoucher.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart)));
                    binding.tvTotal.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart)));
                    return;
                }
                break;
            }
            case PURCHASE:
            default: {
                if (purchaseOrderDetails.isEmpty()) {
                    sumAmountCart = 0;
                    binding.tvSubTotal.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart)));
                    binding.tvVoucher.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart)));
                    binding.tvTotal.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart)));
                    return;
                }
                break;
            }
        }

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(new Runnable() {
            @Override
            public void run() {
                ProductDatabaseQuery productDatabaseQuery = new ProductDatabaseQuery(getApplicationContext());
                productDatabaseQuery.open();
                double result = 0;

                switch (methodManagement) {
                    case ORDER: {
                        for (OrderDetail orderDetail : orderDetails) {
                            Product product = productDatabaseQuery.getProductById(orderDetail.getProductId());
                            if (product != null) {
                                result += product.getPrice() * orderDetail.getQuantity();
                            } else {
                                Log.e("OrderDetailActivity", "Product not found");
                            }
                        }
                        break;
                    }
                    case PURCHASE:
                    default: {
                        for (PurchaseOrderDetail purchaseOrderDetail : purchaseOrderDetails) {
                            Product product = productDatabaseQuery.getProductById(purchaseOrderDetail.getProductId());
                            if (product != null) {
                                result += product.getPrice() * purchaseOrderDetail.getQuantity();
                            } else {
                                Log.e("OrderDetailActivity", "Product not found");
                            }
                        }
                        break;
                    }
                }

                productDatabaseQuery.close();

                double finalResult = result;
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (finalResult != 0) {
                            sumAmountCart = finalResult;

                            //binding.tvTotal.setText(MessageFormat.format("{0} đ", String.valueOf(sumAmountCart)));
                            if (promotionSelected != null) {
                                binding.tvSubTotal.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart)));
                                binding.tvVoucher.setText(MessageFormat.format("{0} %", String.valueOf(promotionSelected.getDiscountPercentage())));
                                binding.tvTotal.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart - promotionSelected.getDiscountPercentage() * sumAmountCart * 1.0 / 100)));

                            } else {
                                binding.tvSubTotal.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart)));
                                binding.tvVoucher.setText("0 %");
                                binding.tvTotal.setText(MessageFormat.format("{0} VNĐ", String.valueOf(sumAmountCart)));
                            }
                        } else {
                            Log.e("CreateOrderActivity", "Products not found");
                        }
                        executor.shutdown();  // Shut down the executor service
                    }
                });
            }
        });
    }

    private void initAdapter() {
        switch (methodManagement) {
            case ORDER: {
                orderDetails = getIntent().getParcelableArrayListExtra("orderDetails");
                if (orderDetails == null) {
                    orderDetails = new ArrayList<>(); // Initialize to an empty list to avoid null pointer exception
                }
                orderDetailAdapter = new OrderDetailAdapter(getApplicationContext(), orderDetails, onChangeOrderQuantity, onDeleteProduct);
                Log.e("SIZE", String.valueOf(orderDetails.size()));
                LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
                binding.recycleListProduct.setAdapter(orderDetailAdapter);
                binding.recycleListProduct.setLayoutManager(layoutManager);
                break;
            }
            case PURCHASE:
            default: {
                binding.groupPromotion.setVisibility(View.GONE);
                binding.groupSubTotal.setVisibility(View.GONE);
                binding.groupTextViewPromotion.setVisibility(View.GONE);
                purchaseOrderDetails = getIntent().getParcelableArrayListExtra("purchaseOrderDetails");
                if (purchaseOrderDetails == null) {
                    purchaseOrderDetails = new ArrayList<>(); // Initialize to an empty list to avoid null pointer exception
                }
                purchaseOrderDetailAdapter = new PurchaseOrderDetailAdapter(getApplicationContext(), purchaseOrderDetails, onChangePurchaseOrderQuantity, onDeletePurchaseProduct);
                Log.e("SIZE", String.valueOf(purchaseOrderDetails.size()));
                LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
                binding.recycleListProduct.setAdapter(purchaseOrderDetailAdapter);
                binding.recycleListProduct.setLayoutManager(layoutManager);
                break;
            }
        }

    }

    private final ObjectListener<PurchaseOrderDetail> onChangePurchaseOrderQuantity = new ObjectListener<PurchaseOrderDetail>() {

        @Override
        public void onClick(PurchaseOrderDetail purchaseOrderDetail) {
            int indexOrderDetail = findPurchaseOrderDetailIndexByProductId(purchaseOrderDetails, purchaseOrderDetail.getProductId());
            purchaseOrderDetails.set(indexOrderDetail, purchaseOrderDetail);
            getTotalPriceProduct();
        }
    };

    private final ObjectListener<PurchaseOrderDetail> onDeletePurchaseProduct = new ObjectListener<PurchaseOrderDetail>() {
        @Override
        public void onClick(PurchaseOrderDetail purchaseOrderDetail) {
            int indexOrderDetail = findPurchaseOrderDetailIndexByProductId(purchaseOrderDetails, purchaseOrderDetail.getProductId());
            purchaseOrderDetails.remove(purchaseOrderDetail);
            purchaseOrderDetailAdapter.notifyItemRemoved(indexOrderDetail);
            purchaseOrderDetailAdapter.notifyItemRangeChanged(indexOrderDetail, purchaseOrderDetails.size());
            getTotalPriceProduct();
        }
    };

    private final ObjectListener<OrderDetail> onChangeOrderQuantity = new ObjectListener<OrderDetail>() {

        @Override
        public void onClick(OrderDetail orderDetail) {
            int indexOrderDetail = findOrderDetailIndexByProductId(orderDetails, orderDetail.getProductId());
            orderDetails.set(indexOrderDetail, orderDetail);
            getDataVoucherSpinner();
            getTotalPriceProduct();
        }
    };

    private final ObjectListener<OrderDetail> onDeleteProduct = new ObjectListener<OrderDetail>() {
        @Override
        public void onClick(OrderDetail orderDetail) {
            int indexOrderDetail = findOrderDetailIndexByProductId(orderDetails, orderDetail.getProductId());
            orderDetails.remove(orderDetail);
            orderDetailAdapter.notifyItemRemoved(indexOrderDetail);
            orderDetailAdapter.notifyItemRangeChanged(indexOrderDetail, orderDetails.size());
            getTotalPriceProduct();
        }
    };

    private void onBookingOrder(ExecutorService executor, Handler handler) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // Insert Order
                OrderDatabaseQuery orderDatabaseQuery = new OrderDatabaseQuery(getApplicationContext());
                orderDatabaseQuery.open();
                Order order = new Order();
                order.setCustomerId(customerSelected.getCustomerId());

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String currentDate = sdf.format(new Date());
                order.setOrderDate(currentDate);
                order.setSubTotal(sumAmountCart);

                if (promotionSelected == null) {
                    order.setDiscountAmount(0.0);
                    order.setPromotionId(-1);
                } else {
                    order.setDiscountAmount(promotionSelected.getDiscountPercentage() * sumAmountCart * 0.01);
                    order.setPromotionId(promotionSelected.getPromotionId());
                }

                order.setTotalAmount(sumAmountCart - order.getDiscountAmount());
                order.setStatus(payed ? StatusOrder.SUCCESS.toStringValue() : StatusOrder.PENDING.toStringValue());

                long orderId = orderDatabaseQuery.insert(order);
                orderDatabaseQuery.close();

                // Insert OrderDetails
                OrderDetailDatabaseQuery orderDetailDatabaseQuery = new OrderDetailDatabaseQuery(getApplicationContext());
                orderDetailDatabaseQuery.open();

                for (OrderDetail orderDetail : orderDetails) {
                    orderDetail.setOrderId((int) orderId);
                    long rowId = orderDetailDatabaseQuery.insert(orderDetail);
                    if (rowId == -1) {
                        Log.e("OrderDetailActivity", "Failed to insert OrderDetail: " + orderDetail.toString());
                    } else {
                        Log.i("OrderDetailActivity", "Inserted OrderDetail with ID: " + rowId);
                    }
                }

                ProductDatabaseQuery productDatabaseQuery = new ProductDatabaseQuery(getApplicationContext());
                productDatabaseQuery.open();
                for (OrderDetail orderDetail : orderDetails) {
                    int result = productDatabaseQuery.updateProductStock(orderDetail.getProductId(), orderDetail.getQuantity());
                    Log.i("UPDATESTOCK", result + "");
                }
                productDatabaseQuery.close();

                orderDetailDatabaseQuery.close();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (orderId != -1) {
                            Log.i("CreateOrderActivity", "Order successfully" + order);
                        } else {
                            Log.e("CreateOrderActivity", "Products not found");
                        }
                        executor.shutdown();  // Shut down the executor service
                    }
                });
            }
        });

        Toast.makeText(getApplicationContext(), "Order successfully", Toast.LENGTH_SHORT).show();
    }

    private void onBookingPurchaseOrder(ExecutorService executor, Handler handler) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // Insert Order
                PurchaseOrderDatabaseQuery purchaseOrderDatabaseQuery = new PurchaseOrderDatabaseQuery(getApplicationContext());
                purchaseOrderDatabaseQuery.open();


                PurchaseOrder purchaseOrder = new PurchaseOrder();
                purchaseOrder.setSupplierId(suplierSelected.getSupplierId());
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String currentDate = sdf.format(new Date());
                purchaseOrder.setOrderDate(currentDate);
                purchaseOrder.setTotalAmount(sumAmountCart);
                purchaseOrder.setStatus(payed ? StatusOrder.SUCCESS.toStringValue() : StatusOrder.PENDING.toStringValue());


                int purchaseOrderId = (int) purchaseOrderDatabaseQuery.insert(purchaseOrder);

                purchaseOrderDatabaseQuery.close();

                // Insert OrderDetails
                PurchaseOrderDetailDatabaseQuery purchaseOrderDetailDatabaseQuery = new PurchaseOrderDetailDatabaseQuery(getApplicationContext());
                purchaseOrderDetailDatabaseQuery.open();

                for (PurchaseOrderDetail purchaseOrderDetail : purchaseOrderDetails) {
                    purchaseOrderDetail.setPurchaseOrderId((int) purchaseOrderId);
                    long rowId = purchaseOrderDetailDatabaseQuery.insert(purchaseOrderDetail);
                    if (rowId == -1) {
                        Log.e("OrderDetailActivity", "Failed to insert OrderDetail: " + purchaseOrderDetailDatabaseQuery.toString());
                    } else {
                        Log.i("OrderDetailActivity", "Inserted OrderDetail with ID: " + rowId);
                    }
                }

                ProductDatabaseQuery productDatabaseQuery = new ProductDatabaseQuery(getApplicationContext());
                productDatabaseQuery.open();
                for (PurchaseOrderDetail purchaseOrderDetail : purchaseOrderDetails) {
                    int result = productDatabaseQuery.updatePurchaseProductStock(purchaseOrderDetail.getProductId(), purchaseOrderDetail.getQuantity());
                    Log.i("UPDATESTOCK", result + "");
                }
                productDatabaseQuery.close();

                purchaseOrderDatabaseQuery.close();


                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (purchaseOrderId != -1) {
                            Log.i("CreateOrderActivity", "Order successfully" + purchaseOrderId);
                        } else {
                            Log.e("CreateOrderActivity", "Products not found");
                        }
                        executor.shutdown();  // Shut down the executor service
                    }
                });
            }
        });


        Toast.makeText(getApplicationContext(), "Order successfully", Toast.LENGTH_SHORT).show();

    }

    private void backToRoot() {
        Intent intent = new Intent(getApplicationContext(), RootActivity.class);
        startActivity(intent);
        finish();
    }

    private void initEventComponent() {
        binding.btnOrder.setOnClickListener(v -> {

//            if (payed) {
//                Toast.makeText(getApplicationContext(), "Please select payment method", Toast.LENGTH_SHORT).show();
//                return;
//            }

            ExecutorService executor = Executors.newSingleThreadExecutor();
            Handler handler = new Handler(Looper.getMainLooper());


            switch (methodManagement) {
                case ORDER: {
                    if (customerSelected == null) {
                        Toast.makeText(getApplicationContext(), "Please select customer", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (orderDetails.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please select orderDetails", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    onBookingOrder(executor, handler);
                    backToRoot();
                    break;
                }
                case PURCHASE:
                default: {
                    if (suplierSelected == null) {
                        Toast.makeText(getApplicationContext(), "Please select supplier", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (purchaseOrderDetails.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please select purchaseOrderDetails", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    onBookingPurchaseOrder(executor, handler);
                    backToRoot();
                    break;
                }
            }
        });

        binding.btnDeleteAll.setOnClickListener(v -> {
            switch (methodManagement) {
                case ORDER: {
                    orderDetails.clear();
                    orderDetailAdapter.notifyDataSetChanged();
                    break;
                }
                case PURCHASE:
                default: {
                    purchaseOrderDetails.clear();
                    purchaseOrderDetailAdapter.notifyDataSetChanged();
                    break;
                }
            }

            getTotalPriceProduct();
        });


    }

    private void initCustomAppBar() {
        if (getIntent() != null && getIntent().hasExtra("methodManagement")) {
            methodManagement = MethodManagement.fromString(getIntent().getStringExtra("methodManagement"));
        }

        binding.appbar.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.appbar.appBarTitle.setText(R.string.title_app_bar_detail_order);
    }

    public OrderDetail findOrderDetailByProductId(List<OrderDetail> orderDetails, int productId) {
        for (OrderDetail orderDetail : orderDetails) {
            if (orderDetail.getProductId() == productId) {
                return orderDetail;
            }
        }
        return null;
    }

    public static int findOrderDetailIndexByProductId(List<OrderDetail> orderDetails, int productId) {
        OptionalInt indexOpt = IntStream.range(0, orderDetails.size())
                .filter(i -> orderDetails.get(i).getProductId() == productId)
                .findFirst();
        return indexOpt.orElse(-1);
    }

    public static int findPurchaseOrderDetailIndexByProductId(List<PurchaseOrderDetail> purchaseOrderDetails, int productId) {
        OptionalInt indexOpt = IntStream.range(0, purchaseOrderDetails.size())
                .filter(i -> purchaseOrderDetails.get(i).getProductId() == productId)
                .findFirst();
        return indexOpt.orElse(-1);
    }
}