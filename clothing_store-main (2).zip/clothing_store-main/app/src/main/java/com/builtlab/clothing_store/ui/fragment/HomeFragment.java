package com.builtlab.clothing_store.ui.fragment;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.FragmentHomeBinding;
import com.builtlab.clothing_store.enums.MethodManagement;
import com.builtlab.clothing_store.helper.query.BusinessPlanDatabaseQuery;
import com.builtlab.clothing_store.helper.query.BusinessPlanTargetDatabaseQuery;
import com.builtlab.clothing_store.helper.query.OrderDatabaseQuery;
import com.builtlab.clothing_store.helper.query.OrderDetailDatabaseQuery;
import com.builtlab.clothing_store.helper.query.ProductDatabaseQuery;
import com.builtlab.clothing_store.model.BusinessPlan;
import com.builtlab.clothing_store.model.BusinessPlanTarget;
import com.builtlab.clothing_store.model.Product;
import com.builtlab.clothing_store.ui.activity.OrderManagerActivity;
import com.builtlab.clothing_store.ui.activity.ProductDetailActivity;
import com.builtlab.clothing_store.ui.activity.StatisticGoalActivity;
import com.builtlab.clothing_store.ui.activity.StatisticActivity;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private BusinessPlanDatabaseQuery businessPlanDatabaseQuery;
    private BusinessPlanTargetDatabaseQuery businessPlanTargetDatabaseQuery;
    private ProductDatabaseQuery productDatabaseQuery;

    int planJackets = 0;
    int planTShirts = 0;
    int planTrousers = 0;
    int planDresses = 0;

    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    // INIT CODE IN HERE
    private FragmentHomeBinding binding;
    private PopupWindow popupWindow;
    private List<Product> searchResults = new ArrayList<>();
    private ArrayAdapter<Product> adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        businessPlanDatabaseQuery = new BusinessPlanDatabaseQuery(getActivity());
        businessPlanTargetDatabaseQuery = new BusinessPlanTargetDatabaseQuery(getActivity());
        productDatabaseQuery = new ProductDatabaseQuery(getActivity());

        init();
        return view;
    }

    private void init() {
        initEvent();
        initSearch();
    }

    private void initEvent() {
        binding.buttonToOrderManagement.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), OrderManagerActivity.class);
            intent.putExtra("methodManagement", MethodManagement.ORDER.toStringValue());
            startActivity(intent);
        });

        binding.buttonToPurchaseManagement.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), OrderManagerActivity.class);
            intent.putExtra("methodManagement", MethodManagement.PURCHASE.toStringValue());
            startActivity(intent);
        });

        binding.goalLayout.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), StatisticGoalActivity.class);
            startActivity(intent);
        });

        binding.cvThongKe.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), StatisticActivity.class);
            startActivity(intent);
        });

        loadBusinessPlanData();
    }

    private void initSearch() {
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.popup_search_result, null);

        ListView searchResultList = popupView.findViewById(R.id.search_result_list);

        adapter = new ArrayAdapter<Product>(getActivity(), android.R.layout.simple_list_item_2, android.R.id.text1, searchResults) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                TextView text1 = view.findViewById(android.R.id.text1);
                TextView text2 = view.findViewById(android.R.id.text2);

                Product product = getItem(position);
                text1.setText(product.getProductName());
                text2.setText(String.valueOf(product.getPrice()));

                return view;
            }
        };

        searchResultList.setAdapter(adapter);

        popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        binding.searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0) {
                    if (popupWindow.isShowing()) {
                        popupWindow.dismiss();
                    }
                    return;
                }

                searchResults.clear();
                List<Product> searchedProducts = productDatabaseQuery.searchProductsByName(binding.searchInput.getText().toString());
                for (Product e : searchedProducts) {
                    if (searchResults.size() >= 5) {
                        break;
                    }
                    searchResults.add(e);
                }
                adapter.notifyDataSetChanged();
                if (!popupWindow.isShowing()) {
                    popupWindow.showAsDropDown(binding.searchInput);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        searchResultList.setOnItemClickListener((parent, view, position, id) -> {
            Product selectedItem = searchResults.get(position);
            Intent intent = new Intent(this.getActivity(), ProductDetailActivity.class);
            intent.putExtra("product", selectedItem);
            this.startActivity(intent);
            popupWindow.dismiss();
        });
    }


    private void loadBusinessPlanData() {
        List<BusinessPlan> businessPlans = businessPlanDatabaseQuery.getAllBusinessPlans();

        if (businessPlans.isEmpty()) {
            binding.contentLayout.setVisibility(View.GONE);
            binding.dateRange.setText("Bạn chưa có kế hoạch kinh doanh nào");
        } else {
            binding.contentLayout.setVisibility(View.VISIBLE);
            BusinessPlan businessPlan = businessPlans.get(0);
            binding.dateRange.setText("Chỉ tiêu bán hàng " + businessPlan.getStartDate() + " - " + businessPlan.getEndDate());

            List<BusinessPlanTarget> targets = businessPlanTargetDatabaseQuery.getBusinessPlanTargetsByPlanId(businessPlan.getBusinessPlanId());
            for (BusinessPlanTarget target : targets) {
                switch (target.getProductCategory()) {
                    case "Full set":
                        planJackets = target.getSaleTarget();
                        break;
                    case "Áo":
                        planTShirts = target.getSaleTarget();
                        break;
                    case "Quần":
                        planTrousers = target.getSaleTarget();
                        break;
                    case "Đầm/Váy":
                        planDresses = target.getSaleTarget();
                        break;
                }
            }

            int totalSoldJackets = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Full set"));
            int totalSoldTShirts = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Áo"));
            int totalSoldTrousers = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Quần"));
            int totalSoldDresses = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Đầm/Váy"));

            int totalPlan = planDresses + planJackets + planTrousers + planTShirts;
            int totalSold = totalSoldJackets + totalSoldTShirts + totalSoldTrousers + totalSoldDresses;

            binding.totalPlan.setText(totalPlan + " sản phẩm");
            binding.totalSold.setText(totalSold + " sản phẩm");
            double percent = ((double) totalSold / (double) totalPlan) * 100;
            binding.percentTv.setText(String.format("%.0f%%", percent));
        }
    }

    public int getCategoryIdFromString(String category) {
        switch (category) {
            case "Full set":
                return 1;
            case "Áo":
                return 2;
            case "Quần":
                return 3;
            case "Đầm/Váy":
                return 4;
            default:
                return -1;
        }
    }
}
