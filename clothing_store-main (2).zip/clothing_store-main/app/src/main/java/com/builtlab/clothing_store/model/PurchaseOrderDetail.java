package com.builtlab.clothing_store.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class PurchaseOrderDetail implements Parcelable {
    private int purchaseOrderDetailId;
    private int purchaseOrderId;
    private int productId;
    private int quantity;
    private double unitPrice;
    private String size;

    public PurchaseOrderDetail(int purchaseOrderDetailId, int purchaseOrderId, int productId, int quantity, double unitPrice, String size) {
        this.purchaseOrderDetailId = purchaseOrderDetailId;
        this.purchaseOrderId = purchaseOrderId;
        this.productId = productId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.size = size;
    }

    public PurchaseOrderDetail() {

    }

    protected PurchaseOrderDetail(Parcel in) {
        purchaseOrderDetailId = in.readInt();
        purchaseOrderId = in.readInt();
        productId = in.readInt();
        quantity = in.readInt();
        unitPrice = in.readDouble();
        size = in.readString();
    }

    public static final Creator<PurchaseOrderDetail> CREATOR = new Creator<PurchaseOrderDetail>() {
        @Override
        public PurchaseOrderDetail createFromParcel(Parcel in) {
            return new PurchaseOrderDetail(in);
        }

        @Override
        public PurchaseOrderDetail[] newArray(int size) {
            return new PurchaseOrderDetail[size];
        }
    };

    public int getPurchaseOrderDetailId() {
        return purchaseOrderDetailId;
    }

    public void setPurchaseOrderDetailId(int purchaseOrderDetailId) {
        this.purchaseOrderDetailId = purchaseOrderDetailId;
    }

    public int getPurchaseOrderId() {
        return purchaseOrderId;
    }

    public void setPurchaseOrderId(int purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "PurchaseOrderDetail{" +
                "purchaseOrderDetailId=" + purchaseOrderDetailId +
                ", purchaseOrderId=" + purchaseOrderId +
                ", productId=" + productId +
                ", quantity=" + quantity +
                ", unitPrice=" + unitPrice +
                ", size='" + size + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeInt(purchaseOrderDetailId);
        dest.writeInt(purchaseOrderId);
        dest.writeInt(productId);
        dest.writeInt(quantity);
        dest.writeDouble(unitPrice);
        dest.writeString(size);
    }
}
