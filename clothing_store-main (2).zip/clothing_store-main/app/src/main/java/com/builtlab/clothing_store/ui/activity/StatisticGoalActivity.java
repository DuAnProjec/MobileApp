package com.builtlab.clothing_store.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.builtlab.clothing_store.R;
import com.builtlab.clothing_store.databinding.ActivityStatisticGoalBinding;
import com.builtlab.clothing_store.helper.EmailSender;
import com.builtlab.clothing_store.helper.query.BusinessPlanDatabaseQuery;
import com.builtlab.clothing_store.helper.query.BusinessPlanTargetDatabaseQuery;
import com.builtlab.clothing_store.helper.query.OrderDatabaseQuery;
import com.builtlab.clothing_store.helper.query.OrderDetailDatabaseQuery;
import com.builtlab.clothing_store.helper.query.ProductDatabaseQuery;
import com.builtlab.clothing_store.model.BusinessPlan;
import com.builtlab.clothing_store.model.BusinessPlanTarget;
import com.builtlab.clothing_store.model.Order;
import com.builtlab.clothing_store.model.OrderDetail;
import com.builtlab.clothing_store.model.PurchaseOrder;

import java.util.List;

public class StatisticGoalActivity extends AppCompatActivity {
    public static final int CREATE_GOAL_REQUEST_CODE = 1001;
    private ActivityStatisticGoalBinding binding;
    private BusinessPlanDatabaseQuery businessPlanDatabaseQuery;
    private BusinessPlanTargetDatabaseQuery businessPlanTargetDatabaseQuery;
    private OrderDatabaseQuery orderDatabaseQuery;
    private ProductDatabaseQuery productDatabaseQuery;
    private OrderDetailDatabaseQuery orderDetailDatabaseQuery;

    int planJackets = 0;
    int planTShirts = 0;
    int planTrousers = 0;
    int planDresses = 0;

    int planPurchaseJackets = 0;
    int planPurchaseTShirts = 0;
    int planPurchaseTrousers = 0;
    int planPurchaseDresses = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityStatisticGoalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        businessPlanDatabaseQuery = new BusinessPlanDatabaseQuery(this);
        businessPlanTargetDatabaseQuery = new BusinessPlanTargetDatabaseQuery(this);
        orderDatabaseQuery = new OrderDatabaseQuery(this);
        productDatabaseQuery = new ProductDatabaseQuery(this);
        orderDetailDatabaseQuery = new OrderDetailDatabaseQuery(this);

        init();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_GOAL_REQUEST_CODE && resultCode == RESULT_OK) {
            checkBusinessPlans();
        }
    }

    private void init() {
        initAppBar();
        initEvent();
        checkBusinessPlans();

    }

    private void initEvent() {
        binding.buttonCreateNewOrder.setOnClickListener(v -> {
            Intent intent = new Intent(this, CreateGoalActivity.class);
            startActivityForResult(intent, CREATE_GOAL_REQUEST_CODE);
        });
    }

    private void initAppBar() {
        binding.appbar.appBarTitle.setText(R.string.business_plan);
        binding.appbar.buttonBack.setOnClickListener(v -> {
            finish();
        });
    }

    private void checkBusinessPlans() {
        List<BusinessPlan> businessPlans = businessPlanDatabaseQuery.getAllBusinessPlans();

        if (businessPlans.isEmpty()) {
            binding.imageViewEmptyStatisticGoal.setVisibility(View.VISIBLE);
            binding.textViewEmpty.setVisibility(View.VISIBLE);

            binding.groupTimeline.setVisibility(View.GONE);
            binding.groupFigureBuyProduct.setVisibility(View.GONE);
            binding.groupFigureSellProduct.setVisibility(View.GONE);
            binding.groupFigureRealisticProduct.setVisibility(View.GONE);
        } else {
            binding.imageViewEmptyStatisticGoal.setVisibility(View.GONE);
            binding.textViewEmpty.setVisibility(View.GONE);

            binding.groupTimeline.setVisibility(View.VISIBLE);
            binding.groupFigureBuyProduct.setVisibility(View.VISIBLE);
            binding.groupFigureSellProduct.setVisibility(View.VISIBLE);
            binding.groupFigureRealisticProduct.setVisibility(View.VISIBLE);

            BusinessPlan businessPlan = businessPlans.get(0);
            displayBusinessPlan(businessPlan);
        }
    }

    private void displayBusinessPlan(BusinessPlan businessPlan) {
        binding.textViewStartDate.setText(businessPlan.getStartDate());
        binding.textViewEndDate.setText(businessPlan.getEndDate());

        List<BusinessPlanTarget> targets = businessPlanTargetDatabaseQuery.getBusinessPlanTargetsByPlanId(businessPlan.getBusinessPlanId());
        for (BusinessPlanTarget target : targets) {
            switch (target.getProductCategory()) {
                case "Full set":
                    planJackets = target.getSaleTarget();
                    planPurchaseJackets = target.getPurchaseTarget();
                    binding.groupBuyJacket.title.setText(target.getProductCategory());
                    binding.groupSellJacket.title.setText(target.getProductCategory());
                    updateTargetViews(binding.groupBuyJacket.quantityBuyJacket, binding.groupSellJacket.quantityBuyJacket, target);
                    break;
                case "Áo":
                    planTShirts = target.getSaleTarget();
                    planPurchaseTShirts = target.getPurchaseTarget();
                    binding.groupBuyTShirt.title.setText(target.getProductCategory());
                    binding.groupSellTShirt.title.setText(target.getProductCategory());
                    updateTargetViews(binding.groupBuyTShirt.quantityBuyJacket, binding.groupSellTShirt.quantityBuyJacket, target);
                    break;
                case "Quần":
                    planTrousers = target.getSaleTarget();
                    planPurchaseTrousers = target.getPurchaseTarget();
                    binding.groupBuyTrouser.title.setText(target.getProductCategory());
                    binding.groupSellTrouser.title.setText(target.getProductCategory());
                    updateTargetViews(binding.groupBuyTrouser.quantityBuyJacket, binding.groupSellTrouser.quantityBuyJacket, target);
                    break;
                case "Đầm/Váy":
                    planDresses = target.getSaleTarget();
                    planPurchaseDresses = target.getPurchaseTarget();
                    binding.groupBuyDress.title.setText(target.getProductCategory());
                    binding.groupSellDress.title.setText(target.getProductCategory());
                    updateTargetViews(binding.groupBuyDress.quantityBuyJacket, binding.groupSellDress.quantityBuyJacket, target);
                    break;
            }
        }

        displayRealisticFigures(businessPlan.getStartDate(), businessPlan.getEndDate());
        checkAndSendEmailWarnings();
    }

    private void updateTargetViews(TextView buyTextView, TextView sellTextView, BusinessPlanTarget target) {
        buyTextView.setText(String.valueOf(target.getPurchaseTarget()));
        sellTextView.setText(String.valueOf(target.getSaleTarget()));
    }

    public int getCategoryIdFromString(String category) {
        switch (category) {
            case "Full set":
                return 1;
            case "Áo":
                return 2;
            case "Quần":
                return 3;
            case "Đầm/Váy":
                return 4;
            default:
                return -1;
        }
    }

    private void displayRealisticFigures(String startDate, String endDate) {
        int totalSoldJackets = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Full set"));
        int totalSoldTShirts = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Áo"));
        int totalSoldTrousers = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Quần"));
        int totalSoldDresses = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Đầm/Váy"));

        binding.groupSumJacketRealistic.leftNameProduct.setText("Full set");
        binding.groupSumJacketRealistic.rightNameProduct.setText("Full set");
        binding.groupSumTShirtRealistic.leftNameProduct.setText("Áo");
        binding.groupSumTShirtRealistic.rightNameProduct.setText("Áo");
        binding.groupSumTrouserRealistic.leftNameProduct.setText("Quần");
        binding.groupSumTrouserRealistic.rightNameProduct.setText("Quần");
        binding.groupSumDressRealistic.leftNameProduct.setText("Đầm/Váy");
        binding.groupSumDressRealistic.rightNameProduct.setText("Đầm/Váy");

        int differenceSoldJackets = Math.abs(planJackets - totalSoldJackets);
        int differenceSoldTShirts = Math.abs(planTShirts - totalSoldTShirts);
        int differenceSoldTrousers = Math.abs(planTrousers - totalSoldTrousers);
        int differenceSoldDresses = Math.abs(planDresses - totalSoldDresses);

        int progressSoldJackets = (int) ((totalSoldJackets / (double) planJackets) * 100);
        int progressSoldTShirts = (int) ((totalSoldTShirts / (double) planTShirts) * 100);
        int progressSoldTrousers = (int) ((totalSoldTrousers / (double) planTrousers) * 100);
        int progressSoldDresses = (int) ((totalSoldDresses / (double) planDresses) * 100);

        binding.groupSumJacketRealistic.leftQuantityProduct.setText(String.valueOf(differenceSoldJackets));
        binding.groupSumTShirtRealistic.leftQuantityProduct.setText(String.valueOf(differenceSoldTShirts));
        binding.groupSumTrouserRealistic.leftQuantityProduct.setText(String.valueOf(differenceSoldTrousers));
        binding.groupSumDressRealistic.leftQuantityProduct.setText(String.valueOf(differenceSoldDresses));

        binding.groupSumJacketRealistic.statusLeft.setText(totalSoldJackets > planJackets ? "vượt quá" : "còn lại");
        binding.groupSumTShirtRealistic.statusLeft.setText(totalSoldTShirts > planTShirts ? "vượt quá" : "còn lại");
        binding.groupSumTrouserRealistic.statusLeft.setText(totalSoldTrousers > planTrousers ? "vượt quá" : "còn lại");
        binding.groupSumDressRealistic.statusLeft.setText(totalSoldDresses > planDresses ? "vượt quá" : "còn lại");

        binding.groupSumJacketRealistic.leftValueProgressbar.setProgress(progressSoldJackets);
        binding.groupSumTShirtRealistic.leftValueProgressbar.setProgress(progressSoldTShirts);
        binding.groupSumTrouserRealistic.leftValueProgressbar.setProgress(progressSoldTrousers);
        binding.groupSumDressRealistic.leftValueProgressbar.setProgress(progressSoldDresses);

        binding.groupSumJacketRealistic.leftPercentageText.setText(progressSoldJackets + "%");
        binding.groupSumTShirtRealistic.leftPercentageText.setText(progressSoldTShirts + "%");
        binding.groupSumTrouserRealistic.leftPercentageText.setText(progressSoldTrousers + "%");
        binding.groupSumDressRealistic.leftPercentageText.setText(progressSoldDresses + "%");

        int totalPurchasedJackets = productDatabaseQuery.getTotalBuyByCategoryId(getCategoryIdFromString("Full set"));
        int totalPurchasedTShirts = productDatabaseQuery.getTotalBuyByCategoryId(getCategoryIdFromString("Áo"));
        int totalPurchasedTrousers = productDatabaseQuery.getTotalBuyByCategoryId(getCategoryIdFromString("Quần"));
        int totalPurchasedDresses = productDatabaseQuery.getTotalBuyByCategoryId(getCategoryIdFromString("Đầm/Váy"));

        int differencePurchasedJackets = Math.abs(planPurchaseJackets - totalPurchasedJackets);
        int differencePurchasedTShirts = Math.abs(planPurchaseTShirts - totalPurchasedTShirts);
        int differencePurchasedTrousers = Math.abs(planPurchaseTrousers - totalPurchasedTrousers);
        int differencePurchasedDresses = Math.abs(planPurchaseDresses - totalPurchasedDresses);

        int progressPurchasedJackets = (int) ((totalPurchasedJackets / (double) planPurchaseJackets) * 100);
        int progressPurchasedTShirts = (int) ((totalPurchasedTShirts / (double) planPurchaseTShirts) * 100);
        int progressPurchasedTrousers = (int) ((totalPurchasedTrousers / (double) planPurchaseTrousers) * 100);
        int progressPurchasedDresses = (int) ((totalPurchasedDresses / (double) planPurchaseDresses) * 100);

        binding.groupSumJacketRealistic.rightQuantityProduct.setText(String.valueOf(differencePurchasedJackets));
        binding.groupSumTShirtRealistic.rightQuantityProduct.setText(String.valueOf(differencePurchasedTShirts));
        binding.groupSumTrouserRealistic.rightQuantityProduct.setText(String.valueOf(differencePurchasedTrousers));
        binding.groupSumDressRealistic.rightQuantityProduct.setText(String.valueOf(differencePurchasedDresses));

        binding.groupSumJacketRealistic.statusRight.setText(totalPurchasedJackets > planPurchaseJackets ? "vượt quá" : "còn lại");
        binding.groupSumTShirtRealistic.statusRight.setText(totalPurchasedTShirts > planPurchaseTShirts ? "vượt quá" : "còn lại");
        binding.groupSumTrouserRealistic.statusRight.setText(totalPurchasedTrousers > planPurchaseTrousers ? "vượt quá" : "còn lại");
        binding.groupSumDressRealistic.statusRight.setText(totalPurchasedDresses > planPurchaseDresses ? "vượt quá" : "còn lại");

        binding.groupSumJacketRealistic.rightValueProgressbar.setProgress(progressPurchasedJackets);
        binding.groupSumTShirtRealistic.rightValueProgressbar.setProgress(progressPurchasedTShirts);
        binding.groupSumTrouserRealistic.rightValueProgressbar.setProgress(progressPurchasedTrousers);
        binding.groupSumDressRealistic.rightValueProgressbar.setProgress(progressPurchasedDresses);

        binding.groupSumJacketRealistic.rightPercentageText.setText(progressPurchasedJackets + "%");
        binding.groupSumTShirtRealistic.rightPercentageText.setText(progressPurchasedTShirts + "%");
        binding.groupSumTrouserRealistic.rightPercentageText.setText(progressPurchasedTrousers + "%");
        binding.groupSumDressRealistic.rightPercentageText.setText(progressPurchasedDresses + "%");

        binding.quantitySumSellRealistic.setText(String.valueOf(totalSoldDresses + totalSoldJackets + totalSoldTrousers + totalSoldTShirts));
        binding.quantitySumBuyRealistic.setText(String.valueOf(totalPurchasedJackets + totalPurchasedTShirts + totalPurchasedTrousers + totalPurchasedDresses));
    }

    private void checkAndSendEmailWarnings() {
        int totalSoldJackets = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Full set"));
        int totalSoldTShirts = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Áo"));
        int totalSoldTrousers = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Quần"));
        int totalSoldDresses = productDatabaseQuery.getTotalSoldByCategoryId(getCategoryIdFromString("Đầm/Váy"));

        String emailBody = "";

        if (totalSoldJackets > planJackets) {
            emailBody += "Sản phẩm Full set đã vượt kế hoạch.\n";
        }
        if (totalSoldTShirts > planTShirts) {
            emailBody += "Sản phẩm Áo đã vượt kế hoạch.\n";
        }
        if (totalSoldTrousers > planTrousers) {
            emailBody += "Sản phẩm Quần đã vượt kế hoạch.\n";
        }
        if (totalSoldDresses > planDresses) {
            emailBody += "Sản phẩm Đầm/Váy đã vượt kế hoạch.\n";
        }

        if (!emailBody.isEmpty()) {
            EmailSender.sendEmailAsync("ngminhan10082003@gmail.com", "Khuyến cáo vượt hạn mức kế hoạch", emailBody);
        }
    }
}
